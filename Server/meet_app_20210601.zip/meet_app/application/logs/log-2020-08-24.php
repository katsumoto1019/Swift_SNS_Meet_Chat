<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-24 02:35:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-08-24 11:03:10 --> 404 Page Not Found: Api/closeAccount
ERROR - 2020-08-24 11:03:12 --> 404 Page Not Found: Api/closeAccount
ERROR - 2020-08-24 11:03:13 --> 404 Page Not Found: Api/closeAccount
ERROR - 2020-08-24 21:52:30 --> 404 Page Not Found: Robotstxt/index
