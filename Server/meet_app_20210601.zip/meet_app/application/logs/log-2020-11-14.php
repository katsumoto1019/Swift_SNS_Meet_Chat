<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-14 00:22:58 --> 404 Page Not Found: Wp_admin/install.php
ERROR - 2020-11-14 07:47:24 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-11-14 07:47:25 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-11-14 23:44:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-14 23:44:03 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2020-11-14 23:44:06 --> 404 Page Not Found: Adstxt/index
