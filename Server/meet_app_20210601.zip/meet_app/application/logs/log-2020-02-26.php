<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-26 02:46:38 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) C:\xampp\htdocs\foodtrack\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2020-02-26 02:46:38 --> Unable to connect to the database
ERROR - 2020-02-26 02:47:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'foodtrack' C:\xampp\htdocs\foodtrack\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2020-02-26 02:47:39 --> Unable to connect to the database
ERROR - 2020-02-26 02:47:42 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'foodtrack' C:\xampp\htdocs\foodtrack\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2020-02-26 02:47:42 --> Unable to connect to the database
ERROR - 2020-02-26 02:47:44 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'foodtrack' C:\xampp\htdocs\foodtrack\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2020-02-26 02:47:44 --> Unable to connect to the database
ERROR - 2020-02-26 02:52:06 --> 404 Page Not Found: Admin/sales
