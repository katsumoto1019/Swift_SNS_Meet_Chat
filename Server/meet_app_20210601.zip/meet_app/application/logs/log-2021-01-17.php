<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-17 07:41:24 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-01-17 07:41:25 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-01-17 08:41:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-01-17 10:54:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-01-17 12:54:35 --> 404 Page Not Found: Robotstxt/index
