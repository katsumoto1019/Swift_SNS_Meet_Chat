<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-01 03:36:18 --> Severity: error --> Exception: Call to undefined method Api_model::delete_query() C:\xampp\htdocs\application\controllers\Api.php 1334
ERROR - 2020-04-01 03:39:20 --> Severity: error --> Exception: Call to undefined method Api_model::delete_query() C:\xampp\htdocs\application\controllers\Api.php 1334
ERROR - 2020-04-01 05:20:03 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-04-01 05:20:35 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-04-01 05:21:14 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-04-01 05:21:34 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-04-01 05:22:01 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-04-01 05:22:18 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-04-01 05:22:23 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-04-01 05:22:38 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-04-01 05:23:42 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-04-01 05:23:44 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-04-01 05:23:59 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-04-01 05:24:16 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-04-01 05:24:18 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-04-01 05:24:21 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-04-01 05:24:24 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-04-01 05:36:42 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-04-01 05:45:37 --> 404 Page Not Found: Manifestjson/index
