<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-09 00:35:38 --> 404 Page Not Found: Env/index
ERROR - 2020-10-09 00:35:44 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-10-09 12:39:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'Group By tb_user.id' at line 1 - Invalid query: SELECT * FROM tb_user WHERE tb_user.id !=  Group By tb_user.id
ERROR - 2020-10-09 12:41:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND (tb_user.user_gender ='フェム') Group By tb_user.id' at line 1 - Invalid query: SELECT * FROM tb_user WHERE  AND (tb_user.user_gender ='フェム') Group By tb_user.id
ERROR - 2020-10-09 06:57:24 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-10-09 06:57:24 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-10-09 07:10:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-10-09 07:11:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-10-09 07:11:28 --> 404 Page Not Found: Asset_manifestjson/index
ERROR - 2020-10-09 15:39:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-10-09 15:39:49 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2020-10-09 15:39:51 --> 404 Page Not Found: Blog/robots.txt
ERROR - 2020-10-09 15:39:51 --> 404 Page Not Found: Blog/index
ERROR - 2020-10-09 15:39:52 --> 404 Page Not Found: Wordpress/index
ERROR - 2020-10-09 15:39:52 --> 404 Page Not Found: Wp/index
