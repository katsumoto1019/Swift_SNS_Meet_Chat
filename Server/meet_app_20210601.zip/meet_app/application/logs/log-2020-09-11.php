<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-11 11:01:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-09-11 11:05:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Can't connect to local MySQL server through socket '/var/lib/mysql/mysql.sock' (2) /home/wvl3ni4qjvil/public_html/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2020-09-11 11:05:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Can't connect to local MySQL server through socket '/var/lib/mysql/mysql.sock' (2) /home/wvl3ni4qjvil/public_html/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2020-09-11 11:05:17 --> Unable to connect to the database
ERROR - 2020-09-11 11:05:49 --> Unable to connect to the database
