<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-29 04:16:34 --> 404 Page Not Found: Api/getMyDetails
ERROR - 2019-12-29 05:22:33 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\application\controllers\Api.php 152
ERROR - 2019-12-29 05:22:33 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\application\controllers\Api.php 152
ERROR - 2019-12-29 05:22:33 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\application\controllers\Api.php 152
ERROR - 2019-12-29 05:22:33 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\application\controllers\Api.php 152
ERROR - 2019-12-29 05:22:33 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\application\controllers\Api.php 152
ERROR - 2019-12-29 05:22:33 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\application\controllers\Api.php 152
ERROR - 2019-12-29 09:21:02 --> Severity: Notice --> Undefined variable: queryC C:\xampp\htdocs\application\controllers\Api.php 241
ERROR - 2019-12-29 09:21:02 --> Severity: error --> Exception: Call to a member function num_rows() on null C:\xampp\htdocs\application\controllers\Api.php 241
