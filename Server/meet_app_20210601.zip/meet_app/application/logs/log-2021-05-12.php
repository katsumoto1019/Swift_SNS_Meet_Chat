<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-12 02:19:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-12 06:19:14 --> 404 Page Not Found: Public/assets
ERROR - 2021-05-12 06:35:13 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-05-12 06:35:14 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-05-12 18:20:27 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-05-12 18:20:27 --> 404 Page Not Found: Wp_loginphp/index
