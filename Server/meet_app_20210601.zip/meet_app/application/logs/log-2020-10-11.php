<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-11 00:35:22 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-10-11 01:13:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-10-11 12:13:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT * FROM `tb_user` JOIN tb_follow ON tb_user.id = tb_follow.owner_id WHERE tb_follow.user_id = 
ERROR - 2020-10-11 12:16:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT * FROM `tb_user` JOIN tb_follow ON tb_user.id = tb_follow.owner_id WHERE tb_follow.user_id =
ERROR - 2020-10-11 06:52:02 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-10-11 06:52:03 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-10-11 09:06:32 --> 404 Page Not Found: Apple_touch_iconpng/index
ERROR - 2020-10-11 09:06:32 --> 404 Page Not Found: Apple_touch_icon_precomposedpng/index
ERROR - 2020-10-11 09:06:36 --> 404 Page Not Found: Apple_touch_icon_120x120_precomposedpng/index
ERROR - 2020-10-11 09:06:36 --> 404 Page Not Found: Apple_touch_icon_120x120png/index
ERROR - 2020-10-11 09:06:36 --> 404 Page Not Found: Apple_touch_iconpng/index
ERROR - 2020-10-11 09:06:36 --> 404 Page Not Found: Apple_touch_iconpng/index
ERROR - 2020-10-11 09:06:56 --> 404 Page Not Found: Apple_touch_icon_120x120_precomposedpng/index
ERROR - 2020-10-11 09:06:57 --> 404 Page Not Found: Apple_touch_icon_120x120png/index
ERROR - 2020-10-11 09:06:57 --> 404 Page Not Found: Apple_touch_iconpng/index
ERROR - 2020-10-11 09:06:57 --> 404 Page Not Found: Apple_touch_iconpng/index
