<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-31 00:23:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-31 00:46:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-31 07:47:01 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-12-31 07:47:02 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-12-31 17:10:30 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-12-31 22:27:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-31 23:54:38 --> 404 Page Not Found: Robotstxt/index
