<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-13 07:43:09 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-11-13 07:43:10 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-11-13 14:16:10 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-11-13 16:51:29 --> 404 Page Not Found: Wp_loginphp/index
