<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-23 07:19:36 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-01-23 07:19:36 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-01-23 07:46:27 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-01-23 07:46:28 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-01-23 09:03:42 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-01-23 14:01:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-01-23 15:15:34 --> 404 Page Not Found: Env/index
ERROR - 2021-01-23 15:15:35 --> 404 Page Not Found: Wp_content/index
ERROR - 2021-01-23 18:00:57 --> 404 Page Not Found: Wp_includes/wlwmanifest.xml
ERROR - 2021-01-23 18:00:58 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2021-01-23 18:03:04 --> 404 Page Not Found: News/wp_includes
ERROR - 2021-01-23 18:03:04 --> 404 Page Not Found: 2020/wp_includes
ERROR - 2021-01-23 18:03:05 --> 404 Page Not Found: 2019/wp_includes
ERROR - 2021-01-23 18:03:05 --> 404 Page Not Found: Shop/wp_includes
ERROR - 2021-01-23 18:03:05 --> 404 Page Not Found: Wp1/wp_includes
ERROR - 2021-01-23 18:03:05 --> 404 Page Not Found: Test/wp_includes
ERROR - 2021-01-23 18:03:05 --> 404 Page Not Found: Wp2/wp_includes
ERROR - 2021-01-23 18:03:06 --> 404 Page Not Found: Site/wp_includes
ERROR - 2021-01-23 18:03:06 --> 404 Page Not Found: Cms/wp_includes
ERROR - 2021-01-23 18:03:07 --> 404 Page Not Found: Sito/wp_includes
ERROR - 2021-01-23 20:09:51 --> 404 Page Not Found: Env/index
