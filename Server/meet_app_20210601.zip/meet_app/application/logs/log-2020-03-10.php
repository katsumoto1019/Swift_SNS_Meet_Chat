<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-10 01:43:14 --> Severity: Notice --> Undefined index: categories C:\xampp\htdocs\application\controllers\Api.php 86
ERROR - 2020-03-10 01:43:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\controllers\Api.php 86
ERROR - 2020-03-10 04:49:44 --> Severity: Compile Error --> Cannot redeclare Api::getWorkoutVideoCheckout() C:\xampp\htdocs\application\controllers\Api.php 792
ERROR - 2020-03-10 04:50:59 --> Severity: Compile Error --> Cannot redeclare Api::getWorkoutVideoCheckout() C:\xampp\htdocs\application\controllers\Api.php 792
ERROR - 2020-03-10 04:51:10 --> Severity: Compile Error --> Cannot redeclare Api::getWorkoutVideoCheckout() C:\xampp\htdocs\application\controllers\Api.php 792
ERROR - 2020-03-10 04:51:12 --> Severity: Compile Error --> Cannot redeclare Api::getWorkoutVideoCheckout() C:\xampp\htdocs\application\controllers\Api.php 792
ERROR - 2020-03-10 04:51:23 --> Severity: Compile Error --> Cannot redeclare Api::getWorkoutVideoCheckout() C:\xampp\htdocs\application\controllers\Api.php 792
ERROR - 2020-03-10 05:03:13 --> Severity: Compile Error --> Cannot redeclare Api::getWorkoutVideoCheckout() C:\xampp\htdocs\application\controllers\Api.php 792
ERROR - 2020-03-10 05:04:16 --> Severity: Compile Error --> Cannot redeclare Api::getWorkoutVideoCheckout() C:\xampp\htdocs\application\controllers\Api.php 792
ERROR - 2020-03-10 05:04:18 --> Severity: Compile Error --> Cannot redeclare Api::getWorkoutVideoCheckout() C:\xampp\htdocs\application\controllers\Api.php 792
ERROR - 2020-03-10 05:04:20 --> Severity: Compile Error --> Cannot redeclare Api::getWorkoutVideoCheckout() C:\xampp\htdocs\application\controllers\Api.php 792
ERROR - 2020-03-10 05:07:42 --> Severity: Compile Error --> Cannot redeclare Api::getWorkoutVideoCheckout() C:\xampp\htdocs\application\controllers\Api.php 792
ERROR - 2020-03-10 05:10:33 --> Severity: Compile Error --> Cannot redeclare Api::getWorkoutVideoCheckout() C:\xampp\htdocs\application\controllers\Api.php 792
ERROR - 2020-03-10 05:24:41 --> 404 Page Not Found: Api/getRecommend
ERROR - 2020-03-10 05:46:31 --> Query error: Unknown column 'quantity' in 'field list' - Invalid query: INSERT INTO `tb_mynutritionists` (`quantity`, `product_id`, `user_id`) VALUES ('1', '1', '6')
ERROR - 2020-03-10 06:32:59 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\application\controllers\Api.php 609
ERROR - 2020-03-10 06:32:59 --> Query error: Column 'email' cannot be null - Invalid query: INSERT INTO `tb_mynutritionists` (`user_id`, `nutritionist_id`, `email`, `status`) VALUES ('6', '3', NULL, 'yes')
ERROR - 2020-03-10 06:36:40 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\application\controllers\Api.php 609
ERROR - 2020-03-10 06:36:40 --> Query error: Column 'email' cannot be null - Invalid query: INSERT INTO `tb_mynutritionists` (`user_id`, `nutritionist_id`, `email`, `status`) VALUES ('6', '3', NULL, 'yes')
ERROR - 2020-03-10 06:40:20 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\application\controllers\Api.php 609
ERROR - 2020-03-10 06:40:20 --> Query error: Column 'email' cannot be null - Invalid query: INSERT INTO `tb_mynutritionists` (`user_id`, `nutritionist_id`, `email`, `status`) VALUES ('6', '3', NULL, 'yes')
ERROR - 2020-03-10 07:42:19 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-10 07:42:20 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-10 06:52:42 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\application\controllers\Api.php 609
ERROR - 2020-03-10 06:52:42 --> Query error: Column 'email' cannot be null - Invalid query: INSERT INTO `tb_mynutritionists` (`user_id`, `nutritionist_id`, `email`, `status`) VALUES ('6', '3', NULL, 'yes')
ERROR - 2020-03-10 07:26:14 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\application\controllers\Api.php 609
ERROR - 2020-03-10 07:26:14 --> Query error: Column 'email' cannot be null - Invalid query: INSERT INTO `tb_mynutritionists` (`user_id`, `nutritionist_id`, `email`, `status`) VALUES ('6', '3', NULL, 'yes')
ERROR - 2020-03-10 07:39:04 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\application\controllers\Api.php 609
ERROR - 2020-03-10 07:39:04 --> Query error: Column 'email' cannot be null - Invalid query: INSERT INTO `tb_mynutritionists` (`user_id`, `nutritionist_id`, `email`, `status`) VALUES ('6', '6', NULL, 'yes')
ERROR - 2020-03-10 07:41:20 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\application\controllers\Api.php 606
ERROR - 2020-03-10 07:41:20 --> Query error: Column 'email' cannot be null - Invalid query: INSERT INTO `tb_mynutritionists` (`user_id`, `nutritionist_id`, `email`, `status`) VALUES ('6', '3', NULL, 'yes')
ERROR - 2020-03-10 07:44:36 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\application\controllers\Api.php 606
ERROR - 2020-03-10 07:44:36 --> Query error: Column 'email' cannot be null - Invalid query: INSERT INTO `tb_mynutritionists` (`user_id`, `nutritionist_id`, `email`, `status`) VALUES ('6', '3', NULL, 'yes')
ERROR - 2020-03-10 09:17:39 --> Severity: Notice --> Undefined index: categories C:\xampp\htdocs\application\controllers\Api.php 86
ERROR - 2020-03-10 09:17:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\controllers\Api.php 86
ERROR - 2020-03-10 13:06:22 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-10 13:06:23 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-10 13:06:25 --> 404 Page Not Found: Manifestjson/index
