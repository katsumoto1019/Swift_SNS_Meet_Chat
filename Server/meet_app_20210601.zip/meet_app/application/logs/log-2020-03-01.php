<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-01 11:52:01 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\application\controllers\Api.php 487
ERROR - 2020-03-01 11:52:01 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\application\controllers\Api.php 487
ERROR - 2020-03-01 11:52:01 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\application\controllers\Api.php 487
ERROR - 2020-03-01 11:52:01 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\application\controllers\Api.php 487
ERROR - 2020-03-01 11:52:01 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\application\controllers\Api.php 487
ERROR - 2020-03-01 11:52:01 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\application\controllers\Api.php 487
ERROR - 2020-03-01 11:52:01 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\application\controllers\Api.php 487
ERROR - 2020-03-01 11:52:01 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\application\controllers\Api.php 487
ERROR - 2020-03-01 11:52:01 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\application\controllers\Api.php 487
ERROR - 2020-03-01 11:52:01 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\application\controllers\Api.php 487
ERROR - 2020-03-01 11:53:47 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\application\controllers\Api.php 487
ERROR - 2020-03-01 11:53:47 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\application\controllers\Api.php 487
ERROR - 2020-03-01 11:53:47 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\application\controllers\Api.php 487
ERROR - 2020-03-01 11:53:47 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\application\controllers\Api.php 487
ERROR - 2020-03-01 11:53:47 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\application\controllers\Api.php 487
ERROR - 2020-03-01 16:06:58 --> 404 Page Not Found: Api/getNutirtionists
ERROR - 2020-03-01 16:07:37 --> 404 Page Not Found: Api/getNutirtionists
ERROR - 2020-03-01 16:10:57 --> 404 Page Not Found: Api/getNutirtionists
