<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-11 05:50:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-02-11 07:44:58 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-02-11 07:44:59 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-02-11 18:59:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-02-11 18:59:11 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-02-11 18:59:11 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-02-11 21:16:05 --> 404 Page Not Found: Robotstxt/index
