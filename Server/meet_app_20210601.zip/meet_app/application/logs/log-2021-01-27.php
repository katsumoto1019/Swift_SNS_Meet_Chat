<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-27 01:27:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-01-27 04:56:27 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-01-27 07:46:08 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-01-27 07:46:09 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-01-27 08:41:56 --> 404 Page Not Found: Robotstxt/index
