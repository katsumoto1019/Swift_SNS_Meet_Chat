<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-10 00:25:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-01-10 06:25:45 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-01-10 07:42:47 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-01-10 07:42:48 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-01-10 10:01:32 --> 404 Page Not Found: Env/index
ERROR - 2021-01-10 22:48:51 --> 404 Page Not Found: Robotstxt/index
