<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-02 01:24:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-01-02 07:50:10 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-01-02 07:50:11 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-01-02 15:31:30 --> 404 Page Not Found: Wp_loginphp/index
