<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-07 00:31:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-01-07 03:22:15 --> 404 Page Not Found: Env/index
ERROR - 2021-01-07 07:47:12 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-01-07 07:47:13 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-01-07 08:13:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-01-07 12:44:14 --> 404 Page Not Found: Blog/index
