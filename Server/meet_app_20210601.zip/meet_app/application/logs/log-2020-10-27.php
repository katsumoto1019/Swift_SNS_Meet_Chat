<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-27 06:47:22 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-10-27 06:47:24 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-10-27 11:47:00 --> 404 Page Not Found: Robotstxt/index
