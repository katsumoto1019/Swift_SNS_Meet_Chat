<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-29 05:00:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-29 05:00:05 --> 404 Page Not Found: Wp_content/uploads
ERROR - 2020-06-29 06:19:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-29 06:19:12 --> 404 Page Not Found: Feed/index
ERROR - 2020-06-29 07:26:43 --> 404 Page Not Found: Logphp/index
ERROR - 2020-06-29 09:51:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-29 09:51:59 --> 404 Page Not Found: Wp_json/oembed
ERROR - 2020-06-29 13:03:46 --> 404 Page Not Found: Administrator/index.php
ERROR - 2020-06-29 13:36:01 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-06-29 13:36:06 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-06-29 13:52:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-29 13:57:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-29 13:57:35 --> 404 Page Not Found: Wp_content/uploads
ERROR - 2020-06-29 14:43:05 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-06-29 14:43:06 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-06-29 17:07:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-29 18:40:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-29 21:14:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-29 21:15:10 --> 404 Page Not Found: App_adstxt/index
ERROR - 2020-06-29 21:31:36 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-06-29 21:31:39 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-06-29 22:55:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-29 22:55:12 --> 404 Page Not Found: Robotstxt/index
