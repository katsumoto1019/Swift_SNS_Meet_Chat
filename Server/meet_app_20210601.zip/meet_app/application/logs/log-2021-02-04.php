<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-04 07:47:02 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-02-04 07:47:03 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-02-04 16:22:34 --> 404 Page Not Found: Robotstxt/index
