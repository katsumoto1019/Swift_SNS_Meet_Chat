<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-10 01:39:23 --> 404 Page Not Found: Apple_touch_icon_120x120_precomposedpng/index
ERROR - 2020-12-10 01:39:24 --> 404 Page Not Found: Apple_touch_icon_120x120png/index
ERROR - 2020-12-10 01:39:24 --> 404 Page Not Found: Apple_touch_iconpng/index
ERROR - 2020-12-10 01:39:24 --> 404 Page Not Found: Apple_touch_iconpng/index
ERROR - 2020-12-10 07:53:19 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-12-10 07:53:20 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-12-10 19:56:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-10 20:36:24 --> 404 Page Not Found: Wp_loginphp/index
