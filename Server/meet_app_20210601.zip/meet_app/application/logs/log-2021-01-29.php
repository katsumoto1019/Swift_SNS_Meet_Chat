<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-29 07:46:21 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-01-29 07:46:22 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-01-29 09:08:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-01-29 10:06:04 --> 404 Page Not Found: Wp_includes/wlwmanifest.xml
ERROR - 2021-01-29 10:06:04 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2021-01-29 10:06:05 --> 404 Page Not Found: Blog/wp_includes
ERROR - 2021-01-29 10:06:05 --> 404 Page Not Found: Web/wp_includes
ERROR - 2021-01-29 10:06:05 --> 404 Page Not Found: Wordpress/wp_includes
ERROR - 2021-01-29 10:06:05 --> 404 Page Not Found: Website/wp_includes
ERROR - 2021-01-29 10:06:05 --> 404 Page Not Found: Wp/wp_includes
ERROR - 2021-01-29 10:06:05 --> 404 Page Not Found: News/wp_includes
ERROR - 2021-01-29 10:06:05 --> 404 Page Not Found: 2018/wp_includes
ERROR - 2021-01-29 10:06:05 --> 404 Page Not Found: 2019/wp_includes
ERROR - 2021-01-29 10:06:06 --> 404 Page Not Found: Shop/wp_includes
ERROR - 2021-01-29 10:06:06 --> 404 Page Not Found: Wp1/wp_includes
ERROR - 2021-01-29 10:06:06 --> 404 Page Not Found: Test/wp_includes
ERROR - 2021-01-29 10:06:06 --> 404 Page Not Found: Media/wp_includes
ERROR - 2021-01-29 10:06:06 --> 404 Page Not Found: Wp2/wp_includes
ERROR - 2021-01-29 10:06:06 --> 404 Page Not Found: Site/wp_includes
ERROR - 2021-01-29 10:06:06 --> 404 Page Not Found: Cms/wp_includes
ERROR - 2021-01-29 10:06:06 --> 404 Page Not Found: Sito/wp_includes
ERROR - 2021-01-29 11:30:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-01-29 11:30:27 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-01-29 11:30:28 --> 404 Page Not Found: Adstxt/index
