<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-24 01:31:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-01-24 02:19:58 --> 404 Page Not Found: Git/config
ERROR - 2021-01-24 02:55:24 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-01-24 02:55:25 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-01-24 06:16:04 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-01-24 06:16:05 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-01-24 07:50:15 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-01-24 07:50:16 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-01-24 07:58:49 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-01-24 14:07:00 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-01-24 14:07:01 --> 404 Page Not Found: Wp_loginphp/index
