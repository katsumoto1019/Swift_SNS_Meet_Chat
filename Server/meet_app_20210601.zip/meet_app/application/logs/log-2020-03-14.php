<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-14 00:28:13 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-14 00:28:16 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-14 00:53:35 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-14 00:53:36 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-14 01:19:00 --> Severity: Notice --> Undefined index: categories C:\xampp\htdocs\application\controllers\Api.php 86
ERROR - 2020-03-14 01:19:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\controllers\Api.php 86
