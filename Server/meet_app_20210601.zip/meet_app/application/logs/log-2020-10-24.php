<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-24 06:54:11 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-10-24 06:54:12 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-10-24 10:23:58 --> 404 Page Not Found: Git/config
ERROR - 2020-10-24 10:24:00 --> 404 Page Not Found: Git/config
ERROR - 2020-10-24 18:34:45 --> 404 Page Not Found: Api/order
ERROR - 2020-10-24 18:40:01 --> 404 Page Not Found: Robotstxt/index
