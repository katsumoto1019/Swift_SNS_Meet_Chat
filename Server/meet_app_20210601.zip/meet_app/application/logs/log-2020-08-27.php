<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-27 00:10:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-08-27 10:31:46 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-08-27 15:21:52 --> 404 Page Not Found: Demo/wp_login.php
ERROR - 2020-08-27 21:01:01 --> 404 Page Not Found: Robotstxt/index
