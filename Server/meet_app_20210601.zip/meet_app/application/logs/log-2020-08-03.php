<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-03 05:50:18 --> 404 Page Not Found: Wordpress/wp_admin
ERROR - 2020-08-03 09:13:08 --> 404 Page Not Found: Wp_admin/install.php
