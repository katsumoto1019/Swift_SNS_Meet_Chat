<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-30 01:35:23 --> 404 Page Not Found: Wp_admin/admin_ajax.php
ERROR - 2020-09-30 01:35:24 --> 404 Page Not Found: Env/index
ERROR - 2020-09-30 01:35:25 --> 404 Page Not Found: Api/.env
ERROR - 2020-09-30 01:35:26 --> 404 Page Not Found: Laravel/.env
ERROR - 2020-09-30 01:35:27 --> 404 Page Not Found: Test/.env
ERROR - 2020-09-30 01:35:29 --> 404 Page Not Found: Admin/.env
ERROR - 2020-09-30 01:35:30 --> 404 Page Not Found: Vendor/.env
ERROR - 2020-09-30 01:35:31 --> 404 Page Not Found: Sites/.env
ERROR - 2020-09-30 01:35:32 --> 404 Page Not Found: Blog/.env
ERROR - 2020-09-30 01:35:33 --> 404 Page Not Found: System/.env
ERROR - 2020-09-30 01:35:33 --> 404 Page Not Found: Public/.env
ERROR - 2020-09-30 01:35:34 --> 404 Page Not Found: Shop/.env
ERROR - 2020-09-30 02:35:42 --> 404 Page Not Found: Adstxt/index
ERROR - 2020-09-30 02:35:59 --> 404 Page Not Found: App_adstxt/index
ERROR - 2020-09-30 05:58:21 --> 404 Page Not Found: Env/index
ERROR - 2020-09-30 09:08:01 --> 404 Page Not Found: Env/index
ERROR - 2020-09-30 18:34:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-09-30 18:34:54 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2020-09-30 20:33:40 --> 404 Page Not Found: Robotstxt/index
