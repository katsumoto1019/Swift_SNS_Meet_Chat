<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-12 22:43:14 --> Query error: Unknown column 'approve' in 'where clause' - Invalid query: SELECT *
FROM `tb_user`
WHERE `approve` = '0'
AND `type` = 'seller'
AND `profile_complete` = '1'
ERROR - 2020-07-12 22:44:07 --> Query error: Unknown column 'approve' in 'where clause' - Invalid query: SELECT *
FROM `tb_user`
WHERE `approve` = '0'
AND `type` = 'seller'
AND `profile_complete` = '1'
ERROR - 2020-07-12 22:45:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\application\controllers\Admin.php 198
ERROR - 2020-07-12 22:45:24 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-12 22:45:24 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-12 22:45:24 --> Severity: Notice --> Undefined variable: buyer_count C:\xampp\htdocs\application\views\admin\dashboard.php 24
ERROR - 2020-07-12 22:45:24 --> Severity: Notice --> Undefined variable: seller_count C:\xampp\htdocs\application\views\admin\dashboard.php 40
ERROR - 2020-07-12 22:45:24 --> Severity: Notice --> Undefined variable: approve_count C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-07-12 22:45:24 --> Severity: Notice --> Undefined variable: upcomming_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-12 22:45:24 --> Severity: Notice --> Undefined variable: complete_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-12 22:45:24 --> Severity: Notice --> Undefined variable: refund C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-12 22:45:24 --> Severity: Notice --> Undefined variable: total_amount C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-12 22:51:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\application\controllers\Admin.php 198
ERROR - 2020-07-12 22:51:53 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-12 22:51:53 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-12 22:51:53 --> Severity: Notice --> Undefined variable: buyer_count C:\xampp\htdocs\application\views\admin\dashboard.php 24
ERROR - 2020-07-12 22:51:53 --> Severity: Notice --> Undefined variable: seller_count C:\xampp\htdocs\application\views\admin\dashboard.php 40
ERROR - 2020-07-12 22:51:53 --> Severity: Notice --> Undefined variable: approve_count C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-07-12 22:51:53 --> Severity: Notice --> Undefined variable: upcomming_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-12 22:51:53 --> Severity: Notice --> Undefined variable: complete_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-12 22:51:53 --> Severity: Notice --> Undefined variable: refund C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-12 22:51:53 --> Severity: Notice --> Undefined variable: total_amount C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-12 22:52:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\application\controllers\Admin.php 198
ERROR - 2020-07-12 22:52:25 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-12 22:52:25 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-12 22:52:25 --> Severity: Notice --> Undefined variable: buyer_count C:\xampp\htdocs\application\views\admin\dashboard.php 24
ERROR - 2020-07-12 22:52:25 --> Severity: Notice --> Undefined variable: seller_count C:\xampp\htdocs\application\views\admin\dashboard.php 40
ERROR - 2020-07-12 22:52:25 --> Severity: Notice --> Undefined variable: approve_count C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-07-12 22:52:25 --> Severity: Notice --> Undefined variable: upcomming_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-12 22:52:25 --> Severity: Notice --> Undefined variable: complete_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-12 22:52:25 --> Severity: Notice --> Undefined variable: refund C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-12 22:52:25 --> Severity: Notice --> Undefined variable: total_amount C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-12 22:52:37 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\application\controllers\Admin.php 198
ERROR - 2020-07-12 22:52:37 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-12 22:52:37 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-12 22:52:37 --> Severity: Notice --> Undefined variable: buyer_count C:\xampp\htdocs\application\views\admin\dashboard.php 24
ERROR - 2020-07-12 22:52:37 --> Severity: Notice --> Undefined variable: seller_count C:\xampp\htdocs\application\views\admin\dashboard.php 40
ERROR - 2020-07-12 22:52:37 --> Severity: Notice --> Undefined variable: approve_count C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-07-12 22:52:37 --> Severity: Notice --> Undefined variable: upcomming_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-12 22:52:37 --> Severity: Notice --> Undefined variable: complete_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-12 22:52:37 --> Severity: Notice --> Undefined variable: refund C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-12 22:52:37 --> Severity: Notice --> Undefined variable: total_amount C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-12 22:58:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\application\controllers\Admin.php 198
ERROR - 2020-07-12 22:58:28 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-12 22:58:28 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-12 22:58:28 --> Severity: Notice --> Undefined variable: buyer_count C:\xampp\htdocs\application\views\admin\dashboard.php 24
ERROR - 2020-07-12 22:58:28 --> Severity: Notice --> Undefined variable: seller_count C:\xampp\htdocs\application\views\admin\dashboard.php 40
ERROR - 2020-07-12 22:58:28 --> Severity: Notice --> Undefined variable: approve_count C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-07-12 22:58:28 --> Severity: Notice --> Undefined variable: upcomming_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-12 22:58:28 --> Severity: Notice --> Undefined variable: complete_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-12 22:58:28 --> Severity: Notice --> Undefined variable: refund C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-12 22:58:28 --> Severity: Notice --> Undefined variable: total_amount C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-12 22:59:09 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\application\controllers\Admin.php 198
ERROR - 2020-07-12 22:59:09 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-12 22:59:09 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-12 22:59:09 --> Severity: Notice --> Undefined variable: buyer_count C:\xampp\htdocs\application\views\admin\dashboard.php 24
ERROR - 2020-07-12 22:59:09 --> Severity: Notice --> Undefined variable: seller_count C:\xampp\htdocs\application\views\admin\dashboard.php 40
ERROR - 2020-07-12 22:59:09 --> Severity: Notice --> Undefined variable: approve_count C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-07-12 22:59:09 --> Severity: Notice --> Undefined variable: upcomming_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-12 22:59:09 --> Severity: Notice --> Undefined variable: complete_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-12 22:59:09 --> Severity: Notice --> Undefined variable: refund C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-12 22:59:09 --> Severity: Notice --> Undefined variable: total_amount C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-12 23:00:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\application\controllers\Admin.php 198
ERROR - 2020-07-12 23:00:04 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-12 23:00:04 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-12 23:00:04 --> Severity: Notice --> Undefined variable: buyer_count C:\xampp\htdocs\application\views\admin\dashboard.php 24
ERROR - 2020-07-12 23:00:04 --> Severity: Notice --> Undefined variable: seller_count C:\xampp\htdocs\application\views\admin\dashboard.php 40
ERROR - 2020-07-12 23:00:04 --> Severity: Notice --> Undefined variable: approve_count C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-07-12 23:00:04 --> Severity: Notice --> Undefined variable: upcomming_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-12 23:00:04 --> Severity: Notice --> Undefined variable: complete_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-12 23:00:04 --> Severity: Notice --> Undefined variable: refund C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-12 23:00:04 --> Severity: Notice --> Undefined variable: total_amount C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-12 23:01:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\application\controllers\Admin.php 198
ERROR - 2020-07-12 23:01:57 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-12 23:01:57 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-12 23:01:57 --> Severity: Notice --> Undefined variable: buyer_count C:\xampp\htdocs\application\views\admin\dashboard.php 24
ERROR - 2020-07-12 23:01:57 --> Severity: Notice --> Undefined variable: seller_count C:\xampp\htdocs\application\views\admin\dashboard.php 40
ERROR - 2020-07-12 23:01:57 --> Severity: Notice --> Undefined variable: approve_count C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-07-12 23:01:57 --> Severity: Notice --> Undefined variable: upcomming_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-12 23:01:57 --> Severity: Notice --> Undefined variable: complete_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-12 23:01:57 --> Severity: Notice --> Undefined variable: refund C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-12 23:01:57 --> Severity: Notice --> Undefined variable: total_amount C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-12 23:06:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\application\controllers\Admin.php 198
ERROR - 2020-07-12 23:06:20 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-12 23:06:20 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-12 23:06:20 --> Severity: Notice --> Undefined variable: buyer_count C:\xampp\htdocs\application\views\admin\dashboard.php 24
ERROR - 2020-07-12 23:06:20 --> Severity: Notice --> Undefined variable: seller_count C:\xampp\htdocs\application\views\admin\dashboard.php 40
ERROR - 2020-07-12 23:06:20 --> Severity: Notice --> Undefined variable: approve_count C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-07-12 23:06:20 --> Severity: Notice --> Undefined variable: upcomming_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-12 23:06:20 --> Severity: Notice --> Undefined variable: complete_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-12 23:06:20 --> Severity: Notice --> Undefined variable: refund C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-12 23:06:20 --> Severity: Notice --> Undefined variable: total_amount C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-12 23:18:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\application\controllers\Admin.php 198
ERROR - 2020-07-12 23:18:11 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-12 23:18:11 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-12 23:18:11 --> Severity: Notice --> Undefined variable: buyer_count C:\xampp\htdocs\application\views\admin\dashboard.php 24
ERROR - 2020-07-12 23:18:11 --> Severity: Notice --> Undefined variable: seller_count C:\xampp\htdocs\application\views\admin\dashboard.php 40
ERROR - 2020-07-12 23:18:11 --> Severity: Notice --> Undefined variable: approve_count C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-07-12 23:18:11 --> Severity: Notice --> Undefined variable: upcomming_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-12 23:18:11 --> Severity: Notice --> Undefined variable: complete_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-12 23:18:11 --> Severity: Notice --> Undefined variable: refund C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-12 23:18:11 --> Severity: Notice --> Undefined variable: total_amount C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-12 23:20:01 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-12 23:20:01 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-12 23:20:01 --> Severity: Notice --> Undefined variable: buyer_count C:\xampp\htdocs\application\views\admin\dashboard.php 24
ERROR - 2020-07-12 23:20:01 --> Severity: Notice --> Undefined variable: seller_count C:\xampp\htdocs\application\views\admin\dashboard.php 40
ERROR - 2020-07-12 23:20:01 --> Severity: Notice --> Undefined variable: approve_count C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-07-12 23:20:01 --> Severity: Notice --> Undefined variable: upcomming_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-12 23:20:01 --> Severity: Notice --> Undefined variable: complete_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-12 23:20:01 --> Severity: Notice --> Undefined variable: refund C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-12 23:20:01 --> Severity: Notice --> Undefined variable: total_amount C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-12 23:21:04 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-12 23:21:04 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-12 23:21:04 --> Severity: Notice --> Undefined variable: buyer_count C:\xampp\htdocs\application\views\admin\dashboard.php 24
ERROR - 2020-07-12 23:21:04 --> Severity: Notice --> Undefined variable: seller_count C:\xampp\htdocs\application\views\admin\dashboard.php 40
ERROR - 2020-07-12 23:21:04 --> Severity: Notice --> Undefined variable: approve_count C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-07-12 23:21:04 --> Severity: Notice --> Undefined variable: upcomming_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-12 23:21:04 --> Severity: Notice --> Undefined variable: complete_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-12 23:21:04 --> Severity: Notice --> Undefined variable: refund C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-12 23:21:04 --> Severity: Notice --> Undefined variable: total_amount C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-12 23:24:39 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-12 23:24:39 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-12 23:24:39 --> Severity: Notice --> Undefined variable: buyer_count C:\xampp\htdocs\application\views\admin\dashboard.php 24
ERROR - 2020-07-12 23:24:39 --> Severity: Notice --> Undefined variable: seller_count C:\xampp\htdocs\application\views\admin\dashboard.php 40
ERROR - 2020-07-12 23:24:39 --> Severity: Notice --> Undefined variable: approve_count C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-07-12 23:24:39 --> Severity: Notice --> Undefined variable: upcomming_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-12 23:24:39 --> Severity: Notice --> Undefined variable: complete_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-12 23:24:39 --> Severity: Notice --> Undefined variable: refund C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-12 23:24:39 --> Severity: Notice --> Undefined variable: total_amount C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-12 23:28:31 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-12 23:28:31 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-12 23:28:31 --> Severity: Notice --> Undefined variable: buyer_count C:\xampp\htdocs\application\views\admin\dashboard.php 24
ERROR - 2020-07-12 23:28:31 --> Severity: Notice --> Undefined variable: seller_count C:\xampp\htdocs\application\views\admin\dashboard.php 40
ERROR - 2020-07-12 23:28:31 --> Severity: Notice --> Undefined variable: approve_count C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-07-12 23:28:31 --> Severity: Notice --> Undefined variable: upcomming_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-12 23:28:31 --> Severity: Notice --> Undefined variable: complete_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-12 23:28:31 --> Severity: Notice --> Undefined variable: refund C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-12 23:28:31 --> Severity: Notice --> Undefined variable: total_amount C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-12 23:29:14 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-12 23:29:14 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-12 23:29:14 --> Severity: Notice --> Undefined variable: buyer_count C:\xampp\htdocs\application\views\admin\dashboard.php 24
ERROR - 2020-07-12 23:29:14 --> Severity: Notice --> Undefined variable: seller_count C:\xampp\htdocs\application\views\admin\dashboard.php 40
ERROR - 2020-07-12 23:29:14 --> Severity: Notice --> Undefined variable: approve_count C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-07-12 23:29:14 --> Severity: Notice --> Undefined variable: upcomming_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-12 23:29:14 --> Severity: Notice --> Undefined variable: complete_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-12 23:29:14 --> Severity: Notice --> Undefined variable: refund C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-12 23:29:14 --> Severity: Notice --> Undefined variable: total_amount C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-12 23:33:54 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-12 23:33:54 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-12 23:33:54 --> Severity: Notice --> Undefined variable: buyer_count C:\xampp\htdocs\application\views\admin\dashboard.php 24
ERROR - 2020-07-12 23:33:54 --> Severity: Notice --> Undefined variable: seller_count C:\xampp\htdocs\application\views\admin\dashboard.php 40
ERROR - 2020-07-12 23:33:54 --> Severity: Notice --> Undefined variable: approve_count C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-07-12 23:33:54 --> Severity: Notice --> Undefined variable: upcomming_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-12 23:33:54 --> Severity: Notice --> Undefined variable: complete_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-12 23:33:54 --> Severity: Notice --> Undefined variable: refund C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-12 23:33:54 --> Severity: Notice --> Undefined variable: total_amount C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-12 23:34:05 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-12 23:34:05 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-12 23:34:05 --> Severity: Notice --> Undefined variable: buyer_count C:\xampp\htdocs\application\views\admin\dashboard.php 24
ERROR - 2020-07-12 23:34:05 --> Severity: Notice --> Undefined variable: seller_count C:\xampp\htdocs\application\views\admin\dashboard.php 40
ERROR - 2020-07-12 23:34:05 --> Severity: Notice --> Undefined variable: approve_count C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-07-12 23:34:05 --> Severity: Notice --> Undefined variable: upcomming_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-12 23:34:05 --> Severity: Notice --> Undefined variable: complete_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-12 23:34:05 --> Severity: Notice --> Undefined variable: refund C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-12 23:34:05 --> Severity: Notice --> Undefined variable: total_amount C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-12 23:37:02 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-12 23:37:02 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-12 23:37:02 --> Severity: Notice --> Undefined variable: buyer_count C:\xampp\htdocs\application\views\admin\dashboard.php 24
ERROR - 2020-07-12 23:37:02 --> Severity: Notice --> Undefined variable: seller_count C:\xampp\htdocs\application\views\admin\dashboard.php 40
ERROR - 2020-07-12 23:37:02 --> Severity: Notice --> Undefined variable: approve_count C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-07-12 23:37:02 --> Severity: Notice --> Undefined variable: upcomming_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-12 23:37:02 --> Severity: Notice --> Undefined variable: complete_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-12 23:37:02 --> Severity: Notice --> Undefined variable: refund C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-12 23:37:02 --> Severity: Notice --> Undefined variable: total_amount C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-12 23:39:06 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-12 23:39:06 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-12 23:39:06 --> Severity: Notice --> Undefined variable: buyer_count C:\xampp\htdocs\application\views\admin\dashboard.php 24
ERROR - 2020-07-12 23:39:06 --> Severity: Notice --> Undefined variable: seller_count C:\xampp\htdocs\application\views\admin\dashboard.php 40
ERROR - 2020-07-12 23:39:06 --> Severity: Notice --> Undefined variable: approve_count C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-07-12 23:39:06 --> Severity: Notice --> Undefined variable: upcomming_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-12 23:39:06 --> Severity: Notice --> Undefined variable: complete_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-12 23:39:06 --> Severity: Notice --> Undefined variable: refund C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-12 23:39:06 --> Severity: Notice --> Undefined variable: total_amount C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-12 23:39:23 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-12 23:39:23 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-12 23:39:31 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-12 23:39:31 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-12 23:39:33 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-12 23:39:33 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-12 23:39:43 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-12 23:39:43 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-12 23:39:43 --> Severity: Notice --> Undefined variable: buyer_count C:\xampp\htdocs\application\views\admin\dashboard.php 24
ERROR - 2020-07-12 23:39:43 --> Severity: Notice --> Undefined variable: seller_count C:\xampp\htdocs\application\views\admin\dashboard.php 40
ERROR - 2020-07-12 23:39:43 --> Severity: Notice --> Undefined variable: approve_count C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-07-12 23:39:43 --> Severity: Notice --> Undefined variable: upcomming_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-12 23:39:43 --> Severity: Notice --> Undefined variable: complete_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-12 23:39:43 --> Severity: Notice --> Undefined variable: refund C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-12 23:39:43 --> Severity: Notice --> Undefined variable: total_amount C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-12 23:40:53 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-12 23:40:53 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-12 23:40:53 --> Severity: Notice --> Undefined variable: buyer_count C:\xampp\htdocs\application\views\admin\dashboard.php 24
ERROR - 2020-07-12 23:40:53 --> Severity: Notice --> Undefined variable: seller_count C:\xampp\htdocs\application\views\admin\dashboard.php 40
ERROR - 2020-07-12 23:40:53 --> Severity: Notice --> Undefined variable: approve_count C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-07-12 23:40:53 --> Severity: Notice --> Undefined variable: upcomming_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-12 23:40:53 --> Severity: Notice --> Undefined variable: complete_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-12 23:40:53 --> Severity: Notice --> Undefined variable: refund C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-12 23:40:53 --> Severity: Notice --> Undefined variable: total_amount C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-12 23:41:08 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-12 23:41:08 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-12 23:41:08 --> Severity: Notice --> Undefined variable: buyer_count C:\xampp\htdocs\application\views\admin\dashboard.php 24
ERROR - 2020-07-12 23:41:08 --> Severity: Notice --> Undefined variable: seller_count C:\xampp\htdocs\application\views\admin\dashboard.php 40
ERROR - 2020-07-12 23:41:08 --> Severity: Notice --> Undefined variable: approve_count C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-07-12 23:41:08 --> Severity: Notice --> Undefined variable: upcomming_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-12 23:41:08 --> Severity: Notice --> Undefined variable: complete_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-12 23:41:08 --> Severity: Notice --> Undefined variable: refund C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-12 23:41:08 --> Severity: Notice --> Undefined variable: total_amount C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-12 23:41:20 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-12 23:41:20 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-12 23:41:20 --> Severity: Notice --> Undefined variable: buyer_count C:\xampp\htdocs\application\views\admin\dashboard.php 24
ERROR - 2020-07-12 23:41:20 --> Severity: Notice --> Undefined variable: seller_count C:\xampp\htdocs\application\views\admin\dashboard.php 40
ERROR - 2020-07-12 23:41:20 --> Severity: Notice --> Undefined variable: approve_count C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-07-12 23:41:20 --> Severity: Notice --> Undefined variable: upcomming_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-12 23:41:20 --> Severity: Notice --> Undefined variable: complete_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-12 23:41:20 --> Severity: Notice --> Undefined variable: refund C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-12 23:41:20 --> Severity: Notice --> Undefined variable: total_amount C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-12 23:41:30 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-12 23:41:30 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-12 23:41:30 --> Severity: Notice --> Undefined variable: buyer_count C:\xampp\htdocs\application\views\admin\dashboard.php 24
ERROR - 2020-07-12 23:41:30 --> Severity: Notice --> Undefined variable: seller_count C:\xampp\htdocs\application\views\admin\dashboard.php 40
ERROR - 2020-07-12 23:41:30 --> Severity: Notice --> Undefined variable: approve_count C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-07-12 23:41:30 --> Severity: Notice --> Undefined variable: upcomming_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-12 23:41:30 --> Severity: Notice --> Undefined variable: complete_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-12 23:41:30 --> Severity: Notice --> Undefined variable: refund C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-12 23:41:30 --> Severity: Notice --> Undefined variable: total_amount C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-12 23:41:34 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-12 23:41:34 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-12 23:41:50 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-12 23:41:50 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-12 23:41:50 --> Severity: Notice --> Undefined variable: buyer_count C:\xampp\htdocs\application\views\admin\dashboard.php 24
ERROR - 2020-07-12 23:41:50 --> Severity: Notice --> Undefined variable: seller_count C:\xampp\htdocs\application\views\admin\dashboard.php 40
ERROR - 2020-07-12 23:41:50 --> Severity: Notice --> Undefined variable: approve_count C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-07-12 23:41:50 --> Severity: Notice --> Undefined variable: upcomming_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-12 23:41:50 --> Severity: Notice --> Undefined variable: complete_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-12 23:41:50 --> Severity: Notice --> Undefined variable: refund C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-12 23:41:50 --> Severity: Notice --> Undefined variable: total_amount C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-12 23:41:55 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-12 23:41:55 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-12 23:42:04 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-12 23:42:04 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-12 23:42:04 --> Severity: Notice --> Undefined variable: buyer_count C:\xampp\htdocs\application\views\admin\dashboard.php 24
ERROR - 2020-07-12 23:42:04 --> Severity: Notice --> Undefined variable: seller_count C:\xampp\htdocs\application\views\admin\dashboard.php 40
ERROR - 2020-07-12 23:42:04 --> Severity: Notice --> Undefined variable: approve_count C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-07-12 23:42:04 --> Severity: Notice --> Undefined variable: upcomming_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-12 23:42:04 --> Severity: Notice --> Undefined variable: complete_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-12 23:42:04 --> Severity: Notice --> Undefined variable: refund C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-12 23:42:04 --> Severity: Notice --> Undefined variable: total_amount C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-12 23:45:30 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-12 23:45:30 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-12 23:45:30 --> Severity: Notice --> Undefined variable: buyer_count C:\xampp\htdocs\application\views\admin\dashboard.php 24
ERROR - 2020-07-12 23:45:30 --> Severity: Notice --> Undefined variable: seller_count C:\xampp\htdocs\application\views\admin\dashboard.php 40
ERROR - 2020-07-12 23:45:30 --> Severity: Notice --> Undefined variable: approve_count C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-07-12 23:45:30 --> Severity: Notice --> Undefined variable: upcomming_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-12 23:45:30 --> Severity: Notice --> Undefined variable: complete_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-12 23:45:30 --> Severity: Notice --> Undefined variable: refund C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-12 23:45:30 --> Severity: Notice --> Undefined variable: total_amount C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-12 23:45:37 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-12 23:45:37 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-12 23:45:37 --> Severity: Notice --> Undefined variable: buyer_count C:\xampp\htdocs\application\views\admin\dashboard.php 24
ERROR - 2020-07-12 23:45:37 --> Severity: Notice --> Undefined variable: seller_count C:\xampp\htdocs\application\views\admin\dashboard.php 40
ERROR - 2020-07-12 23:45:37 --> Severity: Notice --> Undefined variable: approve_count C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-07-12 23:45:37 --> Severity: Notice --> Undefined variable: upcomming_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-12 23:45:37 --> Severity: Notice --> Undefined variable: complete_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-12 23:45:37 --> Severity: Notice --> Undefined variable: refund C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-12 23:45:37 --> Severity: Notice --> Undefined variable: total_amount C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-12 23:45:58 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-12 23:45:58 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-12 23:45:58 --> Severity: Notice --> Undefined variable: buyer_count C:\xampp\htdocs\application\views\admin\dashboard.php 24
ERROR - 2020-07-12 23:45:58 --> Severity: Notice --> Undefined variable: seller_count C:\xampp\htdocs\application\views\admin\dashboard.php 40
ERROR - 2020-07-12 23:45:58 --> Severity: Notice --> Undefined variable: approve_count C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-07-12 23:45:58 --> Severity: Notice --> Undefined variable: upcomming_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-12 23:45:58 --> Severity: Notice --> Undefined variable: complete_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-12 23:45:58 --> Severity: Notice --> Undefined variable: refund C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-12 23:45:58 --> Severity: Notice --> Undefined variable: total_amount C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-12 23:46:14 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-12 23:46:14 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-12 23:46:14 --> Severity: Notice --> Undefined variable: buyer_count C:\xampp\htdocs\application\views\admin\dashboard.php 24
ERROR - 2020-07-12 23:46:14 --> Severity: Notice --> Undefined variable: seller_count C:\xampp\htdocs\application\views\admin\dashboard.php 40
ERROR - 2020-07-12 23:46:14 --> Severity: Notice --> Undefined variable: approve_count C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-07-12 23:46:14 --> Severity: Notice --> Undefined variable: upcomming_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-12 23:46:14 --> Severity: Notice --> Undefined variable: complete_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-12 23:46:14 --> Severity: Notice --> Undefined variable: refund C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-12 23:46:14 --> Severity: Notice --> Undefined variable: total_amount C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-12 23:47:06 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-12 23:47:06 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-12 23:47:06 --> Severity: Notice --> Undefined variable: buyer_count C:\xampp\htdocs\application\views\admin\dashboard.php 24
ERROR - 2020-07-12 23:47:06 --> Severity: Notice --> Undefined variable: seller_count C:\xampp\htdocs\application\views\admin\dashboard.php 40
ERROR - 2020-07-12 23:47:06 --> Severity: Notice --> Undefined variable: approve_count C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-07-12 23:47:06 --> Severity: Notice --> Undefined variable: upcomming_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-12 23:47:06 --> Severity: Notice --> Undefined variable: complete_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-12 23:47:06 --> Severity: Notice --> Undefined variable: refund C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-12 23:47:06 --> Severity: Notice --> Undefined variable: total_amount C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-12 23:47:15 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-12 23:47:15 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-12 23:47:15 --> Severity: Notice --> Undefined variable: buyer_count C:\xampp\htdocs\application\views\admin\dashboard.php 24
ERROR - 2020-07-12 23:47:15 --> Severity: Notice --> Undefined variable: seller_count C:\xampp\htdocs\application\views\admin\dashboard.php 40
ERROR - 2020-07-12 23:47:15 --> Severity: Notice --> Undefined variable: approve_count C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-07-12 23:47:15 --> Severity: Notice --> Undefined variable: upcomming_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-12 23:47:15 --> Severity: Notice --> Undefined variable: complete_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-12 23:47:15 --> Severity: Notice --> Undefined variable: refund C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-12 23:47:15 --> Severity: Notice --> Undefined variable: total_amount C:\xampp\htdocs\application\views\admin\dashboard.php 135
