<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-03 06:59:39 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-11-03 06:59:40 --> 404 Page Not Found: 404javascriptjs/index
