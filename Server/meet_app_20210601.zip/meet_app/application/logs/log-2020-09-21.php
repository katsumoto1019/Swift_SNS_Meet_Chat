<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-21 06:13:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-09-21 06:14:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-09-21 06:14:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-09-21 06:14:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-09-21 06:14:01 --> 404 Page Not Found: Robotstxt/index
