<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-16 07:49:04 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-11-16 07:49:04 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-11-16 11:17:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-16 16:51:46 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-11-16 18:38:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-16 19:23:43 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-11-16 21:42:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-16 21:42:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-16 21:42:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-16 21:42:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-16 23:50:09 --> 404 Page Not Found: Robotstxt/index
