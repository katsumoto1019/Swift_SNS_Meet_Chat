<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-20 12:25:59 --> 404 Page Not Found: Manifestjson/index
