<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-17 01:15:00 --> 404 Page Not Found: __media__/js
ERROR - 2021-03-17 06:37:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-03-17 06:44:07 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-03-17 06:44:08 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-03-17 09:03:27 --> 404 Page Not Found: Upsphp/index
ERROR - 2021-03-17 18:36:18 --> 404 Page Not Found: Docphp/index
ERROR - 2021-03-17 22:13:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-03-17 22:13:31 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-03-17 22:13:31 --> 404 Page Not Found: Adstxt/index
