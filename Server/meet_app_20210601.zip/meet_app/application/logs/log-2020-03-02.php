<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-02 03:45:33 --> Severity: Notice --> Undefined index: categories C:\xampp\htdocs\application\controllers\Api.php 81
ERROR - 2020-03-02 03:45:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\controllers\Api.php 81
ERROR - 2020-03-02 05:38:21 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-02 05:38:24 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-02 05:42:18 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-02 05:42:34 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-02 05:42:42 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-02 18:13:16 --> Severity: Notice --> Undefined index: categories C:\xampp\htdocs\application\controllers\Api.php 81
ERROR - 2020-03-02 18:13:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\controllers\Api.php 81
ERROR - 2020-03-02 22:00:04 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-02 22:00:06 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-02 22:00:12 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-02 22:04:11 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-02 23:28:08 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-02 23:28:14 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-02 23:28:16 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-02 23:28:25 --> 404 Page Not Found: Manifestjson/index
