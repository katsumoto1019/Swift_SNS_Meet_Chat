<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-27 01:26:54 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 01:28:18 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 01:28:33 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 01:31:02 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 01:31:10 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 01:32:45 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 01:32:45 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 01:32:45 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 01:32:45 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 01:32:45 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 01:32:45 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 01:32:45 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 01:32:48 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 01:32:48 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 01:32:48 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 01:32:48 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 01:32:48 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 01:32:48 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 01:32:48 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 01:32:48 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 01:32:48 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 01:32:50 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 01:32:50 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 01:32:50 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 01:32:50 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 01:32:50 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 01:32:50 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 01:32:51 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 01:32:52 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 01:32:52 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 01:32:52 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 01:32:52 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 01:32:52 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 01:32:52 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 01:32:52 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 01:32:52 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 01:32:52 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 01:32:55 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 01:32:55 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 01:32:55 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 01:32:55 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 01:32:55 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 01:32:55 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 01:32:55 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 01:32:56 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 01:32:56 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 01:38:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 01:38:09 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 01:41:18 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 01:41:21 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 01:41:25 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 01:41:27 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 01:41:46 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 01:43:00 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 01:43:03 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 01:45:14 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 01:46:27 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 01:46:54 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 01:47:38 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 01:47:55 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 01:48:05 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 01:49:46 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 01:50:17 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 01:50:31 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 01:50:45 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 01:50:58 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 01:51:28 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 01:51:54 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 01:52:25 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 01:59:17 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 02:00:21 --> 404 Page Not Found: Admin/categories
ERROR - 2019-12-27 02:01:12 --> 404 Page Not Found: Admin/categories
ERROR - 2019-12-27 02:01:17 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 02:01:58 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 02:02:18 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 02:02:26 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:02:26 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:02:26 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:02:26 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:02:26 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:02:27 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:02:27 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:02:27 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:02:27 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:02:29 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:02:29 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:02:29 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:02:29 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:02:29 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:02:29 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:02:29 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:02:29 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:02:29 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:13:40 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 01:13:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\application\views\admin\edit_categories.php 23
ERROR - 2019-12-27 01:13:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\edit_categories.php 23
ERROR - 2019-12-27 02:13:51 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 02:14:19 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 01:14:20 --> Severity: error --> Exception: Call to undefined method Admin_model::get_salebalance_byuser() C:\xampp\htdocs\application\controllers\Admin.php 733
ERROR - 2019-12-27 02:14:22 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 02:14:43 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 01:14:54 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\application\views\admin\edit_categories.php 23
ERROR - 2019-12-27 01:14:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\edit_categories.php 23
ERROR - 2019-12-27 02:14:54 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 02:14:59 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 01:15:01 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\application\views\admin\edit_categories.php 23
ERROR - 2019-12-27 01:15:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\edit_categories.php 23
ERROR - 2019-12-27 02:15:01 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 02:15:02 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 01:15:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\application\views\admin\edit_categories.php 23
ERROR - 2019-12-27 01:15:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\edit_categories.php 23
ERROR - 2019-12-27 02:15:05 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 02:15:06 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 02:16:15 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 02:16:17 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 02:16:43 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 01:16:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\application\views\admin\edit_categories.php 23
ERROR - 2019-12-27 01:16:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\edit_categories.php 23
ERROR - 2019-12-27 02:16:50 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 02:16:58 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:16:58 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:16:58 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:16:58 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:16:58 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:16:58 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:16:58 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:16:58 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:16:59 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:17:02 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:17:02 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:17:02 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:17:02 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:17:02 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:17:02 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:17:02 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:17:02 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:17:02 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 01:22:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\application\views\admin\edit_categories.php 23
ERROR - 2019-12-27 01:22:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\edit_categories.php 23
ERROR - 2019-12-27 02:22:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 01:22:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\application\views\admin\edit_categories.php 23
ERROR - 2019-12-27 01:22:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\edit_categories.php 23
ERROR - 2019-12-27 02:22:08 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 01:22:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\application\views\admin\edit_categories.php 23
ERROR - 2019-12-27 01:22:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\edit_categories.php 23
ERROR - 2019-12-27 02:22:11 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 02:22:12 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 01:22:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\application\views\admin\edit_categories.php 23
ERROR - 2019-12-27 01:22:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\edit_categories.php 23
ERROR - 2019-12-27 02:22:14 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 01:22:46 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\application\views\admin\edit_categories.php 23
ERROR - 2019-12-27 02:22:46 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 02:22:49 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 01:22:51 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\application\views\admin\edit_categories.php 23
ERROR - 2019-12-27 02:22:51 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 01:23:42 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\application\controllers\Admin.php 136
ERROR - 2019-12-27 01:23:42 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\application\views\admin\edit_categories.php 23
ERROR - 2019-12-27 01:24:12 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\application\views\admin\edit_categories.php 23
ERROR - 2019-12-27 02:32:05 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 02:32:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 01:32:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`Fruit` = ''
WHERE `id` = '3'' at line 1 - Invalid query: UPDATE `tb_categories` SET `Low Calorie` `Fruit` = ''
WHERE `id` = '3'
ERROR - 2019-12-27 02:53:39 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 01:53:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`CalorieFruit` = ''
WHERE `id` = '3'' at line 1 - Invalid query: UPDATE `tb_categories` SET `Low` `CalorieFruit` = ''
WHERE `id` = '3'
ERROR - 2019-12-27 02:54:19 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 02:55:42 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:55:42 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:55:42 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:55:42 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:55:42 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:55:42 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:55:42 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:55:42 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:55:42 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:55:52 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:55:52 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:55:52 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:55:52 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:55:52 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:55:52 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:55:53 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:55:53 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:55:53 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:55:58 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:55:58 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:55:58 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 02:56:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 02:56:08 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 02:01:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`Fruits` = ''
WHERE `id` = '3'' at line 1 - Invalid query: UPDATE `tb_categories` SET `Low Calorie` `Fruits` = ''
WHERE `id` = '3'
ERROR - 2019-12-27 03:15:45 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 03:15:54 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 03:19:24 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 03:19:24 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 03:19:24 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 03:19:24 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 03:19:24 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 03:19:24 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 03:19:24 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 03:19:24 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 03:19:24 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 03:19:28 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 03:19:28 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 03:19:28 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 03:20:18 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 03:20:18 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 03:20:18 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 03:20:18 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 03:20:18 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 03:20:18 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 03:20:19 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 03:20:19 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 03:33:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 03:33:29 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 03:33:38 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 03:34:59 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 03:36:29 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 02:36:31 --> Query error: Table 'foodtrack.tb_categories2' doesn't exist - Invalid query: DELETE FROM `tb_categories2`
WHERE 3 IS NULL
ERROR - 2019-12-27 03:39:19 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 03:39:21 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 02:39:23 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\application\controllers\Admin.php 155
ERROR - 2019-12-27 03:39:24 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 03:39:42 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 03:39:44 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 03:40:01 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 03:40:06 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 03:48:10 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 03:48:29 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 03:49:09 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 02:50:30 --> Query error: Table 'foodtrack.tb_minprice' doesn't exist - Invalid query: SELECT *
FROM `tb_minprice`
ORDER BY `id` DESC
ERROR - 2019-12-27 03:50:32 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 03:52:48 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:05:58 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:06:08 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:06:12 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:08:44 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:08:54 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:21:23 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:21:28 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:21:33 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:21:36 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:21:39 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:21:55 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:27:18 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 03:27:20 --> Severity: Notice --> Undefined variable: brakfast C:\xampp\htdocs\application\views\admin\breakfast.php 56
ERROR - 2019-12-27 03:27:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\breakfast.php 56
ERROR - 2019-12-27 04:27:20 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:28:16 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:28:19 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:29:34 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:29:39 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:30:09 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:30:11 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:30:12 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:30:57 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 03:31:01 --> Query error: Table 'foodtrack.tb_breakfast' doesn't exist - Invalid query: SELECT *
FROM `tb_breakfast`
WHERE `id` = '1'
ERROR - 2019-12-27 04:31:56 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:32:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:32:09 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:32:13 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:32:17 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:34:37 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:34:44 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:34:48 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:34:50 --> 404 Page Not Found: Admin/2
ERROR - 2019-12-27 04:34:58 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:35:37 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:35:39 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:36:32 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:36:36 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:46:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:46:12 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:46:22 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:47:00 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:47:03 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:47:05 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:47:08 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:47:14 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:47:17 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:47:24 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:47:26 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:47:29 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:47:31 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:47:42 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:52:43 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:52:46 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:52:52 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:52:56 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:52:57 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:53:01 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:54:15 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:54:17 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:54:19 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:54:21 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:54:27 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:54:28 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:54:43 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 04:59:40 --> Severity: Compile Error --> Cannot redeclare Admin::edit_firstsnack() C:\xampp\htdocs\application\controllers\Admin.php 306
ERROR - 2019-12-27 05:00:24 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:00:29 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:00:32 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:00:38 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:00:39 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:00:40 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:00:41 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:00:42 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:00:42 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:00:43 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:00:44 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:00:47 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:00:50 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:01:40 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:01:44 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:01:45 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:01:48 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:01:50 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:01:57 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:02:09 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:02:11 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:02:13 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:02:15 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:02:18 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:02:20 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:02:31 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:02:33 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:02:44 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:15:53 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:15:57 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:16:01 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:16:09 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:16:13 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:16:18 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:16:22 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:16:25 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:16:55 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:16:57 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:17:02 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:17:05 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:17:09 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:17:14 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:17:17 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:18:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:18:17 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:18:22 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:18:59 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:19:00 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:19:05 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:19:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:19:09 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:19:27 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:19:30 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:19:35 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:19:37 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:19:40 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:19:41 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:19:45 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:19:46 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:19:56 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:19:58 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:20:00 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:20:02 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:20:06 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:20:10 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:20:13 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:25:58 --> Severity: Compile Error --> Cannot redeclare Admin::secondsnack() C:\xampp\htdocs\application\controllers\Admin.php 360
ERROR - 2019-12-27 05:26:04 --> Severity: Compile Error --> Cannot redeclare Admin::secondsnack() C:\xampp\htdocs\application\controllers\Admin.php 360
ERROR - 2019-12-27 05:26:05 --> Severity: Compile Error --> Cannot redeclare Admin::secondsnack() C:\xampp\htdocs\application\controllers\Admin.php 360
ERROR - 2019-12-27 05:26:08 --> Severity: Compile Error --> Cannot redeclare Admin::secondsnack() C:\xampp\htdocs\application\controllers\Admin.php 360
ERROR - 2019-12-27 05:26:12 --> Severity: Compile Error --> Cannot redeclare Admin::secondsnack() C:\xampp\htdocs\application\controllers\Admin.php 360
ERROR - 2019-12-27 05:26:16 --> Severity: Compile Error --> Cannot redeclare Admin::secondsnack() C:\xampp\htdocs\application\controllers\Admin.php 360
ERROR - 2019-12-27 05:26:58 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:27:02 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:27:06 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:27:09 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:27:11 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:27:13 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:27:15 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:27:19 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:27:23 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:27:24 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:27:27 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:27:28 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:27:34 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:27:35 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:27:38 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:27:40 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:27:44 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:27:45 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:27:49 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:27:51 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:28:13 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:44:51 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:44:52 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 05:44:54 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 06:16:43 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 06:16:47 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 06:18:20 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 06:18:24 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 06:19:24 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 06:22:24 --> 404 Page Not Found: Admin/recomended
ERROR - 2019-12-27 06:22:26 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 06:23:17 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 06:23:23 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 06:28:04 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 06:28:11 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 06:28:39 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 06:29:04 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 06:29:28 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 06:32:06 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 06:32:28 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 06:32:37 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 06:32:42 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 06:32:46 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 06:32:51 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 08:24:45 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 07:24:46 --> Severity: error --> Exception: Call to undefined method Admin_model::get_recomended() C:\xampp\htdocs\application\controllers\Admin.php 404
ERROR - 2019-12-27 07:25:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\recomended.php 46
ERROR - 2019-12-27 08:01:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.`id = tb_r`.`category_id ORDER BY tb_c`.`id`' at line 1 - Invalid query: SELECT `SELECT tb_c`.`id` AS `category_id`, `tb_c`.`title` AS `title`, `tb_r`.`id` AS `recomended_id`, `tb_r`.`title AS subtitle FROM tb_categories` AS `tb_c`, `tb_recomended` AS `tb_r WHERE tb_c`.`id = tb_r`.`category_id ORDER BY tb_c`.`id`
ERROR - 2019-12-27 08:02:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'SELECT 'tb_c.id' AS category_id, 'tb_c.title' AS title, 'tb_r.id' AS recomended_' at line 1 - Invalid query: SELECT SELECT 'tb_c.id' AS category_id, 'tb_c.title' AS title, 'tb_r.id' AS recomended_id, 'tb_r.title' AS subtitle FROM tb_categories AS tb_c, tb_recomended AS tb_r WHERE 'tb_c.id' = 'tb_r.category_id' ORDER BY 'tb_c.id'
ERROR - 2019-12-27 08:05:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE tb_c.id = tb_r.category_id ORDER BY tb_c.id' at line 1 - Invalid query: SELECT `SELECT tb_c`.`id` AS "category_id", `tb_c`.`title` AS "title", `tb_r`.`id` AS "recomended_id", `tb_r`.`title AS "subtitle" FROM tb_categories` AS "tb_c", `tb_recomended` AS "tb_r" WHERE tb_c.id = tb_r.category_id ORDER BY tb_c.id
ERROR - 2019-12-27 08:08:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ''tb_c', tb_recomended 'tb_r' WHERE tb_c.id = tb_r.category_id ORDER BY tb_c.id' at line 1 - Invalid query: SELECT `SELECT tb_c`.`id` AS `category_id`, `tb_c`.`title` AS `title`, `tb_r`.`id` AS `recomended_id`, tb_r.title AS subtitle FROM tb_categories 'tb_c', tb_recomended 'tb_r' WHERE tb_c.id = tb_r.category_id ORDER BY tb_c.id
ERROR - 2019-12-27 08:09:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ''tb_categories' tb_c, 'tb_recomended' AS tb_r WHERE tb_c.id = tb_r.category_id O' at line 1 - Invalid query: SELECT `SELECT tb_c`.`id` AS `category_id`, `tb_c`.`title` AS `title`, `tb_r`.`id` AS `recomended_id`, tb_r.title AS subtitle FROM 'tb_categories' tb_c, 'tb_recomended' AS tb_r WHERE tb_c.id = tb_r.category_id ORDER BY tb_c.id
ERROR - 2019-12-27 08:10:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.`id = tb_r`.`category_id ORDER BY tb_c`.`id`' at line 1 - Invalid query: SELECT `SELECT tb_c`.`id` AS `category_id`, `tb_c`.`title` AS `title`, `tb_r`.`id` AS `recomended_id`, `tb_r`.`title` AS `subtitle FROM "tb_categories" tb_c`, "tb_recomended" AS `tb_r WHERE tb_c`.`id = tb_r`.`category_id ORDER BY tb_c`.`id`
ERROR - 2019-12-27 08:10:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.`id = tb_r`.`category_id ORDER BY tb_c`.`id`' at line 1 - Invalid query: SELECT `SELECT tb_c`.`id` AS `category_id`, `tb_c`.`title` AS `title`, `tb_r`.`id` AS `recomended_id`, `tb_r`.`title` AS `subtitle FROM "tb_categories" tb_c`, "tb_recomended" AS `tb_r WHERE tb_c`.`id = tb_r`.`category_id ORDER BY tb_c`.`id`
ERROR - 2019-12-27 08:10:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.`id = tb_r`.`category_id ORDER BY tb_c`.`id`' at line 1 - Invalid query: SELECT `SELECT tb_c`.`id` AS `category_id`, `tb_c`.`title` AS `title`, `tb_r`.`id` AS `recomended_id`, `tb_r`.`title` AS `subtitle FROM "tb_categories" tb_c`, "tb_recomended" AS `tb_r WHERE tb_c`.`id = tb_r`.`category_id ORDER BY tb_c`.`id`
ERROR - 2019-12-27 08:10:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.`id = tb_r`.`category_id ORDER BY tb_c`.`id`' at line 1 - Invalid query: SELECT `SELECT tb_c`.`id` AS `category_id`, `tb_c`.`title` AS `title`, `tb_r`.`id` AS `recomended_id`, `tb_r`.`title` AS `subtitle FROM "tb_categories" tb_c`, "tb_recomended" AS `tb_r WHERE tb_c`.`id = tb_r`.`category_id ORDER BY tb_c`.`id`
ERROR - 2019-12-27 08:14:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.`id = tb_r`.`category_id ORDER BY tb_c`.`id`' at line 1 - Invalid query: SELECT `SELECT tb_c`.`id` AS `category_id`, `tb_c`.`title` AS `title`, `tb_r`.`id` AS `recomended_id`, `tb_r`.`title` AS `subtitle FROM tb_categories tb_c`, `tb_recomended` AS `tb_r WHERE tb_c`.`id = tb_r`.`category_id ORDER BY tb_c`.`id`
ERROR - 2019-12-27 09:14:27 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:14:28 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 08:14:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.`id = tb_r`.`category_id ORDER BY tb_c`.`id`' at line 1 - Invalid query: SELECT `SELECT tb_c`.`id` AS `category_id`, `tb_c`.`title` AS `title`, `tb_r`.`id` AS `recomended_id`, `tb_r`.`title` AS `subtitle FROM tb_categories tb_c`, `tb_recomended` AS `tb_r WHERE tb_c`.`id = tb_r`.`category_id ORDER BY tb_c`.`id`
ERROR - 2019-12-27 08:16:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.`id = tb_r`.`category_id ORDER BY tb_c`.`id`' at line 1 - Invalid query: SELECT `SELECT tb_c`.`id` AS `category_id`, `tb_c`.`title` AS `title`, `tb_r`.`id` AS `recomended_id`, `tb_r`.`title AS subtitle FROM tb_categories tb_c tb_recomended` AS `tb_r WHERE tb_c`.`id = tb_r`.`category_id ORDER BY tb_c`.`id`
ERROR - 2019-12-27 08:19:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.`id = tb_r`.`category_id ORDER BY tb_c`.`id`' at line 1 - Invalid query: SELECT `SELECT tb_c`.`id` AS `category_id`, `tb_c`.`title` AS `title`, `tb_r`.`id` AS `recomended_id`, `tb_r`.`title` AS `subtitle FROM ``tb_categories`` tb_c`, `tb_recomended` AS `tb_r WHERE tb_c`.`id = tb_r`.`category_id ORDER BY tb_c`.`id`
ERROR - 2019-12-27 08:19:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.`id = tb_r`.`category_id ORDER BY tb_c`.`id`' at line 1 - Invalid query: SELECT `SELECT tb_c`.`id` AS `category_id`, `tb_c`.`title` AS `title`, `tb_r`.`id` AS `recomended_id`, `tb_r`.`title` AS `subtitle FROM ``tb_categories`` tb_c`, `tb_recomended` AS `tb_r WHERE tb_c`.`id = tb_r`.`category_id ORDER BY tb_c`.`id`
ERROR - 2019-12-27 08:19:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.`id = tb_r`.`category_id ORDER BY tb_c`.`id`' at line 1 - Invalid query: SELECT `SELECT tb_c`.`id` AS `category_id`, `tb_c`.`title` AS `title`, `tb_r`.`id` AS `recomended_id`, `tb_r`.`title` AS `subtitle FROM ``tb_categories`` tb_c`, `tb_recomended` AS `tb_r WHERE tb_c`.`id = tb_r`.`category_id ORDER BY tb_c`.`id`
ERROR - 2019-12-27 08:19:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.`id = tb_r`.`category_id ORDER BY tb_c`.`id`' at line 1 - Invalid query: SELECT `SELECT tb_c`.`id` AS `category_id`, `tb_c`.`title` AS `title`, `tb_r`.`id` AS `recomended_id`, `tb_r`.`title` AS `subtitle FROM ``tb_categories`` tb_c`, `tb_recomended` AS `tb_r WHERE tb_c`.`id = tb_r`.`category_id ORDER BY tb_c`.`id`
ERROR - 2019-12-27 08:19:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.`id = tb_r`.`category_id ORDER BY tb_c`.`id`' at line 1 - Invalid query: SELECT `SELECT tb_c`.`id` AS `category_id`, `tb_c`.`title` AS `title`, `tb_r`.`id` AS `recomended_id`, `tb_r`.`title` AS `subtitle FROM ``tb_categories`` tb_c`, `tb_recomended` AS `tb_r WHERE tb_c`.`id = tb_r`.`category_id ORDER BY tb_c`.`id`
ERROR - 2019-12-27 08:19:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.`id = tb_r`.`category_id ORDER BY tb_c`.`id`' at line 1 - Invalid query: SELECT `SELECT tb_c`.`id` AS `category_id`, `tb_c`.`title` AS `title`, `tb_r`.`id` AS `recomended_id`, `tb_r`.`title` AS `subtitle FROM ``tb_categories`` tb_c`, `tb_recomended` AS `tb_r WHERE tb_c`.`id = tb_r`.`category_id ORDER BY tb_c`.`id`
ERROR - 2019-12-27 08:21:47 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\application\views\admin\recomended.php 55
ERROR - 2019-12-27 08:21:47 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\application\views\admin\recomended.php 56
ERROR - 2019-12-27 08:21:47 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\application\views\admin\recomended.php 57
ERROR - 2019-12-27 08:21:47 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\application\views\admin\recomended.php 55
ERROR - 2019-12-27 08:21:47 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\application\views\admin\recomended.php 56
ERROR - 2019-12-27 08:21:47 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\application\views\admin\recomended.php 57
ERROR - 2019-12-27 08:21:47 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\application\views\admin\recomended.php 55
ERROR - 2019-12-27 08:21:47 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\application\views\admin\recomended.php 56
ERROR - 2019-12-27 08:21:47 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\application\views\admin\recomended.php 57
ERROR - 2019-12-27 09:21:47 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:24:05 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:27:27 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:28:08 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:28:13 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:28:25 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:28:30 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:28:53 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:30:04 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:30:41 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:31:30 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:32:35 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:35:23 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:36:39 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:36:57 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:37:43 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:37:45 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:38:06 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:38:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:38:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:41:15 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:41:45 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:41:59 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:42:32 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:42:34 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:42:49 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:44:04 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:44:19 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:44:57 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:45:43 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:46:21 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:46:36 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:52:03 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:52:50 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:53:17 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:53:29 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:53:42 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:54:52 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:55:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:55:33 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:56:24 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:01:48 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:01:50 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:01:53 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:02:00 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:02:03 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:04:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE tb_c.id = tb_r.category_id ORDER BY tb_c.id' at line 1 - Invalid query: SELECT tb_c.id AS category_id, tb_c.title AS title, tb_r.id AS recomended_id, tb_r.title AS subtitle FROM `tb_categories` tb_c LEFT JOIN `tb_recomended` AS tb_r WHERE tb_c.id = tb_r.category_id ORDER BY tb_c.id
ERROR - 2019-12-27 10:05:35 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:07:39 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:08:32 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:09:33 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE) C:\xampp\htdocs\application\views\admin\recomended.php 67
ERROR - 2019-12-27 09:09:54 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\application\views\admin\recomended.php 76
ERROR - 2019-12-27 10:10:06 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:10:33 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:10:37 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:12:41 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:13:03 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:13:14 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:16:58 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:16:59 --> Query error: Unknown column 'category_id' in 'field list' - Invalid query: INSERT INTO `tb_categories` (`category_id`, `recmended_id`, `title`) VALUES ('4', '3', 'Any Kiwi 40 calories per 1 cup or less recommend daily intake 100 calories')
ERROR - 2019-12-27 10:17:02 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:17:20 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:17:40 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:19:55 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:20:26 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:21:41 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:22:02 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:23:24 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:27:44 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:29:13 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:29:34 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:30:19 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:30:29 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:30:47 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:30:55 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:37:58 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:38:00 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:38:23 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:38:25 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:38:38 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:38:39 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:39:11 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:47:51 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:48:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:48:39 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:49:00 --> Severity: error --> Exception: Call to undefined function convert_text() C:\xampp\htdocs\application\controllers\Admin.php 410
ERROR - 2019-12-27 10:51:43 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:51:47 --> Severity: error --> Exception: Call to undefined function convert_text() C:\xampp\htdocs\application\controllers\Admin.php 410
ERROR - 2019-12-27 10:51:59 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:52:01 --> Severity: error --> Exception: Call to undefined function convert_text() C:\xampp\htdocs\application\controllers\Admin.php 410
ERROR - 2019-12-27 10:52:03 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:52:08 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:52:12 --> Severity: error --> Exception: Call to undefined function convert_text() C:\xampp\htdocs\application\controllers\Admin.php 410
ERROR - 2019-12-27 10:53:21 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:53:23 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:53:39 --> Severity: error --> Exception: Call to undefined function convert_text() C:\xampp\htdocs\application\controllers\Admin.php 410
ERROR - 2019-12-27 10:54:16 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:54:21 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:54:25 --> Severity: error --> Exception: Call to undefined function convertText() C:\xampp\htdocs\application\controllers\Admin.php 410
ERROR - 2019-12-27 10:54:47 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:54:50 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:54:53 --> Severity: error --> Exception: Call to undefined function convertText() C:\xampp\htdocs\application\controllers\Admin.php 435
ERROR - 2019-12-27 10:57:29 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:57:32 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:57:35 --> Severity: Notice --> Undefined variable: t C:\xampp\htdocs\application\controllers\Admin.php 758
ERROR - 2019-12-27 10:57:35 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:58:36 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:59:19 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 09:59:23 --> Severity: Notice --> Undefined variable: t C:\xampp\htdocs\application\controllers\Admin.php 760
ERROR - 2019-12-27 10:59:24 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 11:06:24 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 11:06:30 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:06:34 --> Severity: Notice --> Undefined variable: t C:\xampp\htdocs\application\controllers\Admin.php 761
ERROR - 2019-12-27 11:06:34 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:06:43 --> Severity: Notice --> Undefined variable: t C:\xampp\htdocs\application\controllers\Admin.php 761
ERROR - 2019-12-27 11:06:43 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:06:53 --> Severity: Notice --> Undefined variable: t C:\xampp\htdocs\application\controllers\Admin.php 761
ERROR - 2019-12-27 11:06:54 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:07:03 --> Severity: Notice --> Undefined variable: t C:\xampp\htdocs\application\controllers\Admin.php 761
ERROR - 2019-12-27 11:07:03 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 11:07:48 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 11:08:00 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 11:08:04 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 11:08:26 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 11:08:31 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 11:09:00 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 11:09:04 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 11:09:45 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 11:09:50 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 11:10:05 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 11:10:10 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 11:13:05 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 11:17:48 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 10:17:57 --> Severity: error --> Exception: Too few arguments to function Admin::editrecomended(), 0 passed in C:\xampp\htdocs\system\core\CodeIgniter.php on line 514 and exactly 2 expected C:\xampp\htdocs\application\controllers\Admin.php 417
ERROR - 2019-12-27 11:18:51 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 11:18:52 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 11:18:59 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 11:19:11 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 12:54:29 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\application\controllers\Admin.php 690
ERROR - 2019-12-27 12:54:41 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 11:54:45 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\application\controllers\Admin.php 701
ERROR - 2019-12-27 11:54:45 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\application\controllers\Admin.php 701
ERROR - 2019-12-27 11:54:45 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\application\controllers\Admin.php 701
ERROR - 2019-12-27 11:54:45 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\application\controllers\Admin.php 701
ERROR - 2019-12-27 11:54:45 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\application\controllers\Admin.php 701
ERROR - 2019-12-27 12:59:39 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 11:59:40 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\controllers\Admin.php 691
ERROR - 2019-12-27 11:59:40 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\controllers\Admin.php 691
ERROR - 2019-12-27 11:59:40 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\controllers\Admin.php 691
ERROR - 2019-12-27 11:59:40 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\application\controllers\Admin.php 702
ERROR - 2019-12-27 11:59:40 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\application\controllers\Admin.php 702
ERROR - 2019-12-27 13:01:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 12:01:08 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\application\controllers\Admin.php 691
ERROR - 2019-12-27 12:01:08 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\application\controllers\Admin.php 691
ERROR - 2019-12-27 12:01:14 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\application\controllers\Admin.php 691
ERROR - 2019-12-27 13:01:17 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 12:01:18 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\application\controllers\Admin.php 691
ERROR - 2019-12-27 12:01:18 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\application\controllers\Admin.php 691
ERROR - 2019-12-27 13:01:21 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 13:01:33 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 12:01:34 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\controllers\Admin.php 691
ERROR - 2019-12-27 12:01:34 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\controllers\Admin.php 691
ERROR - 2019-12-27 12:01:34 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\controllers\Admin.php 691
ERROR - 2019-12-27 12:01:34 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\application\controllers\Admin.php 702
ERROR - 2019-12-27 12:01:34 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\application\controllers\Admin.php 702
ERROR - 2019-12-27 13:01:51 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 12:01:52 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\controllers\Admin.php 691
ERROR - 2019-12-27 12:01:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Admin.php 691
ERROR - 2019-12-27 12:01:52 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\controllers\Admin.php 691
ERROR - 2019-12-27 12:01:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Admin.php 691
ERROR - 2019-12-27 12:01:52 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\controllers\Admin.php 691
ERROR - 2019-12-27 12:01:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Admin.php 691
ERROR - 2019-12-27 13:02:14 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 12:02:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Admin.php 691
ERROR - 2019-12-27 12:02:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Admin.php 691
ERROR - 2019-12-27 12:02:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Admin.php 691
ERROR - 2019-12-27 12:02:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Admin.php 691
ERROR - 2019-12-27 12:02:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Admin.php 691
ERROR - 2019-12-27 13:03:43 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 12:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Admin.php 693
ERROR - 2019-12-27 12:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Admin.php 693
ERROR - 2019-12-27 12:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Admin.php 693
ERROR - 2019-12-27 12:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Admin.php 693
ERROR - 2019-12-27 12:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Admin.php 693
ERROR - 2019-12-27 13:06:46 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 12:06:49 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\application\controllers\Admin.php 693
ERROR - 2019-12-27 12:06:49 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\application\controllers\Admin.php 694
ERROR - 2019-12-27 12:06:49 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\application\controllers\Admin.php 693
ERROR - 2019-12-27 12:06:49 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\application\controllers\Admin.php 694
ERROR - 2019-12-27 12:06:49 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\application\controllers\Admin.php 693
ERROR - 2019-12-27 12:06:49 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\application\controllers\Admin.php 694
ERROR - 2019-12-27 12:06:49 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\application\controllers\Admin.php 693
ERROR - 2019-12-27 12:06:49 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\application\controllers\Admin.php 694
ERROR - 2019-12-27 12:06:49 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\application\controllers\Admin.php 693
ERROR - 2019-12-27 12:06:49 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\application\controllers\Admin.php 694
ERROR - 2019-12-27 13:14:57 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 13:18:02 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 13:19:55 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 13:23:28 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 13:24:48 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 13:25:21 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 12:25:22 --> Severity: error --> Exception: Call to undefined function is_empty() C:\xampp\htdocs\application\controllers\Admin.php 692
ERROR - 2019-12-27 12:25:22 --> Severity: error --> Exception: Call to undefined function is_empty() C:\xampp\htdocs\application\controllers\Admin.php 692
ERROR - 2019-12-27 12:25:27 --> Severity: error --> Exception: Call to undefined function is_empty() C:\xampp\htdocs\application\controllers\Admin.php 692
ERROR - 2019-12-27 13:25:29 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 13:26:28 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 13:27:04 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 13:27:22 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 13:28:09 --> 404 Page Not Found: Admin/calory
ERROR - 2019-12-27 13:28:12 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 13:32:18 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 13:32:24 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 13:32:54 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 13:33:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 13:34:05 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 13:34:15 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 13:34:19 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 13:34:25 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 13:34:27 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 14:00:48 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:48 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:48 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:48 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:48 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:48 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:48 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:48 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:52 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:52 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:52 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:52 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:52 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:52 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:52 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:52 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:52 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:54 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:54 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:54 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:54 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:54 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:54 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:54 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:54 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:55 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:55 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:55 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:55 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:55 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:55 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:55 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:55 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:55 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:56 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:56 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:56 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:56 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:56 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:56 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:56 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:57 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:57 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:57 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:57 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:57 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:57 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:57 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:57 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:57 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:57 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:57 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:58 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:58 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:58 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:58 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:58 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:58 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:58 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:58 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:00:58 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-27 14:28:41 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 14:28:47 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 14:28:53 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 14:28:55 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 14:28:56 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 14:28:57 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 14:29:24 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 14:29:33 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 14:30:03 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 14:30:04 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 14:30:06 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 14:30:08 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 14:30:09 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 14:30:11 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 14:30:15 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 14:30:17 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 14:30:20 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 14:31:18 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 14:31:46 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 14:31:47 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 14:40:56 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 14:41:58 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 14:42:11 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 14:42:23 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 21:48:50 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 21:48:55 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 21:49:13 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 20:49:22 --> Severity: error --> Exception: Call to undefined method Admin_model::get_salebalance_byuser() C:\xampp\htdocs\application\controllers\Admin.php 452
ERROR - 2019-12-27 21:49:24 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 21:49:34 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 21:50:08 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 21:50:35 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 21:50:56 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 21:51:08 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 21:51:21 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 21:51:28 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 21:52:16 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 21:53:36 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 21:54:10 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 21:54:22 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 21:54:50 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 21:55:18 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 21:55:21 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 20:56:06 --> Severity: Notice --> Undefined variable: fetch C:\xampp\htdocs\application\views\admin\dashboard.php 60
ERROR - 2019-12-27 20:56:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\dashboard.php 60
ERROR - 2019-12-27 21:56:06 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 21:56:14 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 21:56:26 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 21:56:27 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 21:56:41 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 21:56:53 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 21:57:50 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 21:57:55 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 21:58:00 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 21:58:31 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 21:58:33 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 21:58:39 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 21:58:44 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 21:59:35 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 21:59:36 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 21:59:37 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:00:48 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:01:11 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:01:12 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:01:14 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:02:01 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:02:03 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:02:38 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:02:39 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:02:40 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:03:52 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:03:53 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:05:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:05:21 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:05:26 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:05:40 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:06:20 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:06:45 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:07:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:07:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:07:11 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:07:24 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:07:37 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:07:59 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:08:02 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:08:05 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:08:39 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:09:51 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:10:30 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:10:48 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:11:43 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:12:26 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:12:44 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:13:03 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:13:20 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:13:22 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:13:39 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:13:47 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:13:52 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:14:17 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:14:35 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:14:52 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:14:54 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:14:55 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:15:14 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:15:17 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:15:33 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:19:06 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:19:22 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:19:45 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:19:50 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:19:54 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:20:11 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:20:31 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:21:00 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:21:05 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:21:16 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:22:11 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:23:00 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:24:48 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:26:32 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:27:02 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:27:21 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:27:37 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:28:01 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:28:41 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:29:22 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:29:45 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:30:53 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:31:20 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:31:41 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:32:42 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:33:02 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:33:13 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:33:29 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:33:37 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:33:56 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:34:08 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:34:31 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:34:56 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:35:36 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:35:56 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:36:31 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:36:58 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:37:18 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:37:39 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:38:44 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:38:58 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:39:51 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:40:20 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:40:43 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:41:13 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:41:28 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:42:09 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:43:41 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:44:06 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:44:36 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:44:49 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:44:55 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:46:15 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:46:33 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:46:40 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:46:41 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:46:43 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:46:54 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:46:57 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:47:09 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:47:13 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:47:37 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:47:40 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:47:44 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:47:48 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:48:00 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:49:28 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:49:39 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:49:40 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:49:47 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:50:11 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:50:18 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:50:19 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:50:54 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:51:58 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:52:26 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:53:00 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:53:13 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:53:37 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:53:40 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:53:58 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:53:59 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:54:05 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:54:06 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:58:54 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 21:59:19 --> Severity: error --> Exception: Call to undefined method Admin_model::get_salebalance_byuser() C:\xampp\htdocs\application\controllers\Admin.php 452
ERROR - 2019-12-27 23:00:36 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:00:53 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:03:19 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:05:59 --> Severity: error --> Exception: Call to undefined method Admin_model::get_salebalance_byuser() C:\xampp\htdocs\application\controllers\Admin.php 452
ERROR - 2019-12-27 23:06:02 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:07:48 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:07:49 --> Query error: Table 'foodtrack.tb_links' doesn't exist - Invalid query: SELECT *
FROM `tb_links`
WHERE `user_id` = '1'
ERROR - 2019-12-27 22:08:34 --> Severity: Notice --> Undefined property: stdClass::$paypal C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2019-12-27 22:08:34 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\application\views\admin\user-detail.php 51
ERROR - 2019-12-27 22:08:34 --> Severity: Notice --> Undefined variable: amount C:\xampp\htdocs\application\views\admin\user-detail.php 51
ERROR - 2019-12-27 22:08:34 --> Severity: Notice --> Undefined property: stdClass::$balance C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2019-12-27 22:08:34 --> Severity: Notice --> Undefined variable: fetch C:\xampp\htdocs\application\views\admin\user-detail.php 71
ERROR - 2019-12-27 22:08:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\user-detail.php 71
ERROR - 2019-12-27 23:08:34 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:09:30 --> Severity: Notice --> Undefined property: stdClass::$paypal C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2019-12-27 22:09:30 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\application\views\admin\user-detail.php 51
ERROR - 2019-12-27 22:09:30 --> Severity: Notice --> Undefined variable: amount C:\xampp\htdocs\application\views\admin\user-detail.php 51
ERROR - 2019-12-27 22:09:30 --> Severity: Notice --> Undefined property: stdClass::$balance C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2019-12-27 22:09:30 --> Severity: Notice --> Undefined variable: fetch C:\xampp\htdocs\application\views\admin\user-detail.php 71
ERROR - 2019-12-27 22:09:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\user-detail.php 71
ERROR - 2019-12-27 23:09:30 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:09:32 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:09:34 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:10:05 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:10:09 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:10:30 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:10:31 --> 404 Page Not Found: Admin/calory
ERROR - 2019-12-27 23:10:33 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:11:05 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:11:06 --> 404 Page Not Found: Admin/calorie
ERROR - 2019-12-27 23:11:08 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:16:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:17:35 --> Severity: Compile Error --> Cannot redeclare Admin::add_categories() C:\xampp\htdocs\application\controllers\Admin.php 437
ERROR - 2019-12-27 23:17:37 --> Severity: Compile Error --> Cannot redeclare Admin::add_categories() C:\xampp\htdocs\application\controllers\Admin.php 437
ERROR - 2019-12-27 23:19:19 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:19:20 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:19:24 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:19:25 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:19:38 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:19:56 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:20:19 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:20:31 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:20:38 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:21:02 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:21:05 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:21:06 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:24:24 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:24:27 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:25:05 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:25:47 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:26:06 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:26:23 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:26:50 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:27:17 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:27:33 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:27:35 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:27:49 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:28:08 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:28:14 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:28:16 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:29:47 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:30:05 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:30:09 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:31:00 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:31:03 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:31:19 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:31:20 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:31:21 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:32:00 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:32:02 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:32:04 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:32:04 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:32:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 22:50:07 --> Severity: error --> Exception: Too few arguments to function Admin::calorie(), 0 passed in C:\xampp\htdocs\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\application\controllers\Admin.php 437
ERROR - 2019-12-27 23:50:14 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:54:49 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-27 23:11:38 --> Query error: Unknown column 'calories' in 'field list' - Invalid query: INSERT INTO `tb_calorie` (`category_id`, `title`, `calories`, `carbs`, `fat`, `protein`, `fiber`) VALUES ('1', 'Brown Rice', '218', '17.5', '21.5', '6.0', '5.0')
ERROR - 2019-12-27 23:12:46 --> Query error: Unknown column 'calories' in 'field list' - Invalid query: INSERT INTO `tb_calorie` (`category_id`, `title`, `calories`, `carbs`, `fat`, `protein`, `fiber`) VALUES ('1', 'Brown Rice', '218', '17.5', '21.5', '6.0', '5.0')
ERROR - 2019-12-27 23:13:41 --> Severity: Notice --> Undefined property: stdClass::$calories C:\xampp\htdocs\application\views\admin\edit_calorie.php 28
ERROR - 2019-12-27 23:19:03 --> Severity: error --> Exception: Too few arguments to function Admin::calorie(), 0 passed in C:\xampp\htdocs\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\application\controllers\Admin.php 437
ERROR - 2019-12-27 23:23:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\edit_calorie.php 19
ERROR - 2019-12-27 23:23:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\edit_calorie.php 19
ERROR - 2019-12-27 23:23:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\edit_calorie.php 24
ERROR - 2019-12-27 23:23:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\edit_calorie.php 24
ERROR - 2019-12-27 23:23:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\edit_calorie.php 28
ERROR - 2019-12-27 23:23:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\edit_calorie.php 28
ERROR - 2019-12-27 23:23:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\edit_calorie.php 32
ERROR - 2019-12-27 23:23:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\edit_calorie.php 32
ERROR - 2019-12-27 23:23:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\edit_calorie.php 36
ERROR - 2019-12-27 23:23:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\edit_calorie.php 36
ERROR - 2019-12-27 23:23:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\edit_calorie.php 40
ERROR - 2019-12-27 23:23:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\edit_calorie.php 40
ERROR - 2019-12-27 23:23:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\edit_calorie.php 44
ERROR - 2019-12-27 23:23:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\edit_calorie.php 44
ERROR - 2019-12-27 23:24:54 --> Severity: error --> Exception: Call to undefined method Admin::get_single_value() C:\xampp\htdocs\application\controllers\Admin.php 444
ERROR - 2019-12-27 23:25:44 --> Severity: error --> Exception: Call to undefined method Admin::get_single_value() C:\xampp\htdocs\application\controllers\Admin.php 444
ERROR - 2019-12-27 23:25:48 --> Severity: error --> Exception: Call to undefined method Admin::get_single_value() C:\xampp\htdocs\application\controllers\Admin.php 444
ERROR - 2019-12-27 23:25:49 --> Severity: error --> Exception: Call to undefined method Admin::get_single_value() C:\xampp\htdocs\application\controllers\Admin.php 444
ERROR - 2019-12-27 23:26:25 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\application\controllers\Admin.php 445
