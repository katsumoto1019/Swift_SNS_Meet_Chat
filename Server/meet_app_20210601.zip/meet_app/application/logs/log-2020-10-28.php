<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-28 03:38:17 --> 404 Page Not Found: Apple_touch_icon_120x120_precomposedpng/index
ERROR - 2020-10-28 03:38:18 --> 404 Page Not Found: Apple_touch_icon_120x120png/index
ERROR - 2020-10-28 03:38:18 --> 404 Page Not Found: Apple_touch_icon_precomposedpng/index
ERROR - 2020-10-28 03:38:19 --> 404 Page Not Found: Apple_touch_iconpng/index
ERROR - 2020-10-28 04:46:58 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-10-28 06:52:20 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-10-28 06:52:21 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-10-28 07:12:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-10-28 13:02:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-10-28 13:02:49 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2020-10-28 13:02:49 --> 404 Page Not Found: Blog/robots.txt
ERROR - 2020-10-28 13:02:49 --> 404 Page Not Found: Blog/index
ERROR - 2020-10-28 13:02:49 --> 404 Page Not Found: Wordpress/index
ERROR - 2020-10-28 13:02:50 --> 404 Page Not Found: Wp/index
