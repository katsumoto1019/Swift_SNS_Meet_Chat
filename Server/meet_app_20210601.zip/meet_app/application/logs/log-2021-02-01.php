<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-01 07:44:42 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-02-01 07:44:43 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-02-01 14:12:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-02-01 23:30:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-02-01 23:55:26 --> 404 Page Not Found: Robotstxt/index
