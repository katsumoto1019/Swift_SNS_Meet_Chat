<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-13 03:39:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'learnme'@'localhost' (using password: YES) C:\xampp\htdocs\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2020-07-13 03:39:20 --> Unable to connect to the database
ERROR - 2020-07-13 04:23:58 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'learnme'@'localhost' (using password: YES) C:\xampp\htdocs\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2020-07-13 04:23:58 --> Unable to connect to the database
ERROR - 2020-07-13 05:40:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/1044): Access denied for user ''@'localhost' to database 'ounited' C:\xampp\htdocs\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2020-07-13 05:40:08 --> Unable to connect to the database
ERROR - 2020-07-13 05:40:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/1044): Access denied for user ''@'localhost' to database 'ounited' C:\xampp\htdocs\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2020-07-13 05:40:11 --> Unable to connect to the database
ERROR - 2020-07-13 06:20:01 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:21:05 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:24:40 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:28:31 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:29:14 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:33:55 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:34:06 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:37:02 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:39:06 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:39:28 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:39:31 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:39:34 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:39:44 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:40:54 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:41:08 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:41:21 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:41:30 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:41:34 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:41:50 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:41:55 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:42:05 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:45:31 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:45:44 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:46:02 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:46:15 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:47:06 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:47:09 --> 404 Page Not Found: Dashboard/index
ERROR - 2020-07-13 06:47:16 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 00:11:41 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 00:11:41 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 00:11:41 --> Severity: Notice --> Undefined variable: buyer_count C:\xampp\htdocs\application\views\admin\dashboard.php 24
ERROR - 2020-07-13 00:11:41 --> Severity: Notice --> Undefined variable: seller_count C:\xampp\htdocs\application\views\admin\dashboard.php 40
ERROR - 2020-07-13 00:11:41 --> Severity: Notice --> Undefined variable: approve_count C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-07-13 00:11:41 --> Severity: Notice --> Undefined variable: upcomming_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-13 00:11:41 --> Severity: Notice --> Undefined variable: complete_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-13 00:11:41 --> Severity: Notice --> Undefined variable: refund C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-13 00:11:41 --> Severity: Notice --> Undefined variable: total_amount C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-13 07:11:41 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 00:15:04 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 00:15:04 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 00:15:04 --> Severity: Notice --> Undefined variable: buyer_count C:\xampp\htdocs\application\views\admin\dashboard.php 24
ERROR - 2020-07-13 00:15:04 --> Severity: Notice --> Undefined variable: seller_count C:\xampp\htdocs\application\views\admin\dashboard.php 40
ERROR - 2020-07-13 00:15:04 --> Severity: Notice --> Undefined variable: approve_count C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-07-13 00:15:04 --> Severity: Notice --> Undefined variable: upcomming_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-13 00:15:04 --> Severity: Notice --> Undefined variable: complete_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-13 00:15:04 --> Severity: Notice --> Undefined variable: refund C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-13 00:15:04 --> Severity: Notice --> Undefined variable: total_amount C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-13 07:15:04 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 00:15:18 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 00:15:18 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 00:15:18 --> Severity: Notice --> Undefined variable: buyer_count C:\xampp\htdocs\application\views\admin\dashboard.php 24
ERROR - 2020-07-13 00:15:18 --> Severity: Notice --> Undefined variable: seller_count C:\xampp\htdocs\application\views\admin\dashboard.php 40
ERROR - 2020-07-13 00:15:18 --> Severity: Notice --> Undefined variable: approve_count C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-07-13 00:15:18 --> Severity: Notice --> Undefined variable: upcomming_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-13 00:15:18 --> Severity: Notice --> Undefined variable: complete_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-13 00:15:18 --> Severity: Notice --> Undefined variable: refund C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-13 00:15:18 --> Severity: Notice --> Undefined variable: total_amount C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-13 07:15:18 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 00:15:24 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 00:15:24 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 00:15:24 --> Severity: Notice --> Undefined variable: buyer_count C:\xampp\htdocs\application\views\admin\dashboard.php 24
ERROR - 2020-07-13 00:15:24 --> Severity: Notice --> Undefined variable: seller_count C:\xampp\htdocs\application\views\admin\dashboard.php 40
ERROR - 2020-07-13 00:15:24 --> Severity: Notice --> Undefined variable: approve_count C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-07-13 00:15:24 --> Severity: Notice --> Undefined variable: upcomming_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-13 00:15:24 --> Severity: Notice --> Undefined variable: complete_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-13 00:15:24 --> Severity: Notice --> Undefined variable: refund C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-13 00:15:24 --> Severity: Notice --> Undefined variable: total_amount C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-13 07:15:25 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 00:15:46 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 00:15:46 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 00:15:46 --> Severity: Notice --> Undefined variable: buyer_count C:\xampp\htdocs\application\views\admin\dashboard.php 24
ERROR - 2020-07-13 00:15:46 --> Severity: Notice --> Undefined variable: seller_count C:\xampp\htdocs\application\views\admin\dashboard.php 40
ERROR - 2020-07-13 00:15:46 --> Severity: Notice --> Undefined variable: approve_count C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-07-13 00:15:46 --> Severity: Notice --> Undefined variable: upcomming_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-13 00:15:46 --> Severity: Notice --> Undefined variable: complete_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-13 00:15:46 --> Severity: Notice --> Undefined variable: refund C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-13 00:15:46 --> Severity: Notice --> Undefined variable: total_amount C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-13 07:15:46 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 12:51:48 --> 404 Page Not Found: HNAP1/index
ERROR - 2020-07-13 06:14:47 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 06:14:47 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 06:14:47 --> Severity: Notice --> Undefined variable: user_count C:\xampp\htdocs\application\views\admin\dashboard.php 24
ERROR - 2020-07-13 06:14:47 --> Severity: Notice --> Undefined variable: money_count C:\xampp\htdocs\application\views\admin\dashboard.php 40
ERROR - 2020-07-13 06:14:47 --> Severity: Notice --> Undefined variable: mask_count C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-07-13 06:14:47 --> Severity: Notice --> Undefined variable: agency_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-13 06:14:47 --> Severity: Notice --> Undefined variable: apply_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-13 06:14:47 --> Severity: Notice --> Undefined variable: volunteer_count C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-13 06:14:47 --> Severity: Notice --> Undefined variable: report_count C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-13 13:14:48 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:15:37 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 06:15:37 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 06:15:37 --> Severity: Notice --> Undefined variable: user_count C:\xampp\htdocs\application\views\admin\dashboard.php 24
ERROR - 2020-07-13 06:15:37 --> Severity: Notice --> Undefined variable: money_count C:\xampp\htdocs\application\views\admin\dashboard.php 40
ERROR - 2020-07-13 06:15:37 --> Severity: Notice --> Undefined variable: mask_count C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-07-13 06:15:37 --> Severity: Notice --> Undefined variable: agency_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-13 06:15:37 --> Severity: Notice --> Undefined variable: apply_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-13 06:15:37 --> Severity: Notice --> Undefined variable: volunteer_count C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-13 06:15:37 --> Severity: Notice --> Undefined variable: report_count C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-13 13:15:38 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:18:38 --> Query error: Unknown column 'approve' in 'where clause' - Invalid query: SELECT *
FROM `tb_user`
WHERE `approve` = '1'
AND `type` = 'seller'
ERROR - 2020-07-13 06:18:51 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 06:18:51 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 06:18:51 --> Severity: Notice --> Undefined variable: user_count C:\xampp\htdocs\application\views\admin\dashboard.php 24
ERROR - 2020-07-13 06:18:51 --> Severity: Notice --> Undefined variable: money_count C:\xampp\htdocs\application\views\admin\dashboard.php 40
ERROR - 2020-07-13 06:18:51 --> Severity: Notice --> Undefined variable: mask_count C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-07-13 06:18:51 --> Severity: Notice --> Undefined variable: agency_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-13 06:18:51 --> Severity: Notice --> Undefined variable: apply_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-13 06:18:51 --> Severity: Notice --> Undefined variable: volunteer_count C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-13 06:18:51 --> Severity: Notice --> Undefined variable: report_count C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-13 13:18:52 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:19:25 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 06:19:25 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 06:19:25 --> Severity: Notice --> Undefined variable: money_count C:\xampp\htdocs\application\views\admin\dashboard.php 40
ERROR - 2020-07-13 06:19:25 --> Severity: Notice --> Undefined variable: mask_count C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-07-13 06:19:25 --> Severity: Notice --> Undefined variable: agency_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-13 06:19:25 --> Severity: Notice --> Undefined variable: apply_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-13 06:19:25 --> Severity: Notice --> Undefined variable: volunteer_count C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-13 06:19:25 --> Severity: Notice --> Undefined variable: report_count C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-13 13:19:25 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:24:48 --> Severity: Notice --> Undefined variable: total_amount C:\xampp\htdocs\application\controllers\Admin.php 182
ERROR - 2020-07-13 06:24:48 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 06:24:48 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 06:24:48 --> Severity: Notice --> Undefined variable: mask_count C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-07-13 06:24:48 --> Severity: Notice --> Undefined variable: agency_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-13 06:24:48 --> Severity: Notice --> Undefined variable: apply_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-13 06:24:48 --> Severity: Notice --> Undefined variable: volunteer_count C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-13 06:24:48 --> Severity: Notice --> Undefined variable: report_count C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-13 06:25:00 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 06:25:00 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 06:25:00 --> Severity: Notice --> Undefined variable: mask_count C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-07-13 06:25:00 --> Severity: Notice --> Undefined variable: agency_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-13 06:25:00 --> Severity: Notice --> Undefined variable: apply_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-13 06:25:00 --> Severity: Notice --> Undefined variable: volunteer_count C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-13 06:25:00 --> Severity: Notice --> Undefined variable: report_count C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-13 13:25:00 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:25:28 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 06:25:28 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 06:25:28 --> Severity: Notice --> Undefined variable: mask_count C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-07-13 06:25:28 --> Severity: Notice --> Undefined variable: agency_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-13 06:25:28 --> Severity: Notice --> Undefined variable: apply_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-13 06:25:28 --> Severity: Notice --> Undefined variable: volunteer_count C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-13 06:25:28 --> Severity: Notice --> Undefined variable: report_count C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-13 13:25:28 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:26:29 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 06:26:29 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 06:26:29 --> Severity: Notice --> Undefined variable: mask_count C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-07-13 06:26:29 --> Severity: Notice --> Undefined variable: agency_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-13 06:26:29 --> Severity: Notice --> Undefined variable: apply_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-13 06:26:29 --> Severity: Notice --> Undefined variable: volunteer_count C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-13 06:26:29 --> Severity: Notice --> Undefined variable: report_count C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-13 13:26:29 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:26:51 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 06:26:51 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 06:26:51 --> Severity: Notice --> Undefined variable: agency_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-13 06:26:51 --> Severity: Notice --> Undefined variable: apply_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-13 06:26:51 --> Severity: Notice --> Undefined variable: volunteer_count C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-13 06:26:51 --> Severity: Notice --> Undefined variable: report_count C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-13 13:26:51 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:27:11 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 06:27:11 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 06:27:11 --> Severity: Notice --> Undefined variable: agency_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-13 06:27:11 --> Severity: Notice --> Undefined variable: apply_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-13 06:27:11 --> Severity: Notice --> Undefined variable: volunteer_count C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-13 06:27:11 --> Severity: Notice --> Undefined variable: report_count C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-13 13:27:11 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:27:22 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 06:27:22 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 06:27:22 --> Severity: Notice --> Undefined variable: agency_count C:\xampp\htdocs\application\views\admin\dashboard.php 79
ERROR - 2020-07-13 06:27:22 --> Severity: Notice --> Undefined variable: apply_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-13 06:27:22 --> Severity: Notice --> Undefined variable: volunteer_count C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-13 06:27:22 --> Severity: Notice --> Undefined variable: report_count C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-13 13:27:22 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:29:41 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 06:29:41 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 06:29:41 --> Severity: Notice --> Undefined variable: apply_count C:\xampp\htdocs\application\views\admin\dashboard.php 95
ERROR - 2020-07-13 06:29:41 --> Severity: Notice --> Undefined variable: volunteer_count C:\xampp\htdocs\application\views\admin\dashboard.php 110
ERROR - 2020-07-13 06:29:41 --> Severity: Notice --> Undefined variable: report_count C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-13 13:29:41 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:32:03 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 06:32:03 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 13:32:03 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:32:36 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 06:32:36 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 13:32:37 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:34:44 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 06:34:44 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 13:34:45 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:35:57 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 06:35:57 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 13:35:57 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:37:31 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 06:37:31 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 13:37:32 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 13:38:00 --> 404 Page Not Found: Admin/users
ERROR - 2020-07-13 06:38:06 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 06:38:06 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 13:38:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:38:08 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 06:38:08 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 13:38:08 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:38:29 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 06:38:29 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 13:38:30 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:38:34 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 06:38:34 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 13:38:34 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:38:35 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 06:38:35 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 13:38:36 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:38:36 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 06:38:36 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 13:38:37 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:38:37 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 06:38:37 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 13:38:38 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:38:38 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 06:38:38 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 13:38:38 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:38:39 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 06:38:39 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 13:38:39 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:38:44 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 06:38:44 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 13:38:45 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:38:45 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 06:38:45 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 13:38:46 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:38:47 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 06:38:47 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 13:38:47 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:38:51 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 06:38:51 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 13:38:51 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:38:54 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 06:38:54 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 13:38:54 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:38:55 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 06:38:55 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 13:38:56 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:39:04 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 06:39:04 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 13:39:04 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:39:07 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 06:39:07 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 13:39:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 13:50:04 --> 404 Page Not Found: Admin/users
ERROR - 2020-07-13 06:50:08 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 06:50:08 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 13:50:08 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:53:09 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 06:53:09 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 06:53:09 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-13 06:53:09 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 71
ERROR - 2020-07-13 06:53:09 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 71
ERROR - 2020-07-13 06:53:09 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 80
ERROR - 2020-07-13 06:53:09 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\application\views\admin\users.php 95
ERROR - 2020-07-13 06:53:09 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 97
ERROR - 2020-07-13 06:53:09 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 97
ERROR - 2020-07-13 06:53:09 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\application\views\admin\users.php 102
ERROR - 2020-07-13 06:53:09 --> Severity: Notice --> Undefined property: stdClass::$dob C:\xampp\htdocs\application\views\admin\users.php 111
ERROR - 2020-07-13 06:53:09 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 112
ERROR - 2020-07-13 06:53:09 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 112
ERROR - 2020-07-13 06:53:09 --> Severity: Notice --> Undefined property: stdClass::$gender C:\xampp\htdocs\application\views\admin\users.php 118
ERROR - 2020-07-13 06:53:09 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 122
ERROR - 2020-07-13 06:53:09 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\application\views\admin\users.php 95
ERROR - 2020-07-13 06:53:09 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 97
ERROR - 2020-07-13 06:53:09 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 97
ERROR - 2020-07-13 06:53:09 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\application\views\admin\users.php 102
ERROR - 2020-07-13 06:53:09 --> Severity: Notice --> Undefined property: stdClass::$dob C:\xampp\htdocs\application\views\admin\users.php 111
ERROR - 2020-07-13 06:53:09 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 112
ERROR - 2020-07-13 06:53:09 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 112
ERROR - 2020-07-13 06:53:09 --> Severity: Notice --> Undefined property: stdClass::$gender C:\xampp\htdocs\application\views\admin\users.php 118
ERROR - 2020-07-13 06:53:09 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 122
ERROR - 2020-07-13 13:53:09 --> 404 Page Not Found: Admin/%3Cdiv
ERROR - 2020-07-13 13:53:10 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 13:53:12 --> 404 Page Not Found: Api/sendTestMail
ERROR - 2020-07-13 06:53:14 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 06:53:14 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 06:53:14 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-13 06:53:14 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 71
ERROR - 2020-07-13 06:53:14 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 71
ERROR - 2020-07-13 06:53:14 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 80
ERROR - 2020-07-13 06:53:14 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\application\views\admin\users.php 95
ERROR - 2020-07-13 06:53:14 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 97
ERROR - 2020-07-13 06:53:14 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 97
ERROR - 2020-07-13 06:53:14 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\application\views\admin\users.php 102
ERROR - 2020-07-13 06:53:14 --> Severity: Notice --> Undefined property: stdClass::$dob C:\xampp\htdocs\application\views\admin\users.php 111
ERROR - 2020-07-13 06:53:14 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 112
ERROR - 2020-07-13 06:53:14 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 112
ERROR - 2020-07-13 06:53:14 --> Severity: Notice --> Undefined property: stdClass::$gender C:\xampp\htdocs\application\views\admin\users.php 118
ERROR - 2020-07-13 06:53:14 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 122
ERROR - 2020-07-13 06:53:14 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\application\views\admin\users.php 95
ERROR - 2020-07-13 06:53:14 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 97
ERROR - 2020-07-13 06:53:14 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 97
ERROR - 2020-07-13 06:53:14 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\application\views\admin\users.php 102
ERROR - 2020-07-13 06:53:14 --> Severity: Notice --> Undefined property: stdClass::$dob C:\xampp\htdocs\application\views\admin\users.php 111
ERROR - 2020-07-13 06:53:14 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 112
ERROR - 2020-07-13 06:53:14 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 112
ERROR - 2020-07-13 06:53:14 --> Severity: Notice --> Undefined property: stdClass::$gender C:\xampp\htdocs\application\views\admin\users.php 118
ERROR - 2020-07-13 06:53:14 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 122
ERROR - 2020-07-13 13:53:15 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:54:33 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 06:54:33 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 06:54:33 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-13 06:54:33 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 71
ERROR - 2020-07-13 06:54:33 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 71
ERROR - 2020-07-13 06:54:33 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 80
ERROR - 2020-07-13 06:54:33 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\application\views\admin\users.php 95
ERROR - 2020-07-13 06:54:33 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 97
ERROR - 2020-07-13 06:54:33 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 97
ERROR - 2020-07-13 06:54:33 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\application\views\admin\users.php 102
ERROR - 2020-07-13 06:54:33 --> Severity: Notice --> Undefined property: stdClass::$dob C:\xampp\htdocs\application\views\admin\users.php 111
ERROR - 2020-07-13 06:54:33 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 112
ERROR - 2020-07-13 06:54:33 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 112
ERROR - 2020-07-13 06:54:33 --> Severity: Notice --> Undefined property: stdClass::$gender C:\xampp\htdocs\application\views\admin\users.php 118
ERROR - 2020-07-13 06:54:33 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 122
ERROR - 2020-07-13 06:54:33 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\application\views\admin\users.php 95
ERROR - 2020-07-13 06:54:33 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 97
ERROR - 2020-07-13 06:54:33 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 97
ERROR - 2020-07-13 06:54:33 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\application\views\admin\users.php 102
ERROR - 2020-07-13 06:54:33 --> Severity: Notice --> Undefined property: stdClass::$dob C:\xampp\htdocs\application\views\admin\users.php 111
ERROR - 2020-07-13 06:54:33 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 112
ERROR - 2020-07-13 06:54:33 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 112
ERROR - 2020-07-13 06:54:33 --> Severity: Notice --> Undefined property: stdClass::$gender C:\xampp\htdocs\application\views\admin\users.php 118
ERROR - 2020-07-13 06:54:33 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 122
ERROR - 2020-07-13 13:54:33 --> 404 Page Not Found: Admin/%3Cdiv
ERROR - 2020-07-13 13:54:34 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:54:36 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 06:54:36 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 13:54:36 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 06:54:38 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 06:54:38 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 06:54:38 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-13 06:54:38 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 71
ERROR - 2020-07-13 06:54:38 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 71
ERROR - 2020-07-13 06:54:38 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 80
ERROR - 2020-07-13 06:54:38 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\application\views\admin\users.php 95
ERROR - 2020-07-13 06:54:38 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 97
ERROR - 2020-07-13 06:54:38 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 97
ERROR - 2020-07-13 06:54:38 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\application\views\admin\users.php 102
ERROR - 2020-07-13 06:54:38 --> Severity: Notice --> Undefined property: stdClass::$dob C:\xampp\htdocs\application\views\admin\users.php 111
ERROR - 2020-07-13 06:54:38 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 112
ERROR - 2020-07-13 06:54:38 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 112
ERROR - 2020-07-13 06:54:38 --> Severity: Notice --> Undefined property: stdClass::$gender C:\xampp\htdocs\application\views\admin\users.php 118
ERROR - 2020-07-13 06:54:38 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 122
ERROR - 2020-07-13 06:54:38 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\application\views\admin\users.php 95
ERROR - 2020-07-13 06:54:38 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 97
ERROR - 2020-07-13 06:54:38 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 97
ERROR - 2020-07-13 06:54:38 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\application\views\admin\users.php 102
ERROR - 2020-07-13 06:54:38 --> Severity: Notice --> Undefined property: stdClass::$dob C:\xampp\htdocs\application\views\admin\users.php 111
ERROR - 2020-07-13 06:54:38 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 112
ERROR - 2020-07-13 06:54:38 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 112
ERROR - 2020-07-13 06:54:38 --> Severity: Notice --> Undefined property: stdClass::$gender C:\xampp\htdocs\application\views\admin\users.php 118
ERROR - 2020-07-13 06:54:38 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 122
ERROR - 2020-07-13 13:54:38 --> 404 Page Not Found: Admin/%3Cdiv
ERROR - 2020-07-13 13:54:38 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 07:05:59 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 07:05:59 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 14:05:59 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 07:06:01 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 07:06:01 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 07:06:01 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-13 07:06:01 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 71
ERROR - 2020-07-13 07:06:01 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 71
ERROR - 2020-07-13 07:06:01 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 80
ERROR - 2020-07-13 07:06:01 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\application\views\admin\users.php 95
ERROR - 2020-07-13 07:06:01 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 97
ERROR - 2020-07-13 07:06:01 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 97
ERROR - 2020-07-13 07:06:01 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\application\views\admin\users.php 102
ERROR - 2020-07-13 07:06:01 --> Severity: Notice --> Undefined property: stdClass::$dob C:\xampp\htdocs\application\views\admin\users.php 111
ERROR - 2020-07-13 07:06:01 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 112
ERROR - 2020-07-13 07:06:01 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 112
ERROR - 2020-07-13 07:06:01 --> Severity: Notice --> Undefined property: stdClass::$gender C:\xampp\htdocs\application\views\admin\users.php 118
ERROR - 2020-07-13 07:06:01 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 122
ERROR - 2020-07-13 07:06:01 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\application\views\admin\users.php 95
ERROR - 2020-07-13 07:06:01 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 97
ERROR - 2020-07-13 07:06:01 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 97
ERROR - 2020-07-13 07:06:01 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\application\views\admin\users.php 102
ERROR - 2020-07-13 07:06:01 --> Severity: Notice --> Undefined property: stdClass::$dob C:\xampp\htdocs\application\views\admin\users.php 111
ERROR - 2020-07-13 07:06:01 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 112
ERROR - 2020-07-13 07:06:01 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 112
ERROR - 2020-07-13 07:06:01 --> Severity: Notice --> Undefined property: stdClass::$gender C:\xampp\htdocs\application\views\admin\users.php 118
ERROR - 2020-07-13 07:06:01 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 122
ERROR - 2020-07-13 14:06:01 --> 404 Page Not Found: Admin/%3Cdiv
ERROR - 2020-07-13 14:06:02 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 07:17:36 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 07:17:36 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 07:17:36 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-13 07:17:36 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\application\views\admin\users.php 92
ERROR - 2020-07-13 07:17:36 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\application\views\admin\users.php 92
ERROR - 2020-07-13 14:17:37 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 07:17:56 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 07:17:56 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 07:17:56 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-13 14:17:57 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 07:20:36 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 07:20:36 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 07:20:36 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-13 14:20:37 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 07:21:56 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 07:21:56 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 07:21:56 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-13 14:21:56 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 07:32:45 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 07:32:45 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 07:32:45 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-13 14:32:46 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 14:32:50 --> 404 Page Not Found: Admin/report
ERROR - 2020-07-13 07:34:39 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 07:34:39 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 07:34:39 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\report.php 52
ERROR - 2020-07-13 14:34:40 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 07:35:19 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 07:35:19 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 07:35:19 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\report.php 52
ERROR - 2020-07-13 14:35:20 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 07:38:15 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 07:38:15 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 07:38:15 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\report.php 52
ERROR - 2020-07-13 14:38:15 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 07:38:16 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 07:38:16 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 07:38:16 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\report.php 52
ERROR - 2020-07-13 14:38:17 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 07:38:23 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 07:38:23 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 07:38:23 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\report.php 52
ERROR - 2020-07-13 14:38:24 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 07:38:29 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 07:38:29 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 07:38:29 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\report.php 52
ERROR - 2020-07-13 14:38:30 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 07:38:31 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 07:38:31 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 07:38:31 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\report.php 52
ERROR - 2020-07-13 14:38:31 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 07:38:33 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 07:38:33 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 07:38:33 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\report.php 52
ERROR - 2020-07-13 14:38:37 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 07:38:43 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 07:38:43 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 07:38:43 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\application\views\admin\dashboard.php 135
ERROR - 2020-07-13 14:38:44 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 07:39:35 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 07:39:35 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 14:39:35 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 07:39:43 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 07:39:43 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 14:39:43 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 14:41:47 --> Severity: error --> Exception: syntax error, unexpected ''confirm'' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ')' C:\xampp\htdocs\application\controllers\Admin.php 261
ERROR - 2020-07-13 14:41:56 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' C:\xampp\htdocs\application\controllers\Admin.php 261
ERROR - 2020-07-13 14:43:09 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' C:\xampp\htdocs\application\controllers\Admin.php 261
ERROR - 2020-07-13 14:43:41 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' C:\xampp\htdocs\application\controllers\Admin.php 261
ERROR - 2020-07-13 07:44:14 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 07:44:14 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 07:44:14 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\report.php 52
ERROR - 2020-07-13 14:44:15 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 07:44:27 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 07:44:27 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 07:44:27 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\report.php 52
ERROR - 2020-07-13 14:44:28 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 07:49:11 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 07:49:11 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 07:49:11 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\report.php 52
ERROR - 2020-07-13 07:49:11 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\application\views\admin\report.php 80
ERROR - 2020-07-13 14:49:12 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 07:49:38 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 07:49:38 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 07:49:38 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\report.php 52
ERROR - 2020-07-13 14:49:39 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 14:49:42 --> 404 Page Not Found: Admin/updaterefund
ERROR - 2020-07-13 07:49:47 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 07:49:47 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 07:49:47 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\report.php 52
ERROR - 2020-07-13 14:49:48 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 14:49:52 --> 404 Page Not Found: Admin/updaterefund
ERROR - 2020-07-13 14:49:55 --> 404 Page Not Found: Admin/updaterefund
ERROR - 2020-07-13 07:50:07 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 07:50:07 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 07:50:07 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\report.php 52
ERROR - 2020-07-13 14:50:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 07:50:17 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 07:50:17 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 07:50:17 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\report.php 52
ERROR - 2020-07-13 14:50:17 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 07:54:06 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 07:54:06 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 07:54:06 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\report.php 52
ERROR - 2020-07-13 14:54:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 14:54:09 --> 404 Page Not Found: Admin/updaterefund
ERROR - 2020-07-13 07:54:13 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 07:54:13 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 07:54:13 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\report.php 52
ERROR - 2020-07-13 14:54:13 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 07:55:08 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 07:55:08 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 07:55:08 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\report.php 52
ERROR - 2020-07-13 14:55:09 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 07:55:21 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 07:55:21 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 07:55:21 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\report.php 52
ERROR - 2020-07-13 14:55:22 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 07:55:26 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 07:55:26 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 14:55:26 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 07:55:35 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 07:55:35 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 07:55:35 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\report.php 52
ERROR - 2020-07-13 14:55:35 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 07:55:46 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 07:55:46 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 14:55:46 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 07:55:48 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 07:55:48 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 07:55:48 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\report.php 52
ERROR - 2020-07-13 14:55:48 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 15:00:37 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\application\controllers\Admin.php 262
ERROR - 2020-07-13 08:00:50 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 08:00:50 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 15:00:51 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 08:00:54 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 08:00:54 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 08:00:54 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\volunteer.php 52
ERROR - 2020-07-13 15:00:54 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 08:37:04 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 08:37:04 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 08:37:04 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\volunteer.php 52
ERROR - 2020-07-13 15:37:04 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 08:37:05 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 08:37:05 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 08:37:05 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\report.php 52
ERROR - 2020-07-13 15:37:06 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 08:37:07 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 08:37:07 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 08:37:07 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\volunteer.php 52
ERROR - 2020-07-13 15:37:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 08:37:07 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 08:37:07 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 08:37:07 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\report.php 52
ERROR - 2020-07-13 15:37:08 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 08:38:25 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 08:38:25 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 08:38:25 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\apply.php 52
ERROR - 2020-07-13 15:38:26 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 08:38:38 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 08:38:38 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 08:38:38 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\volunteer.php 52
ERROR - 2020-07-13 15:38:38 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 08:38:39 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 08:38:39 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 08:38:39 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\report.php 52
ERROR - 2020-07-13 15:38:40 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 08:38:40 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 08:38:40 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 08:38:40 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\volunteer.php 52
ERROR - 2020-07-13 15:38:40 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 08:38:41 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 08:38:41 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 08:38:41 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\apply.php 52
ERROR - 2020-07-13 15:38:41 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 08:38:43 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 08:38:43 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 08:38:43 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\volunteer.php 52
ERROR - 2020-07-13 15:38:43 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 08:38:44 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 08:38:44 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 08:38:44 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\apply.php 52
ERROR - 2020-07-13 15:38:44 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 08:38:46 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 08:38:46 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 08:38:46 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\volunteer.php 52
ERROR - 2020-07-13 15:38:46 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 08:38:47 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 08:38:47 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 08:38:47 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\apply.php 52
ERROR - 2020-07-13 15:38:47 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 15:41:17 --> Severity: Compile Error --> Cannot redeclare Admin::apply() C:\xampp\htdocs\application\controllers\Admin.php 284
ERROR - 2020-07-13 08:41:36 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 08:41:36 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 08:41:36 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\apply.php 52
ERROR - 2020-07-13 15:41:37 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 08:41:38 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 08:41:38 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 08:41:38 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\agency.php 52
ERROR - 2020-07-13 15:41:39 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 08:42:08 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 08:42:08 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 08:42:08 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\agency.php 52
ERROR - 2020-07-13 15:42:08 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 08:45:22 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 08:45:22 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 08:45:22 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\money.php 52
ERROR - 2020-07-13 15:45:22 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 08:45:58 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 08:45:58 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 08:45:58 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\money.php 52
ERROR - 2020-07-13 15:45:58 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 15:47:33 --> Severity: Compile Error --> Cannot redeclare Admin::money() C:\xampp\htdocs\application\controllers\Admin.php 268
ERROR - 2020-07-13 08:47:41 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 08:47:41 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 08:47:41 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\mask.php 52
ERROR - 2020-07-13 15:47:41 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 08:47:48 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 08:47:48 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 08:47:48 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\mask.php 52
ERROR - 2020-07-13 15:47:48 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 08:47:50 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 08:47:50 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 08:47:50 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\money.php 52
ERROR - 2020-07-13 15:47:51 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 09:27:32 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 09:27:32 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 16:27:33 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 09:27:35 --> Severity: error --> Exception: Call to a member function num_rows() on array C:\xampp\htdocs\application\controllers\Admin.php 264
ERROR - 2020-07-13 16:30:22 --> Severity: error --> Exception: syntax error, unexpected 'var' (T_VAR) C:\xampp\htdocs\application\controllers\Admin.php 265
ERROR - 2020-07-13 09:30:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Admin.php 274
ERROR - 2020-07-13 09:30:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Admin.php 274
ERROR - 2020-07-13 09:30:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Admin.php 275
ERROR - 2020-07-13 09:30:34 --> Severity: Warning --> date() expects parameter 2 to be integer, string given C:\xampp\htdocs\application\controllers\Admin.php 277
ERROR - 2020-07-13 09:30:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Admin.php 274
ERROR - 2020-07-13 09:30:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Admin.php 274
ERROR - 2020-07-13 09:30:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Admin.php 275
ERROR - 2020-07-13 09:30:34 --> Severity: Warning --> date() expects parameter 2 to be integer, string given C:\xampp\htdocs\application\controllers\Admin.php 277
ERROR - 2020-07-13 09:30:34 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 09:30:34 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 09:30:34 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\simple_answer.php 52
ERROR - 2020-07-13 09:30:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 09:30:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 76
ERROR - 2020-07-13 09:30:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 77
ERROR - 2020-07-13 09:30:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 78
ERROR - 2020-07-13 09:30:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 79
ERROR - 2020-07-13 09:30:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 09:30:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 76
ERROR - 2020-07-13 09:30:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 77
ERROR - 2020-07-13 09:30:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 78
ERROR - 2020-07-13 09:30:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 79
ERROR - 2020-07-13 09:34:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Admin.php 274
ERROR - 2020-07-13 09:34:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Admin.php 274
ERROR - 2020-07-13 09:34:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Admin.php 275
ERROR - 2020-07-13 09:34:14 --> Severity: Warning --> date() expects parameter 2 to be integer, string given C:\xampp\htdocs\application\controllers\Admin.php 277
ERROR - 2020-07-13 09:34:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Admin.php 274
ERROR - 2020-07-13 09:34:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Admin.php 274
ERROR - 2020-07-13 09:34:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Admin.php 275
ERROR - 2020-07-13 09:34:14 --> Severity: Warning --> date() expects parameter 2 to be integer, string given C:\xampp\htdocs\application\controllers\Admin.php 277
ERROR - 2020-07-13 09:34:14 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 09:34:14 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 09:34:14 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\simple_answer.php 52
ERROR - 2020-07-13 09:34:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 09:34:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 76
ERROR - 2020-07-13 09:34:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 77
ERROR - 2020-07-13 09:34:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 78
ERROR - 2020-07-13 09:34:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 79
ERROR - 2020-07-13 09:34:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 09:34:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 76
ERROR - 2020-07-13 09:34:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 77
ERROR - 2020-07-13 09:34:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 78
ERROR - 2020-07-13 09:34:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 79
ERROR - 2020-07-13 09:36:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Admin.php 275
ERROR - 2020-07-13 09:36:40 --> Severity: Warning --> date() expects parameter 2 to be integer, string given C:\xampp\htdocs\application\controllers\Admin.php 277
ERROR - 2020-07-13 09:36:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Admin.php 275
ERROR - 2020-07-13 09:36:40 --> Severity: Warning --> date() expects parameter 2 to be integer, string given C:\xampp\htdocs\application\controllers\Admin.php 277
ERROR - 2020-07-13 09:36:40 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 09:36:40 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 09:36:40 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\simple_answer.php 52
ERROR - 2020-07-13 09:36:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 09:36:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 76
ERROR - 2020-07-13 09:36:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 77
ERROR - 2020-07-13 09:36:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 78
ERROR - 2020-07-13 09:36:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 79
ERROR - 2020-07-13 09:36:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 09:36:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 76
ERROR - 2020-07-13 09:36:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 77
ERROR - 2020-07-13 09:36:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 78
ERROR - 2020-07-13 09:36:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 79
ERROR - 2020-07-13 09:36:53 --> Severity: Warning --> date() expects parameter 2 to be integer, string given C:\xampp\htdocs\application\controllers\Admin.php 277
ERROR - 2020-07-13 09:36:53 --> Severity: Warning --> date() expects parameter 2 to be integer, string given C:\xampp\htdocs\application\controllers\Admin.php 277
ERROR - 2020-07-13 09:36:53 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 09:36:53 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 09:36:53 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\simple_answer.php 52
ERROR - 2020-07-13 09:36:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 09:36:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 76
ERROR - 2020-07-13 09:36:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 77
ERROR - 2020-07-13 09:36:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 78
ERROR - 2020-07-13 09:36:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 79
ERROR - 2020-07-13 09:36:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 09:36:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 76
ERROR - 2020-07-13 09:36:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 77
ERROR - 2020-07-13 09:36:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 78
ERROR - 2020-07-13 09:36:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 79
ERROR - 2020-07-13 09:39:12 --> Severity: Warning --> date() expects parameter 2 to be integer, string given C:\xampp\htdocs\application\controllers\Admin.php 277
ERROR - 2020-07-13 09:39:12 --> Severity: Warning --> date() expects parameter 2 to be integer, string given C:\xampp\htdocs\application\controllers\Admin.php 277
ERROR - 2020-07-13 09:39:12 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 09:39:12 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 09:39:12 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\simple_answer.php 52
ERROR - 2020-07-13 09:39:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 09:39:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 09:39:45 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 09:39:45 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 09:39:45 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\simple_answer.php 52
ERROR - 2020-07-13 09:39:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 09:39:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 16:39:46 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 09:40:09 --> Severity: Warning --> date() expects parameter 2 to be integer, float given C:\xampp\htdocs\application\controllers\Admin.php 277
ERROR - 2020-07-13 09:40:09 --> Severity: Warning --> date() expects parameter 2 to be integer, float given C:\xampp\htdocs\application\controllers\Admin.php 277
ERROR - 2020-07-13 09:40:09 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 09:40:09 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 09:40:09 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\simple_answer.php 52
ERROR - 2020-07-13 09:40:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 09:40:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 09:40:17 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 09:40:17 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 09:40:17 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\simple_answer.php 52
ERROR - 2020-07-13 09:40:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 09:40:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 16:40:17 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 09:40:48 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 09:40:48 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 09:40:48 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\simple_answer.php 52
ERROR - 2020-07-13 09:40:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 09:40:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 16:40:49 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 09:41:49 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 09:41:49 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 09:41:49 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\simple_answer.php 52
ERROR - 2020-07-13 09:41:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 09:41:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 16:41:50 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 09:42:01 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 09:42:01 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 09:42:01 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\simple_answer.php 52
ERROR - 2020-07-13 09:42:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 09:42:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 16:42:01 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 09:42:08 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 09:42:08 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 09:42:08 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\simple_answer.php 52
ERROR - 2020-07-13 09:42:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 09:42:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 16:42:08 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 09:42:12 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 09:42:12 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 09:42:12 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\simple_answer.php 52
ERROR - 2020-07-13 09:42:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 09:42:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 16:42:13 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 09:44:37 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 09:44:37 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 09:44:37 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\simple_answer.php 52
ERROR - 2020-07-13 09:44:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 09:44:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 16:44:38 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 09:44:56 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 09:44:56 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 09:44:56 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\simple_answer.php 52
ERROR - 2020-07-13 09:44:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 09:44:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 16:44:57 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 09:45:24 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 09:45:24 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 09:45:24 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\simple_answer.php 52
ERROR - 2020-07-13 09:45:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 09:45:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 16:45:24 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 16:45:46 --> Severity: Notice --> date_default_timezone_set(): Timezone ID 'London' is invalid C:\xampp\htdocs\application\controllers\Admin.php 36
ERROR - 2020-07-13 16:45:46 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 16:45:46 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 09:45:46 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\simple_answer.php 52
ERROR - 2020-07-13 09:45:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 09:45:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 16:45:58 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 16:45:58 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 09:45:58 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\simple_answer.php 52
ERROR - 2020-07-13 09:45:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 09:45:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 16:45:59 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 09:46:11 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 09:46:11 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 09:46:11 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\simple_answer.php 52
ERROR - 2020-07-13 09:46:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 09:46:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 16:46:11 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 14:47:16 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 14:47:16 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 09:47:16 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\simple_answer.php 52
ERROR - 2020-07-13 09:47:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 09:47:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 16:47:17 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 14:47:30 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 14:47:30 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 09:47:30 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\report.php 52
ERROR - 2020-07-13 16:47:31 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 14:47:54 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 14:47:54 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 09:47:54 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\simple_answer.php 52
ERROR - 2020-07-13 09:47:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 09:47:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 16:47:54 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 14:48:26 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 14:48:26 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 09:48:26 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\simple_answer.php 52
ERROR - 2020-07-13 09:48:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 09:48:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 16:48:27 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 17:17:38 --> Severity: Compile Error --> Cannot redeclare Admin::simple_answer() C:\xampp\htdocs\application\controllers\Admin.php 290
ERROR - 2020-07-13 17:17:40 --> Severity: Compile Error --> Cannot redeclare Admin::simple_answer() C:\xampp\htdocs\application\controllers\Admin.php 290
ERROR - 2020-07-13 17:17:42 --> Severity: Compile Error --> Cannot redeclare Admin::simple_answer() C:\xampp\htdocs\application\controllers\Admin.php 290
ERROR - 2020-07-13 15:17:58 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 15:17:58 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 10:17:58 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\simple_answer.php 52
ERROR - 2020-07-13 10:17:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 10:17:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 17:17:58 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 17:18:01 --> 404 Page Not Found: Admin/choice_answer
ERROR - 2020-07-13 15:18:14 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 15:18:14 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 10:18:14 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\simple_answer.php 52
ERROR - 2020-07-13 10:18:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 10:18:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 17:18:14 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 15:18:17 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 15:18:17 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 10:18:17 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\simple_answer.php 52
ERROR - 2020-07-13 10:18:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 10:18:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 17:18:17 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 15:18:19 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 15:18:19 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 10:18:19 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\simple_answer.php 52
ERROR - 2020-07-13 10:18:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 10:18:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 17:18:19 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 16:01:56 --> Severity: Notice --> Undefined variable: choice_question_ids C:\xampp\htdocs\application\controllers\Admin.php 313
ERROR - 2020-07-13 16:01:56 --> Severity: Notice --> Undefined variable: choice_question_ids C:\xampp\htdocs\application\controllers\Admin.php 313
ERROR - 2020-07-13 16:01:56 --> Severity: Notice --> Undefined variable: choice_question_ids C:\xampp\htdocs\application\controllers\Admin.php 313
ERROR - 2020-07-13 16:01:56 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 16:01:56 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 11:01:56 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\simple_answer.php 52
ERROR - 2020-07-13 11:01:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 11:01:56 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\application\views\admin\simple_answer.php 78
ERROR - 2020-07-13 11:01:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 11:01:56 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\application\views\admin\simple_answer.php 78
ERROR - 2020-07-13 11:01:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 11:01:56 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\application\views\admin\simple_answer.php 78
ERROR - 2020-07-13 16:02:36 --> Severity: Notice --> Undefined variable: choice_question_ids C:\xampp\htdocs\application\controllers\Admin.php 313
ERROR - 2020-07-13 16:02:36 --> Severity: Notice --> Undefined variable: choice_question_ids C:\xampp\htdocs\application\controllers\Admin.php 313
ERROR - 2020-07-13 16:02:36 --> Severity: Notice --> Undefined variable: choice_question_ids C:\xampp\htdocs\application\controllers\Admin.php 313
ERROR - 2020-07-13 16:02:36 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 16:02:36 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 11:02:36 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\multiple_answer.php 53
ERROR - 2020-07-13 11:02:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 75
ERROR - 2020-07-13 11:02:36 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\application\views\admin\multiple_answer.php 79
ERROR - 2020-07-13 11:02:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 75
ERROR - 2020-07-13 11:02:36 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\application\views\admin\multiple_answer.php 79
ERROR - 2020-07-13 11:02:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 75
ERROR - 2020-07-13 11:02:36 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\application\views\admin\multiple_answer.php 79
ERROR - 2020-07-13 16:02:42 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 16:02:42 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 11:02:42 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\simple_answer.php 52
ERROR - 2020-07-13 11:02:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 11:02:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 18:02:42 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 16:02:45 --> Severity: Notice --> Undefined variable: choice_question_ids C:\xampp\htdocs\application\controllers\Admin.php 313
ERROR - 2020-07-13 16:02:45 --> Severity: Notice --> Undefined variable: choice_question_ids C:\xampp\htdocs\application\controllers\Admin.php 313
ERROR - 2020-07-13 16:02:45 --> Severity: Notice --> Undefined variable: choice_question_ids C:\xampp\htdocs\application\controllers\Admin.php 313
ERROR - 2020-07-13 16:02:45 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 16:02:45 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 11:02:45 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\multiple_answer.php 53
ERROR - 2020-07-13 11:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 75
ERROR - 2020-07-13 11:02:45 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\application\views\admin\multiple_answer.php 79
ERROR - 2020-07-13 11:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 75
ERROR - 2020-07-13 11:02:45 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\application\views\admin\multiple_answer.php 79
ERROR - 2020-07-13 11:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 75
ERROR - 2020-07-13 11:02:45 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\application\views\admin\multiple_answer.php 79
ERROR - 2020-07-13 16:05:55 --> Severity: Notice --> Undefined variable: choice_question_ids C:\xampp\htdocs\application\controllers\Admin.php 313
ERROR - 2020-07-13 16:05:56 --> Severity: Notice --> Undefined variable: choice_question_ids C:\xampp\htdocs\application\controllers\Admin.php 313
ERROR - 2020-07-13 16:05:56 --> Severity: Notice --> Undefined variable: choice_question_ids C:\xampp\htdocs\application\controllers\Admin.php 313
ERROR - 2020-07-13 16:05:56 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 16:05:56 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 11:05:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 33
ERROR - 2020-07-13 11:05:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 34
ERROR - 2020-07-13 11:05:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 35
ERROR - 2020-07-13 11:05:56 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\multiple_answer.php 56
ERROR - 2020-07-13 11:05:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 78
ERROR - 2020-07-13 11:05:56 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\application\views\admin\multiple_answer.php 82
ERROR - 2020-07-13 11:05:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 78
ERROR - 2020-07-13 11:05:56 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\application\views\admin\multiple_answer.php 82
ERROR - 2020-07-13 11:05:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 78
ERROR - 2020-07-13 11:05:56 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\application\views\admin\multiple_answer.php 82
ERROR - 2020-07-13 16:06:55 --> Severity: Notice --> Undefined variable: choice_question_ids C:\xampp\htdocs\application\controllers\Admin.php 313
ERROR - 2020-07-13 16:06:55 --> Severity: Notice --> Undefined variable: choice_question_ids C:\xampp\htdocs\application\controllers\Admin.php 313
ERROR - 2020-07-13 16:06:55 --> Severity: Notice --> Undefined variable: choice_question_ids C:\xampp\htdocs\application\controllers\Admin.php 313
ERROR - 2020-07-13 16:06:55 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 16:06:55 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 11:06:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 33
ERROR - 2020-07-13 11:06:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 34
ERROR - 2020-07-13 11:06:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 35
ERROR - 2020-07-13 11:06:55 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\multiple_answer.php 56
ERROR - 2020-07-13 11:06:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 78
ERROR - 2020-07-13 11:06:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\application\views\admin\multiple_answer.php 82
ERROR - 2020-07-13 11:06:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 78
ERROR - 2020-07-13 11:06:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\application\views\admin\multiple_answer.php 82
ERROR - 2020-07-13 11:06:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 78
ERROR - 2020-07-13 11:06:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\application\views\admin\multiple_answer.php 82
ERROR - 2020-07-13 16:07:22 --> Severity: Notice --> Undefined variable: choice_question_ids C:\xampp\htdocs\application\controllers\Admin.php 313
ERROR - 2020-07-13 16:07:22 --> Severity: Notice --> Undefined variable: choice_question_ids C:\xampp\htdocs\application\controllers\Admin.php 313
ERROR - 2020-07-13 16:07:22 --> Severity: Notice --> Undefined variable: choice_question_ids C:\xampp\htdocs\application\controllers\Admin.php 313
ERROR - 2020-07-13 16:07:22 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 16:07:22 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 11:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 33
ERROR - 2020-07-13 11:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 34
ERROR - 2020-07-13 11:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 35
ERROR - 2020-07-13 11:07:22 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\multiple_answer.php 56
ERROR - 2020-07-13 11:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 78
ERROR - 2020-07-13 11:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 80
ERROR - 2020-07-13 11:07:22 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\application\views\admin\multiple_answer.php 82
ERROR - 2020-07-13 11:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 78
ERROR - 2020-07-13 11:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 80
ERROR - 2020-07-13 11:07:22 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\application\views\admin\multiple_answer.php 82
ERROR - 2020-07-13 11:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 78
ERROR - 2020-07-13 11:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 80
ERROR - 2020-07-13 11:07:22 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\application\views\admin\multiple_answer.php 82
ERROR - 2020-07-13 18:10:34 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ',' or ')' C:\xampp\htdocs\application\controllers\Admin.php 315
ERROR - 2020-07-13 18:10:53 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\application\controllers\Admin.php 318
ERROR - 2020-07-13 16:11:23 --> Severity: Notice --> Undefined variable: choice_question_ids C:\xampp\htdocs\application\controllers\Admin.php 313
ERROR - 2020-07-13 16:11:23 --> Severity: Notice --> Undefined variable: choice_question_ids C:\xampp\htdocs\application\controllers\Admin.php 313
ERROR - 2020-07-13 16:11:23 --> Severity: Notice --> Undefined variable: choice_question_ids C:\xampp\htdocs\application\controllers\Admin.php 313
ERROR - 2020-07-13 16:11:23 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 16:11:23 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 11:11:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 33
ERROR - 2020-07-13 11:11:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 34
ERROR - 2020-07-13 11:11:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 35
ERROR - 2020-07-13 11:11:23 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\multiple_answer.php 56
ERROR - 2020-07-13 11:11:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 78
ERROR - 2020-07-13 11:11:23 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\application\views\admin\multiple_answer.php 82
ERROR - 2020-07-13 11:11:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 78
ERROR - 2020-07-13 11:11:23 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\application\views\admin\multiple_answer.php 82
ERROR - 2020-07-13 11:11:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 78
ERROR - 2020-07-13 11:11:23 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\application\views\admin\multiple_answer.php 82
ERROR - 2020-07-13 16:11:50 --> Severity: Notice --> Undefined variable: choice_question_ids C:\xampp\htdocs\application\controllers\Admin.php 313
ERROR - 2020-07-13 16:11:50 --> Severity: Notice --> Undefined variable: choice_question_ids C:\xampp\htdocs\application\controllers\Admin.php 313
ERROR - 2020-07-13 16:11:50 --> Severity: Notice --> Undefined variable: choice_question_ids C:\xampp\htdocs\application\controllers\Admin.php 313
ERROR - 2020-07-13 16:11:50 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 16:11:50 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 11:11:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 33
ERROR - 2020-07-13 11:11:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 34
ERROR - 2020-07-13 11:11:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 35
ERROR - 2020-07-13 11:11:50 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\multiple_answer.php 56
ERROR - 2020-07-13 11:11:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 78
ERROR - 2020-07-13 11:11:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\multiple_answer.php 80
ERROR - 2020-07-13 11:11:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\application\views\admin\multiple_answer.php 82
ERROR - 2020-07-13 11:11:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 78
ERROR - 2020-07-13 11:11:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\multiple_answer.php 80
ERROR - 2020-07-13 11:11:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\application\views\admin\multiple_answer.php 82
ERROR - 2020-07-13 11:11:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 78
ERROR - 2020-07-13 11:11:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\multiple_answer.php 80
ERROR - 2020-07-13 11:11:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\application\views\admin\multiple_answer.php 82
ERROR - 2020-07-13 16:38:29 --> Severity: Notice --> Undefined variable: choice_question_ids C:\xampp\htdocs\application\controllers\Admin.php 313
ERROR - 2020-07-13 16:38:29 --> Severity: Notice --> Undefined variable: choice_question_ids C:\xampp\htdocs\application\controllers\Admin.php 313
ERROR - 2020-07-13 16:38:29 --> Severity: Notice --> Undefined variable: choice_question_ids C:\xampp\htdocs\application\controllers\Admin.php 313
ERROR - 2020-07-13 16:38:29 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 16:38:29 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 11:38:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 33
ERROR - 2020-07-13 11:38:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 34
ERROR - 2020-07-13 11:38:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 35
ERROR - 2020-07-13 11:38:29 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\multiple_answer.php 56
ERROR - 2020-07-13 11:38:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 78
ERROR - 2020-07-13 11:38:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\multiple_answer.php 80
ERROR - 2020-07-13 11:38:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\application\views\admin\multiple_answer.php 82
ERROR - 2020-07-13 11:38:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 78
ERROR - 2020-07-13 11:38:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\multiple_answer.php 80
ERROR - 2020-07-13 11:38:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\application\views\admin\multiple_answer.php 82
ERROR - 2020-07-13 11:38:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 78
ERROR - 2020-07-13 11:38:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\multiple_answer.php 80
ERROR - 2020-07-13 11:38:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\application\views\admin\multiple_answer.php 82
ERROR - 2020-07-13 16:44:15 --> Severity: Notice --> Undefined variable: choice_question_ids C:\xampp\htdocs\application\controllers\Admin.php 313
ERROR - 2020-07-13 16:44:15 --> Severity: Notice --> Undefined variable: choice_question_ids C:\xampp\htdocs\application\controllers\Admin.php 313
ERROR - 2020-07-13 16:44:15 --> Severity: Notice --> Undefined variable: choice_question_ids C:\xampp\htdocs\application\controllers\Admin.php 313
ERROR - 2020-07-13 16:44:15 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 16:44:15 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 11:44:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 33
ERROR - 2020-07-13 11:44:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 34
ERROR - 2020-07-13 11:44:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 35
ERROR - 2020-07-13 11:44:15 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\multiple_answer.php 56
ERROR - 2020-07-13 11:44:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 78
ERROR - 2020-07-13 11:44:15 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\application\views\admin\multiple_answer.php 82
ERROR - 2020-07-13 11:44:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 78
ERROR - 2020-07-13 11:44:15 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\application\views\admin\multiple_answer.php 82
ERROR - 2020-07-13 11:44:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 78
ERROR - 2020-07-13 11:44:15 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\application\views\admin\multiple_answer.php 82
ERROR - 2020-07-13 16:44:53 --> Severity: Notice --> Undefined variable: choice_question_ids C:\xampp\htdocs\application\controllers\Admin.php 313
ERROR - 2020-07-13 16:44:53 --> Severity: Notice --> Undefined variable: choice_question_ids C:\xampp\htdocs\application\controllers\Admin.php 313
ERROR - 2020-07-13 16:44:53 --> Severity: Notice --> Undefined variable: choice_question_ids C:\xampp\htdocs\application\controllers\Admin.php 313
ERROR - 2020-07-13 16:44:53 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 16:44:53 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 11:44:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 33
ERROR - 2020-07-13 11:44:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 34
ERROR - 2020-07-13 11:44:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 35
ERROR - 2020-07-13 11:44:53 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\multiple_answer.php 56
ERROR - 2020-07-13 11:44:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 78
ERROR - 2020-07-13 11:44:53 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\application\views\admin\multiple_answer.php 82
ERROR - 2020-07-13 11:44:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 78
ERROR - 2020-07-13 11:44:53 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\application\views\admin\multiple_answer.php 82
ERROR - 2020-07-13 11:44:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 78
ERROR - 2020-07-13 11:44:53 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\application\views\admin\multiple_answer.php 82
ERROR - 2020-07-13 16:45:21 --> Severity: Notice --> Undefined variable: choice_question_ids C:\xampp\htdocs\application\controllers\Admin.php 313
ERROR - 2020-07-13 16:45:21 --> Severity: Notice --> Undefined variable: choice_question_ids C:\xampp\htdocs\application\controllers\Admin.php 313
ERROR - 2020-07-13 16:45:21 --> Severity: Notice --> Undefined variable: choice_question_ids C:\xampp\htdocs\application\controllers\Admin.php 313
ERROR - 2020-07-13 16:45:21 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 16:45:21 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 11:45:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 33
ERROR - 2020-07-13 11:45:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 34
ERROR - 2020-07-13 11:45:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 35
ERROR - 2020-07-13 11:45:21 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\multiple_answer.php 56
ERROR - 2020-07-13 11:45:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 78
ERROR - 2020-07-13 11:45:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 78
ERROR - 2020-07-13 11:45:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 78
ERROR - 2020-07-13 16:45:39 --> Severity: Notice --> Undefined variable: choice_question_ids C:\xampp\htdocs\application\controllers\Admin.php 313
ERROR - 2020-07-13 16:45:39 --> Severity: Notice --> Undefined variable: choice_question_ids C:\xampp\htdocs\application\controllers\Admin.php 313
ERROR - 2020-07-13 16:45:39 --> Severity: Notice --> Undefined variable: choice_question_ids C:\xampp\htdocs\application\controllers\Admin.php 313
ERROR - 2020-07-13 16:45:39 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 16:45:39 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 11:45:39 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\multiple_answer.php 52
ERROR - 2020-07-13 11:45:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-13 11:45:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-13 11:45:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-13 16:46:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Admin.php 317
ERROR - 2020-07-13 16:46:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Admin.php 317
ERROR - 2020-07-13 16:46:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Admin.php 317
ERROR - 2020-07-13 16:46:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Admin.php 317
ERROR - 2020-07-13 16:46:28 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 16:46:28 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 11:46:28 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\multiple_answer.php 52
ERROR - 2020-07-13 11:46:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-13 11:46:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-13 11:46:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-13 16:47:47 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 16:47:47 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 11:47:47 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\multiple_answer.php 52
ERROR - 2020-07-13 11:47:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-13 11:47:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-13 11:47:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-13 18:47:47 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 16:49:01 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 16:49:01 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 11:49:01 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\multiple_answer.php 52
ERROR - 2020-07-13 11:49:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-13 11:49:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-13 11:49:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-13 18:49:02 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 16:52:35 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 16:52:35 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 11:52:35 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\multiple_answer.php 52
ERROR - 2020-07-13 11:52:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-13 11:52:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-13 11:52:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-13 18:52:35 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 16:53:13 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 16:53:13 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 11:53:13 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\multiple_answer.php 52
ERROR - 2020-07-13 11:53:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-13 11:53:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-13 11:53:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-13 18:53:14 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 16:53:46 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 16:53:46 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 11:53:46 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\multiple_answer.php 52
ERROR - 2020-07-13 11:53:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-13 11:53:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-13 11:53:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-13 18:53:46 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 16:53:55 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 16:53:55 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 11:53:55 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\simple_answer.php 52
ERROR - 2020-07-13 11:53:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 11:53:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 18:53:56 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 16:53:59 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 16:53:59 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 11:53:59 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\multiple_answer.php 52
ERROR - 2020-07-13 11:53:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-13 11:53:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-13 11:53:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-13 18:53:59 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 16:54:02 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 16:54:02 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 11:54:02 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\simple_answer.php 52
ERROR - 2020-07-13 11:54:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 11:54:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 18:54:03 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 16:54:04 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 16:54:04 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 11:54:04 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\multiple_answer.php 52
ERROR - 2020-07-13 11:54:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-13 11:54:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-13 11:54:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-13 18:54:04 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 16:54:25 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 16:54:25 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 18:54:26 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 16:54:29 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 16:54:29 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 11:54:29 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\multiple_answer.php 52
ERROR - 2020-07-13 11:54:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-13 11:54:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-13 11:54:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-13 18:54:29 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 18:58:13 --> 404 Page Not Found: Admin/simple
ERROR - 2020-07-13 16:58:16 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 16:58:16 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 11:58:16 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\multiple_answer.php 52
ERROR - 2020-07-13 11:58:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-13 11:58:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-13 11:58:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-13 18:58:16 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 16:58:18 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 16:58:18 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 11:58:18 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\agency.php 52
ERROR - 2020-07-13 18:58:18 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 16:58:19 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 16:58:19 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 11:58:19 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\apply.php 52
ERROR - 2020-07-13 18:58:19 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 16:58:20 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 16:58:20 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 11:58:20 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\volunteer.php 52
ERROR - 2020-07-13 18:58:20 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 16:58:21 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 16:58:21 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 11:58:21 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\report.php 52
ERROR - 2020-07-13 18:58:21 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 16:58:22 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 16:58:22 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 18:58:22 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 16:58:23 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 16:58:23 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 11:58:23 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-13 18:58:24 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 16:58:25 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 16:58:25 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 18:58:25 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 16:58:27 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 16:58:27 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 11:58:27 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-13 18:58:27 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 16:58:28 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 16:58:28 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 18:58:28 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 16:58:28 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 16:58:28 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 11:58:28 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\report.php 52
ERROR - 2020-07-13 18:58:28 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 16:58:31 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 16:58:31 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 11:58:31 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\volunteer.php 52
ERROR - 2020-07-13 18:58:31 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 16:58:32 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 16:58:32 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 11:58:32 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\apply.php 52
ERROR - 2020-07-13 18:58:32 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 16:58:33 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 16:58:33 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 11:58:33 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\agency.php 52
ERROR - 2020-07-13 18:58:33 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 16:58:34 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 16:58:34 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 11:58:34 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\money.php 52
ERROR - 2020-07-13 18:58:34 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 16:58:36 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 16:58:36 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 11:58:36 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\mask.php 52
ERROR - 2020-07-13 18:58:36 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 16:58:37 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 16:58:37 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 11:58:37 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\simple_answer.php 52
ERROR - 2020-07-13 11:58:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 11:58:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 18:58:37 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 16:58:39 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 16:58:39 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 11:58:39 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\multiple_answer.php 52
ERROR - 2020-07-13 11:58:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-13 11:58:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-13 11:58:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-13 18:58:39 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-13 23:40:25 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 23:40:25 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 23:40:29 --> Query error: Table 'ounited.tb_categories' doesn't exist - Invalid query: SELECT *
FROM `tb_categories`
WHERE `id` = 1594598400
ERROR - 2020-07-13 23:41:18 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 23:41:18 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 23:44:20 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 23:44:20 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 23:44:29 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 23:44:29 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 23:45:03 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 23:45:03 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 23:45:05 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 23:45:05 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 23:47:12 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 23:47:12 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 23:47:14 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 23:47:14 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 23:47:18 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 23:47:18 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 23:48:14 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 23:48:14 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 23:48:25 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 23:48:25 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 23:48:34 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 23:48:34 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 23:48:39 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 23:48:39 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 23:54:16 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 23:54:16 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 23:54:19 --> Query error: Table 'ounited.tb_categories' doesn't exist - Invalid query: UPDATE `tb_categories` SET `question` = 'ssss ss'
WHERE `id` = '2'
ERROR - 2020-07-13 23:54:31 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 23:54:31 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 23:54:56 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 23:54:56 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 23:54:59 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 23:54:59 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 23:55:09 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 23:55:09 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 23:55:13 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 23:55:13 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 23:57:01 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 23:57:01 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 23:57:01 --> Severity: Notice --> Undefined index: question C:\xampp\htdocs\application\views\admin\add_simple.php 28
ERROR - 2020-07-13 23:57:30 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 23:57:30 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 23:57:30 --> Severity: Notice --> Undefined index: question C:\xampp\htdocs\application\views\admin\add_simple.php 28
ERROR - 2020-07-13 23:57:37 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 23:57:37 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 23:57:37 --> Severity: Notice --> Undefined index: question C:\xampp\htdocs\application\views\admin\add_simple.php 28
ERROR - 2020-07-13 23:57:54 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 23:57:54 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 23:57:54 --> Severity: Notice --> Undefined index: question C:\xampp\htdocs\application\views\admin\add_simple.php 28
ERROR - 2020-07-13 23:58:54 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-13 23:58:54 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-13 23:58:54 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\add_simple.php 28
ERROR - 2020-07-13 23:58:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_simple.php 28
ERROR - 2020-07-13 19:07:57 --> Severity: Compile Error --> Cannot use [] for reading C:\xampp\htdocs\application\views\admin\add_simple.php 23
ERROR - 2020-07-13 19:08:05 --> Severity: Compile Error --> Cannot use [] for reading C:\xampp\htdocs\application\views\admin\add_simple.php 23
ERROR - 2020-07-13 19:09:11 --> Severity: Compile Error --> Cannot use [] for reading C:\xampp\htdocs\application\views\admin\add_simple.php 23
ERROR - 2020-07-13 19:18:05 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) C:\xampp\htdocs\application\views\admin\add_simple.php 34
ERROR - 2020-07-13 19:18:36 --> Severity: error --> Exception: syntax error, unexpected 'if' (T_IF) C:\xampp\htdocs\application\views\admin\add_simple.php 34
ERROR - 2020-07-13 19:35:10 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\simple_answer.php 52
ERROR - 2020-07-13 19:35:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 19:35:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 19:36:37 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\simple_answer.php 52
ERROR - 2020-07-13 19:36:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 19:36:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 19:36:45 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\multiple_answer.php 52
ERROR - 2020-07-13 19:36:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-13 19:36:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-13 19:36:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-13 19:36:52 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\multiple_answer.php 52
ERROR - 2020-07-13 19:36:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-13 19:36:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-13 19:36:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-13 19:42:18 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\money.php 52
ERROR - 2020-07-13 19:42:21 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\simple_answer.php 52
ERROR - 2020-07-13 19:42:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 19:42:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 22:59:27 --> Severity: Notice --> Undefined variable: category_id C:\xampp\htdocs\application\views\admin\add_choice.php 12
ERROR - 2020-07-13 23:00:00 --> Severity: Notice --> Undefined variable: category_id C:\xampp\htdocs\application\views\admin\add_choice.php 12
ERROR - 2020-07-13 23:00:08 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\simple_answer.php 52
ERROR - 2020-07-13 23:00:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 23:00:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 23:01:35 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\simple_answer.php 52
ERROR - 2020-07-13 23:01:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-13 23:01:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
