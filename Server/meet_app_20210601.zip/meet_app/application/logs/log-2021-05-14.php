<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-14 03:22:36 --> 404 Page Not Found: Git/config
ERROR - 2021-05-14 03:22:36 --> 404 Page Not Found: Env/index
ERROR - 2021-05-14 03:22:37 --> 404 Page Not Found: Sftp_configjson/index
ERROR - 2021-05-14 03:22:37 --> 404 Page Not Found: Ftpconfig/index
ERROR - 2021-05-14 03:22:38 --> 404 Page Not Found: Remote_syncjson/index
ERROR - 2021-05-14 03:22:38 --> 404 Page Not Found: Vscode/ftp_sync.json
ERROR - 2021-05-14 03:22:39 --> 404 Page Not Found: Vscode/sftp.json
ERROR - 2021-05-14 03:22:39 --> 404 Page Not Found: Deployment_configjson/index
ERROR - 2021-05-14 03:22:40 --> 404 Page Not Found: Ftpsyncsettings/index
ERROR - 2021-05-14 03:22:40 --> 404 Page Not Found: Wp_includes/wlwmanifest.xml
ERROR - 2021-05-14 06:31:21 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-05-14 06:31:22 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-05-14 07:58:35 --> 404 Page Not Found: Admin/fileupload
ERROR - 2021-05-14 09:03:53 --> 404 Page Not Found: Robotstxt/index
