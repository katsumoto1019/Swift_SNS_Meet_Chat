<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-16 06:53:16 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-10-16 06:53:17 --> 404 Page Not Found: 404javascriptjs/index
