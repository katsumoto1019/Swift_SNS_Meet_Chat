<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-22 02:35:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-10-22 06:50:57 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-10-22 06:50:58 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-10-22 14:11:36 --> 404 Page Not Found: Wp_loginphp/index
