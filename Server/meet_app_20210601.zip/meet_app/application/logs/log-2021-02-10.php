<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-10 07:48:59 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-02-10 07:49:00 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-02-10 17:30:36 --> 404 Page Not Found: Contact/index
