<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-26 04:16:59 --> Query error: Table 'foodtrack.tb_purchase' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows` FROM `tb_purchase`
ERROR - 2019-12-26 04:17:45 --> Query error: Table 'foodtrack.tb_purchase' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows` FROM `tb_purchase`
ERROR - 2019-12-26 04:18:33 --> Query error: Table 'foodtrack.tb_purchase' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows` FROM `tb_purchase`
ERROR - 2019-12-26 04:22:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\application\controllers\Admin.php 122
ERROR - 2019-12-26 05:23:05 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 04:23:10 --> Query error: Table 'foodtrack.tb_minprice' doesn't exist - Invalid query: SELECT *
FROM `tb_minprice`
ORDER BY `id` DESC
ERROR - 2019-12-26 05:23:15 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 04:24:08 --> Query error: Table 'foodtrack.tb_minprice' doesn't exist - Invalid query: SELECT *
FROM `tb_minprice`
ORDER BY `id` DESC
ERROR - 2019-12-26 05:24:13 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 05:25:12 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 04:25:19 --> Query error: Table 'foodtrack.tb_minprice' doesn't exist - Invalid query: SELECT *
FROM `tb_minprice`
ORDER BY `id` DESC
ERROR - 2019-12-26 05:25:24 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 05:27:20 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 04:27:37 --> Query error: Table 'foodtrack.tb_minprice' doesn't exist - Invalid query: SELECT *
FROM `tb_minprice`
ORDER BY `id` DESC
ERROR - 2019-12-26 04:27:41 --> Severity: Notice --> Undefined variable: fetch C:\xampp\htdocs\application\views\admin\categories.php 72
ERROR - 2019-12-26 04:27:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\categories.php 72
ERROR - 2019-12-26 05:27:42 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 04:28:32 --> Severity: Notice --> Undefined variable: fetch C:\xampp\htdocs\application\views\admin\categories.php 46
ERROR - 2019-12-26 04:28:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\categories.php 46
ERROR - 2019-12-26 05:28:33 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 04:30:15 --> Severity: Notice --> Undefined variable: fetch C:\xampp\htdocs\application\views\admin\categories.php 46
ERROR - 2019-12-26 04:30:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\categories.php 46
ERROR - 2019-12-26 05:30:16 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 04:32:25 --> Severity: Notice --> Undefined variable: fetch C:\xampp\htdocs\application\views\admin\categories.php 35
ERROR - 2019-12-26 04:32:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\categories.php 35
ERROR - 2019-12-26 05:32:25 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 04:32:36 --> Severity: Notice --> Undefined variable: fetch C:\xampp\htdocs\application\views\admin\categories.php 35
ERROR - 2019-12-26 04:32:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\categories.php 35
ERROR - 2019-12-26 05:32:36 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 04:32:39 --> Severity: Notice --> Undefined variable: fetch C:\xampp\htdocs\application\views\admin\categories.php 35
ERROR - 2019-12-26 04:32:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\categories.php 35
ERROR - 2019-12-26 05:32:39 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 04:34:21 --> Severity: Notice --> Undefined variable: fetch C:\xampp\htdocs\application\views\admin\categories.php 35
ERROR - 2019-12-26 04:34:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\categories.php 35
ERROR - 2019-12-26 05:34:21 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 04:35:36 --> Query error: Table 'foodtrack.tb_minprice' doesn't exist - Invalid query: SELECT *
FROM `tb_minprice`
ORDER BY `id` DESC
ERROR - 2019-12-26 04:35:37 --> Severity: Notice --> Undefined variable: fetch C:\xampp\htdocs\application\views\admin\categories.php 35
ERROR - 2019-12-26 04:35:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\categories.php 35
ERROR - 2019-12-26 05:35:38 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 04:35:50 --> Severity: Notice --> Undefined variable: fetch C:\xampp\htdocs\application\views\admin\categories.php 35
ERROR - 2019-12-26 04:35:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\categories.php 35
ERROR - 2019-12-26 05:35:51 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 04:35:52 --> Severity: Notice --> Undefined variable: fetch C:\xampp\htdocs\application\views\admin\categories.php 35
ERROR - 2019-12-26 04:35:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\categories.php 35
ERROR - 2019-12-26 05:35:52 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 04:35:53 --> Severity: Notice --> Undefined variable: fetch C:\xampp\htdocs\application\views\admin\categories.php 35
ERROR - 2019-12-26 04:35:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\categories.php 35
ERROR - 2019-12-26 05:35:53 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 04:35:56 --> Severity: Notice --> Undefined variable: fetch C:\xampp\htdocs\application\views\admin\categories.php 35
ERROR - 2019-12-26 04:35:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\categories.php 35
ERROR - 2019-12-26 05:35:56 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 08:39:02 --> Severity: Notice --> Undefined variable: fetch C:\xampp\htdocs\application\views\admin\categories.php 35
ERROR - 2019-12-26 08:39:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\categories.php 35
ERROR - 2019-12-26 09:39:02 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 13:37:31 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:37:31 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:37:31 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:37:31 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:37:31 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:37:31 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:37:32 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:37:32 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:37:32 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:03 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:03 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:03 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:03 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:03 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:04 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:04 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:04 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:04 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:05 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:05 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:05 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:05 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:05 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:05 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:05 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:05 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:05 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:11 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:11 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:11 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:11 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:11 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:11 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:11 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:11 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:11 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:30 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:30 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:30 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:30 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:30 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:30 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:30 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:30 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:30 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:31 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:31 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:31 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:31 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:31 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:31 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:33 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:33 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:33 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:33 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:33 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:33 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:34 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:34 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:34 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:37 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:37 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:37 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:37 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:37 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:37 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:37 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:45 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:45 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:45 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:45 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:45 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:45 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:45 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:45 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:38:45 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:47:26 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:47:26 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:47:26 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:47:26 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:47:26 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:47:26 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:47:26 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:47:26 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:48:48 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:48:48 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:48:48 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:48:48 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:48:48 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:48:48 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:48:48 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:48:48 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:48:48 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:48:49 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:48:49 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:48:49 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:48:49 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:48:49 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:48:49 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:48:49 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:48:49 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:48:49 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:48:52 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:48:52 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:48:52 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:48:52 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:48:52 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:48:52 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:48:52 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:48:52 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:48:52 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:48:55 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:48:55 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:48:55 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:48:55 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:48:55 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:48:55 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:48:55 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:48:55 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:48:56 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:48:58 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:48:58 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:48:58 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:48:58 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:48:58 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:48:58 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:48:58 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:48:58 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:49:03 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:49:03 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:49:03 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:49:03 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:49:03 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:49:03 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:49:03 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:49:03 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:49:03 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:49:05 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:49:05 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:49:05 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:49:05 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:49:05 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:49:05 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:49:05 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:49:06 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:49:06 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:49:14 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:49:14 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:49:14 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:49:14 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:49:14 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:49:14 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:49:14 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:49:14 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:49:15 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:49:22 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:49:22 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:49:22 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:49:22 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:49:22 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:49:22 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:49:22 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:49:22 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:49:22 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:49:32 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:49:32 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:49:32 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:49:32 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:49:32 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:49:32 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:49:32 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:49:32 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:49:32 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 13:29:10 --> Severity: Notice --> Undefined variable: fetch C:\xampp\htdocs\application\views\admin\categories.php 32
ERROR - 2019-12-26 13:29:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\categories.php 32
ERROR - 2019-12-26 14:29:12 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 13:31:30 --> Severity: Notice --> Undefined variable: fetch C:\xampp\htdocs\application\views\admin\categories.php 32
ERROR - 2019-12-26 13:31:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\categories.php 32
ERROR - 2019-12-26 14:31:31 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 13:32:01 --> Severity: Notice --> Undefined variable: fetch C:\xampp\htdocs\application\views\admin\categories.php 32
ERROR - 2019-12-26 13:32:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\categories.php 32
ERROR - 2019-12-26 14:32:02 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 13:37:12 --> Severity: Notice --> Undefined variable: fetch C:\xampp\htdocs\application\views\admin\categories.php 31
ERROR - 2019-12-26 13:37:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\categories.php 31
ERROR - 2019-12-26 14:37:13 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 13:42:04 --> Severity: Notice --> Undefined variable: fetch C:\xampp\htdocs\application\views\admin\categories.php 31
ERROR - 2019-12-26 13:42:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\categories.php 31
ERROR - 2019-12-26 14:42:06 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 13:42:42 --> Severity: Notice --> Undefined variable: fetch C:\xampp\htdocs\application\views\admin\categories.php 31
ERROR - 2019-12-26 13:42:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\categories.php 31
ERROR - 2019-12-26 14:42:42 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 13:42:45 --> Severity: Notice --> Undefined variable: fetch C:\xampp\htdocs\application\views\admin\categories.php 31
ERROR - 2019-12-26 13:42:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\categories.php 31
ERROR - 2019-12-26 14:42:45 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 13:45:45 --> Severity: Notice --> Undefined variable: Categories C:\xampp\htdocs\application\views\admin\categories.php 31
ERROR - 2019-12-26 13:45:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\categories.php 31
ERROR - 2019-12-26 13:47:00 --> Severity: Notice --> Undefined variable: Categories C:\xampp\htdocs\application\views\admin\categories.php 31
ERROR - 2019-12-26 13:47:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\categories.php 31
ERROR - 2019-12-26 14:47:43 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 13:47:50 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\application\views\admin\categories.php 31
ERROR - 2019-12-26 13:47:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\categories.php 31
ERROR - 2019-12-26 14:48:32 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 13:49:08 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\application\views\admin\categories.php 31
ERROR - 2019-12-26 13:49:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\categories.php 31
ERROR - 2019-12-26 14:49:50 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 13:52:39 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\application\views\admin\categories.php 31
ERROR - 2019-12-26 13:52:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\categories.php 31
ERROR - 2019-12-26 14:53:22 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 13:55:35 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\application\views\admin\categories.php 31
ERROR - 2019-12-26 13:55:35 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\application\views\admin\categories.php 32
ERROR - 2019-12-26 13:55:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\categories.php 32
ERROR - 2019-12-26 13:55:39 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\application\views\admin\categories.php 31
ERROR - 2019-12-26 13:55:39 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\application\views\admin\categories.php 32
ERROR - 2019-12-26 13:55:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\categories.php 32
ERROR - 2019-12-26 14:56:17 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 13:59:48 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\application\views\admin\categories.php 31
ERROR - 2019-12-26 13:59:48 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\application\views\admin\categories.php 32
ERROR - 2019-12-26 13:59:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\categories.php 32
ERROR - 2019-12-26 15:00:10 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 14:01:46 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\application\views\admin\categories.php 31
ERROR - 2019-12-26 14:01:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\categories.php 31
ERROR - 2019-12-26 15:01:48 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 14:01:50 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\application\views\admin\categories.php 31
ERROR - 2019-12-26 14:01:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\categories.php 31
ERROR - 2019-12-26 15:01:50 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 15:04:14 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 15:04:14 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 15:04:14 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 15:04:14 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 15:04:14 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 15:04:14 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 15:04:14 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 15:04:14 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 15:04:14 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 15:04:14 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 15:04:14 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 15:04:14 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 15:04:15 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 15:04:15 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 15:04:15 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 15:04:15 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 14:10:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\categories.php 31
ERROR - 2019-12-26 15:10:28 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 14:10:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\categories.php 31
ERROR - 2019-12-26 15:10:42 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 14:14:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\categories.php 31
ERROR - 2019-12-26 15:14:33 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 14:16:27 --> Severity: error --> Exception: syntax error, unexpected '@' C:\xampp\htdocs\application\views\admin\categories.php 31
ERROR - 2019-12-26 15:16:28 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 14:16:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\categories.php 31
ERROR - 2019-12-26 15:16:50 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 14:17:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\categories.php 31
ERROR - 2019-12-26 15:17:16 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 14:17:57 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\application\views\admin\categories.php 39
ERROR - 2019-12-26 15:17:58 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 14:18:37 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\application\views\admin\categories.php 31
ERROR - 2019-12-26 14:18:37 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\application\views\admin\categories.php 34
ERROR - 2019-12-26 14:18:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\categories.php 34
ERROR - 2019-12-26 14:18:37 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\application\views\admin\categories.php 35
ERROR - 2019-12-26 14:18:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\categories.php 35
ERROR - 2019-12-26 14:18:37 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\application\views\admin\categories.php 36
ERROR - 2019-12-26 14:18:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\categories.php 36
ERROR - 2019-12-26 14:18:37 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\application\views\admin\categories.php 36
ERROR - 2019-12-26 14:18:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\categories.php 36
ERROR - 2019-12-26 14:18:37 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\application\views\admin\categories.php 37
ERROR - 2019-12-26 14:18:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\categories.php 37
ERROR - 2019-12-26 15:18:38 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 16:32:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\categories.php 31
ERROR - 2019-12-26 17:32:26 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 18:25:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\categories.php 31
ERROR - 2019-12-26 19:25:04 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 18:25:22 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\application\views\admin\categories.php 31
ERROR - 2019-12-26 18:25:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\categories.php 31
ERROR - 2019-12-26 19:25:23 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 18:26:18 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\application\views\admin\categories.php 31
ERROR - 2019-12-26 18:26:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\categories.php 31
ERROR - 2019-12-26 19:26:18 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 18:26:58 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\application\views\admin\categories.php 31
ERROR - 2019-12-26 18:26:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\categories.php 31
ERROR - 2019-12-26 19:26:59 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 20:38:27 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 19:38:36 --> Severity: error --> Exception: Call to undefined method Admin_model::get_salebalance_byuser() C:\xampp\htdocs\application\controllers\Admin.php 726
ERROR - 2019-12-26 20:38:41 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 20:47:25 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 20:47:25 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 20:47:25 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 20:47:25 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 20:47:25 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 20:47:25 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 20:47:25 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 20:47:25 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 20:47:32 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 20:47:32 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 20:47:32 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 20:47:32 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 20:47:32 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 20:47:32 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 20:47:32 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 20:47:32 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 20:47:33 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 20:47:33 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 20:47:33 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 20:47:33 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 20:47:33 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 20:47:33 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 20:47:33 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 20:47:33 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 20:47:33 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 20:48:55 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 20:48:55 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 20:48:55 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 20:48:55 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 20:48:55 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 20:48:55 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 20:48:55 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 20:48:55 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 20:48:55 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 20:49:00 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 20:49:00 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 20:49:00 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 20:49:00 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 20:49:00 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 20:49:00 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 20:49:00 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 20:49:00 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 20:49:00 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 20:51:59 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 20:52:06 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 20:52:08 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 20:52:18 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 20:52:41 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 20:54:15 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 20:54:19 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 20:54:20 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 20:54:21 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 20:54:21 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 20:54:21 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 20:54:22 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 20:54:22 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 20:54:23 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 20:55:19 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 20:55:36 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 20:55:44 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 20:55:45 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 20:55:50 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 20:56:17 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 20:56:25 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 20:57:42 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 20:59:14 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 20:59:25 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:09:56 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:10:14 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:10:18 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:11:05 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:12:01 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:12:17 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 21:12:17 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 21:12:17 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 21:12:17 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 21:12:17 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 21:12:17 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 21:12:17 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 21:12:17 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 21:12:17 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 21:12:26 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 21:12:26 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 21:12:26 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 21:12:26 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 21:12:26 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 21:12:26 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 21:12:26 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 21:12:26 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 21:12:26 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 21:13:33 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:15:16 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:15:55 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:16:15 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:16:47 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:17:54 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:18:12 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:18:17 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 21:18:17 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 21:18:17 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 21:20:28 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:20:56 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:21:00 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:22:09 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:22:13 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:22:41 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:23:12 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:23:19 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:24:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:25:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:25:25 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:25:35 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:25:48 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:26:21 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:26:47 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:27:35 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:28:26 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:28:48 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 21:28:48 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 21:28:48 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 21:28:48 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 21:28:48 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 21:28:49 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 21:28:49 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 21:28:49 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 21:28:49 --> 404 Page Not Found: SARA2/static
ERROR - 2019-12-26 20:30:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\dashboard.php 58
ERROR - 2019-12-26 21:30:55 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:31:55 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:33:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:33:21 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:33:39 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:34:01 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:34:43 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:35:10 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:38:28 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:38:42 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:38:58 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:39:40 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:40:35 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:41:03 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:41:14 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:41:16 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:41:39 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:41:51 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:42:48 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:43:10 --> 404 Page Not Found: Manifestjson/index
ERROR - 2019-12-26 21:43:33 --> 404 Page Not Found: Manifestjson/index
