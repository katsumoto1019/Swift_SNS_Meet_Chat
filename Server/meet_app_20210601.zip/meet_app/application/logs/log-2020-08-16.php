<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-16 16:25:53 --> 404 Page Not Found: Admin/index.php
