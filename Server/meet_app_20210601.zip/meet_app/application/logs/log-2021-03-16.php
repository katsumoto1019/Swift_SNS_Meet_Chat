<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-16 05:49:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-03-16 06:45:16 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-03-16 06:45:17 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-03-16 10:39:50 --> 404 Page Not Found: Docindexphp/index
ERROR - 2021-03-16 10:39:55 --> 404 Page Not Found: Docindexphp/index
ERROR - 2021-03-16 17:32:36 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-03-16 17:32:36 --> 404 Page Not Found: Wp_loginphp/index
