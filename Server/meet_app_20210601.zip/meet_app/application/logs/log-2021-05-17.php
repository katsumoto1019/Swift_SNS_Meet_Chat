<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-17 03:56:26 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-05-17 03:56:29 --> 404 Page Not Found: Wordpress/wp_login.php
ERROR - 2021-05-17 03:56:31 --> 404 Page Not Found: Blog/wp_login.php
ERROR - 2021-05-17 03:56:33 --> 404 Page Not Found: Wp/wp_login.php
ERROR - 2021-05-17 06:29:22 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-05-17 06:29:23 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-05-17 08:01:36 --> 404 Page Not Found: Robotstxt/index
