<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-08 06:37:43 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-04-08 06:37:44 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-04-08 07:22:09 --> 404 Page Not Found: Public/assets
ERROR - 2021-04-08 07:22:09 --> 404 Page Not Found: Public/assets
ERROR - 2021-04-08 09:26:26 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-04-08 15:10:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-04-08 17:49:39 --> 404 Page Not Found: Plugins/plupload
ERROR - 2021-04-08 19:24:53 --> 404 Page Not Found: Wp_includes/wlwmanifest.xml
ERROR - 2021-04-08 19:24:53 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2021-04-08 19:24:54 --> 404 Page Not Found: Blog/wp_includes
ERROR - 2021-04-08 19:24:54 --> 404 Page Not Found: Web/wp_includes
ERROR - 2021-04-08 19:24:54 --> 404 Page Not Found: Wordpress/wp_includes
ERROR - 2021-04-08 19:24:54 --> 404 Page Not Found: Website/wp_includes
ERROR - 2021-04-08 19:24:55 --> 404 Page Not Found: Wp/wp_includes
ERROR - 2021-04-08 19:24:55 --> 404 Page Not Found: News/wp_includes
ERROR - 2021-04-08 19:24:55 --> 404 Page Not Found: 2018/wp_includes
ERROR - 2021-04-08 19:24:55 --> 404 Page Not Found: 2019/wp_includes
ERROR - 2021-04-08 19:24:55 --> 404 Page Not Found: Shop/wp_includes
ERROR - 2021-04-08 19:24:56 --> 404 Page Not Found: Wp1/wp_includes
ERROR - 2021-04-08 19:24:56 --> 404 Page Not Found: Test/wp_includes
ERROR - 2021-04-08 19:24:56 --> 404 Page Not Found: Media/wp_includes
ERROR - 2021-04-08 19:24:56 --> 404 Page Not Found: Wp2/wp_includes
ERROR - 2021-04-08 19:24:57 --> 404 Page Not Found: Site/wp_includes
ERROR - 2021-04-08 19:24:57 --> 404 Page Not Found: Cms/wp_includes
ERROR - 2021-04-08 19:24:57 --> 404 Page Not Found: Sito/wp_includes
ERROR - 2021-04-08 19:34:34 --> 404 Page Not Found: Robotstxt/index
