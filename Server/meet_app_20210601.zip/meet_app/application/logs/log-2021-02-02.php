<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-02 07:52:09 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-02-02 07:52:10 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-02-02 15:14:57 --> 404 Page Not Found: Wp_admin/setup_config.php
ERROR - 2021-02-02 15:14:58 --> 404 Page Not Found: Wp_admin/install.php
ERROR - 2021-02-02 17:58:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-02-02 20:10:27 --> 404 Page Not Found: Wp_loginphp/index
