<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-27 13:49:29 --> 404 Page Not Found: Foodtrack/admin
ERROR - 2020-02-27 13:50:04 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-27 20:38:50 --> 404 Page Not Found: GetMyStudents/index
ERROR - 2020-02-27 20:39:31 --> 404 Page Not Found: GetMyStudent/index
ERROR - 2020-02-27 20:40:42 --> 404 Page Not Found: Api/getMyStudents
ERROR - 2020-02-27 20:41:04 --> 404 Page Not Found: Api/emailExist
ERROR - 2020-02-27 20:41:23 --> 404 Page Not Found: GetMyStudent/index
ERROR - 2020-02-27 20:41:34 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-27 20:41:59 --> 404 Page Not Found: GetMyStudents/index
ERROR - 2020-02-27 20:43:08 --> 404 Page Not Found: Api/getContents
ERROR - 2020-02-27 20:43:15 --> 404 Page Not Found: Api/getMyContents
ERROR - 2020-02-27 20:44:19 --> 404 Page Not Found: Api/getContents
ERROR - 2020-02-27 20:45:56 --> 404 Page Not Found: GetMyStudents/index
ERROR - 2020-02-27 20:46:03 --> 404 Page Not Found: GetMyStudents/index
ERROR - 2020-02-27 20:46:25 --> 404 Page Not Found: GetMyStudents/index
