<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-12 06:07:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2021-04-12 06:44:06 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-04-12 06:44:07 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-04-12 06:46:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-04-12 08:56:24 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-04-12 18:16:22 --> 404 Page Not Found: Admin/assets
