<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-22 07:47:30 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-11-22 07:47:30 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-11-22 20:00:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-22 20:07:16 --> 404 Page Not Found: Robotstxt/index
