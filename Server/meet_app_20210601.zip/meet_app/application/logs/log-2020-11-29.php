<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-29 07:42:34 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-11-29 07:42:35 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-11-29 17:20:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-29 20:57:19 --> 404 Page Not Found: Wp_loginphp/index
