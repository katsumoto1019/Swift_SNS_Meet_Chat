<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-25 12:55:19 --> 404 Page Not Found: Api/getSeller
