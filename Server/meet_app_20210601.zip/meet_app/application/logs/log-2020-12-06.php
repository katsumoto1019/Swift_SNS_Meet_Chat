<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-06 00:19:46 --> 404 Page Not Found: Wordpress/index
ERROR - 2020-12-06 00:19:47 --> 404 Page Not Found: Wp/index
ERROR - 2020-12-06 00:19:48 --> 404 Page Not Found: Blog/index
ERROR - 2020-12-06 00:19:49 --> 404 Page Not Found: Old/index
ERROR - 2020-12-06 00:19:50 --> 404 Page Not Found: New/index
ERROR - 2020-12-06 00:19:51 --> 404 Page Not Found: Test/index
ERROR - 2020-12-06 00:19:51 --> 404 Page Not Found: Backup/index
ERROR - 2020-12-06 00:19:52 --> 404 Page Not Found: Temp/index
ERROR - 2020-12-06 07:52:14 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-12-06 07:52:14 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-12-06 13:57:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-06 15:51:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-06 15:51:18 --> 404 Page Not Found: Humanstxt/index
ERROR - 2020-12-06 15:51:19 --> 404 Page Not Found: Adstxt/index
ERROR - 2020-12-06 20:05:25 --> 404 Page Not Found: Blog/index
ERROR - 2020-12-06 21:50:58 --> 404 Page Not Found: Env/index
