<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-18 05:13:32 --> 404 Page Not Found: Assets/admin
ERROR - 2020-09-18 05:13:53 --> 404 Page Not Found: Assets/admin
ERROR - 2020-09-18 14:25:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-09-18 14:25:33 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2020-09-18 14:25:52 --> 404 Page Not Found: Adstxt/index
ERROR - 2020-09-18 19:07:05 --> 404 Page Not Found: Robotstxt/index
