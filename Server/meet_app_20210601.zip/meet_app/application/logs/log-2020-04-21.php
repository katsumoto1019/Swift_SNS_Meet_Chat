<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-21 05:27:38 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-04-21 05:27:47 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-04-21 05:28:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-04-21 05:28:19 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-04-21 05:28:36 --> 404 Page Not Found: Manifestjson/index
