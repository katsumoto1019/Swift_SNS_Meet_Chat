<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-09 06:52:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-01-09 07:40:20 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-01-09 07:40:22 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-01-09 11:22:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-01-09 17:03:54 --> 404 Page Not Found: Env/index
