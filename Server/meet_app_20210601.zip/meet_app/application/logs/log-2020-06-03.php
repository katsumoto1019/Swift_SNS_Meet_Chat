<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-03 00:54:17 --> 404 Page Not Found: Wp_content/uploads
ERROR - 2020-06-03 01:52:21 --> 404 Page Not Found: Cache/s_eval.php
ERROR - 2020-06-03 03:18:00 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-06-03 05:31:48 --> 404 Page Not Found: Cache/seo_script.php
ERROR - 2020-06-03 05:52:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-03 05:52:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-03 07:13:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-03 07:13:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-03 07:13:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-03 07:13:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-03 07:13:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-03 07:19:27 --> 404 Page Not Found: Wp_content/uploads
ERROR - 2020-06-03 09:21:25 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-06-03 10:16:56 --> 404 Page Not Found: Hook_filtersphp/index
ERROR - 2020-06-03 11:13:05 --> 404 Page Not Found: Admin/index
ERROR - 2020-06-03 11:47:31 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-03 12:47:17 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-06-03 13:30:46 --> 404 Page Not Found: Cache/accesson.php
ERROR - 2020-06-03 13:44:08 --> Severity: error --> Exception: syntax error, unexpected 'parent' (T_STRING) /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 24
ERROR - 2020-06-03 13:44:59 --> Severity: error --> Exception: syntax error, unexpected 'parent' (T_STRING) /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 24
ERROR - 2020-06-03 13:45:15 --> Severity: error --> Exception: syntax error, unexpected 'parent' (T_STRING) /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 24
ERROR - 2020-06-03 14:12:47 --> 404 Page Not Found: Templates/protostar
ERROR - 2020-06-03 15:27:09 --> 404 Page Not Found: Wp_content/themes
ERROR - 2020-06-03 15:31:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-03 15:31:52 --> 404 Page Not Found: Privacy_policy_learnme/index
ERROR - 2020-06-03 17:02:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-03 17:02:31 --> 404 Page Not Found: Wp_json/index
ERROR - 2020-06-03 18:21:34 --> 404 Page Not Found: Feed/index
ERROR - 2020-06-03 21:01:29 --> 404 Page Not Found: Env/index
ERROR - 2020-06-03 21:01:30 --> 404 Page Not Found: Api/.env
ERROR - 2020-06-03 21:01:31 --> 404 Page Not Found: Laravel/.env
ERROR - 2020-06-03 21:01:32 --> 404 Page Not Found: Test/.env
ERROR - 2020-06-03 21:01:33 --> 404 Page Not Found: Admin/.env
ERROR - 2020-06-03 21:01:34 --> 404 Page Not Found: Vendor/.env
ERROR - 2020-06-03 21:01:35 --> 404 Page Not Found: Sites/.env
ERROR - 2020-06-03 21:01:36 --> 404 Page Not Found: Blog/.env
ERROR - 2020-06-03 21:01:37 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-06-03 21:01:38 --> 404 Page Not Found: Public/.env
ERROR - 2020-06-03 21:01:39 --> 404 Page Not Found: Shop/.env
ERROR - 2020-06-03 21:09:30 --> 404 Page Not Found: Assets/images
