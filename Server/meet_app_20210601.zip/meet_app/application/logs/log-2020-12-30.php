<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-30 07:51:10 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-12-30 07:51:11 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-12-30 08:51:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-30 09:55:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-30 21:56:33 --> 404 Page Not Found: Robotstxt/index
