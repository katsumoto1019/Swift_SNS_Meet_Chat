<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-09 03:23:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-02-09 07:42:29 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-02-09 07:42:30 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-02-09 08:55:07 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-02-09 08:55:08 --> 404 Page Not Found: Wordpress/wp_login.php
ERROR - 2021-02-09 08:55:10 --> 404 Page Not Found: Blog/wp_login.php
ERROR - 2021-02-09 08:55:11 --> 404 Page Not Found: Wp/wp_login.php
ERROR - 2021-02-09 18:02:02 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-02-09 18:02:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-02-09 19:54:32 --> 404 Page Not Found: Wp_includes/css
ERROR - 2021-02-09 19:55:12 --> 404 Page Not Found: Wp_includes/fonts
ERROR - 2021-02-09 22:45:47 --> 404 Page Not Found: Js/mage
