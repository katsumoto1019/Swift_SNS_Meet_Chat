<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-30 01:15:12 --> 404 Page Not Found: Api/submitFCM
ERROR - 2020-05-30 01:15:21 --> 404 Page Not Found: Api/mkContact
ERROR - 2020-05-30 01:16:08 --> 404 Page Not Found: Api/submitFCM
ERROR - 2020-05-30 01:16:23 --> 404 Page Not Found: Api/submitFCM
ERROR - 2020-05-30 01:16:32 --> 404 Page Not Found: Api/submitFCM
ERROR - 2020-05-30 01:16:42 --> 404 Page Not Found: Api/submitFCM
ERROR - 2020-05-30 01:16:48 --> 404 Page Not Found: Api/mkContact
ERROR - 2020-05-30 01:23:40 --> 404 Page Not Found: Api/submitFCM
ERROR - 2020-05-30 01:23:41 --> 404 Page Not Found: Api/mkContact
ERROR - 2020-05-30 01:24:33 --> 404 Page Not Found: Api/mkContact
ERROR - 2020-05-30 01:25:39 --> 404 Page Not Found: Api/mkContact
ERROR - 2020-05-30 01:29:39 --> 404 Page Not Found: Api/submitFCM
ERROR - 2020-05-30 01:29:50 --> 404 Page Not Found: Api/submitFCM
ERROR - 2020-05-30 01:40:57 --> 404 Page Not Found: Api/mkContact
ERROR - 2020-05-30 01:41:42 --> 404 Page Not Found: Api/mkContact
ERROR - 2020-05-30 01:42:47 --> 404 Page Not Found: Api/submitFCM
ERROR - 2020-05-30 01:42:51 --> 404 Page Not Found: Api/mkContact
ERROR - 2020-05-30 01:47:54 --> 404 Page Not Found: Api/submitFCM
ERROR - 2020-05-30 01:47:59 --> 404 Page Not Found: Api/mkContact
ERROR - 2020-05-30 01:48:11 --> 404 Page Not Found: Api/submitFCM
ERROR - 2020-05-30 01:48:12 --> 404 Page Not Found: Api/mkContact
ERROR - 2020-05-30 01:48:48 --> 404 Page Not Found: Api/submitFCM
ERROR - 2020-05-30 01:48:49 --> 404 Page Not Found: Api/mkContact
ERROR - 2020-05-30 01:49:08 --> 404 Page Not Found: Api/submitFCM
ERROR - 2020-05-30 01:49:10 --> 404 Page Not Found: Api/mkContact
ERROR - 2020-05-30 01:51:15 --> 404 Page Not Found: Api/submitFCM
ERROR - 2020-05-30 01:51:16 --> 404 Page Not Found: Api/mkContact
ERROR - 2020-05-30 01:55:36 --> 404 Page Not Found: Api/submitFCM
ERROR - 2020-05-30 03:41:19 --> 404 Page Not Found: Api/mkContact
ERROR - 2020-05-30 03:43:10 --> 404 Page Not Found: Api/submitFCM
ERROR - 2020-05-30 03:49:52 --> 404 Page Not Found: Api/mkContact
ERROR - 2020-05-30 03:51:25 --> 404 Page Not Found: Api/submitFCM
ERROR - 2020-05-30 03:51:32 --> 404 Page Not Found: Api/submitFCM
ERROR - 2020-05-30 03:59:56 --> 404 Page Not Found: Api/submitFCM
ERROR - 2020-05-30 04:00:46 --> 404 Page Not Found: Api/mkContact
ERROR - 2020-05-30 04:20:07 --> 404 Page Not Found: Api/submitFCM
ERROR - 2020-05-30 04:20:11 --> 404 Page Not Found: Api/mkContact
ERROR - 2020-05-30 04:33:57 --> Severity: Compile Error --> Cannot redeclare Api::getOnlineState() C:\xampp\htdocs\application\controllers\Api.php 661
ERROR - 2020-05-30 04:33:57 --> Severity: Compile Error --> Cannot redeclare Api::getOnlineState() C:\xampp\htdocs\application\controllers\Api.php 661
ERROR - 2020-05-30 04:33:57 --> Severity: Compile Error --> Cannot redeclare Api::getOnlineState() C:\xampp\htdocs\application\controllers\Api.php 661
ERROR - 2020-05-30 04:34:32 --> Severity: Compile Error --> Cannot redeclare Api::getOnlineState() C:\xampp\htdocs\application\controllers\Api.php 661
ERROR - 2020-05-30 04:34:32 --> Severity: Compile Error --> Cannot redeclare Api::getOnlineState() C:\xampp\htdocs\application\controllers\Api.php 661
ERROR - 2020-05-30 04:35:37 --> Severity: Compile Error --> Cannot redeclare Api::getOnlineState() C:\xampp\htdocs\application\controllers\Api.php 661
ERROR - 2020-05-30 04:35:37 --> Severity: Compile Error --> Cannot redeclare Api::getOnlineState() C:\xampp\htdocs\application\controllers\Api.php 661
ERROR - 2020-05-30 04:35:43 --> Severity: Compile Error --> Cannot redeclare Api::getOnlineState() C:\xampp\htdocs\application\controllers\Api.php 661
ERROR - 2020-05-30 04:35:45 --> Severity: Compile Error --> Cannot redeclare Api::getOnlineState() C:\xampp\htdocs\application\controllers\Api.php 661
ERROR - 2020-05-30 04:35:47 --> Severity: Compile Error --> Cannot redeclare Api::getOnlineState() C:\xampp\htdocs\application\controllers\Api.php 661
ERROR - 2020-05-30 04:35:50 --> Severity: Compile Error --> Cannot redeclare Api::getOnlineState() C:\xampp\htdocs\application\controllers\Api.php 661
ERROR - 2020-05-30 05:38:50 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 05:40:36 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 05:42:11 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 05:48:53 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 05:49:25 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 05:52:12 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 05:52:15 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 06:00:15 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 06:06:12 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 06:06:20 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 06:40:39 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 06:41:19 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 06:41:39 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 06:41:52 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 06:42:34 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 06:43:02 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 06:43:25 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 06:43:56 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 06:45:07 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 06:46:04 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 06:46:39 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 06:47:38 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 06:47:58 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 06:48:11 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 06:51:01 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 06:52:00 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 06:52:07 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 06:53:22 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 06:55:02 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 06:55:27 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 06:56:49 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 06:57:06 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 06:57:25 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 06:57:41 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 06:59:02 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 06:59:05 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 07:00:00 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 07:00:39 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 07:01:04 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 07:01:21 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 07:03:32 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 07:04:26 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 07:05:05 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 07:06:45 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 07:10:00 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 07:20:29 --> 404 Page Not Found: Terms/index
ERROR - 2020-05-30 07:20:48 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 07:29:07 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 07:43:16 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 07:46:38 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 07:46:58 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 07:47:53 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 07:48:04 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 07:48:12 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 07:49:44 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 07:50:47 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-30 13:46:42 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'root'@'localhost' (using password: NO) /home/kaysmbfnu0fv/public_html/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2020-05-30 13:46:42 --> Unable to connect to the database
ERROR - 2020-05-30 13:50:05 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'root'@'localhost' (using password: NO) /home/kaysmbfnu0fv/public_html/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2020-05-30 13:50:05 --> Unable to connect to the database
ERROR - 2020-05-30 13:58:16 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'root'@'localhost' (using password: NO) /home/kaysmbfnu0fv/public_html/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2020-05-30 13:58:16 --> Unable to connect to the database
ERROR - 2020-05-30 13:59:51 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'root'@'localhost' (using password: NO) /home/kaysmbfnu0fv/public_html/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2020-05-30 13:59:51 --> Unable to connect to the database
ERROR - 2020-05-30 13:59:56 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'root'@'localhost' (using password: NO) /home/kaysmbfnu0fv/public_html/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2020-05-30 13:59:56 --> Unable to connect to the database
ERROR - 2020-05-30 14:00:37 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'root'@'localhost' (using password: YES) /home/kaysmbfnu0fv/public_html/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2020-05-30 14:00:37 --> Unable to connect to the database
ERROR - 2020-05-30 14:04:33 --> Severity: Warning --> mysqli::real_connect(): (42000/1044): Access denied for user 'kaysmbfnu0fv'@'localhost' to database 'learnme' /home/kaysmbfnu0fv/public_html/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2020-05-30 14:04:33 --> Unable to connect to the database
ERROR - 2020-05-30 14:05:37 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'kaysmbfnu0fv_root'@'localhost' (using password: YES) /home/kaysmbfnu0fv/public_html/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2020-05-30 14:05:37 --> Unable to connect to the database
ERROR - 2020-05-30 14:06:24 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'kaysmbfnu0fv_root'@'localhost' (using password: YES) /home/kaysmbfnu0fv/public_html/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2020-05-30 14:06:24 --> Unable to connect to the database
ERROR - 2020-05-30 14:06:46 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'kaysmbfnu0fv_root'@'localhost' (using password: YES) /home/kaysmbfnu0fv/public_html/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2020-05-30 14:06:46 --> Unable to connect to the database
ERROR - 2020-05-30 14:06:48 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'kaysmbfnu0fv_root'@'localhost' (using password: YES) /home/kaysmbfnu0fv/public_html/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2020-05-30 14:06:48 --> Unable to connect to the database
ERROR - 2020-05-30 14:09:17 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'kaysmbfnu0fv_root'@'localhost' (using password: YES) /home/kaysmbfnu0fv/public_html/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2020-05-30 14:09:17 --> Unable to connect to the database
ERROR - 2020-05-30 14:09:50 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'root'@'localhost' (using password: NO) /home/kaysmbfnu0fv/public_html/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2020-05-30 14:09:50 --> Unable to connect to the database
ERROR - 2020-05-30 14:09:53 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'root'@'localhost' (using password: NO) /home/kaysmbfnu0fv/public_html/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2020-05-30 14:09:53 --> Unable to connect to the database
ERROR - 2020-05-30 14:12:53 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'root'@'localhost' (using password: NO) /home/kaysmbfnu0fv/public_html/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2020-05-30 14:12:53 --> Unable to connect to the database
ERROR - 2020-05-30 14:12:55 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'root'@'localhost' (using password: NO) /home/kaysmbfnu0fv/public_html/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2020-05-30 14:12:55 --> Unable to connect to the database
ERROR - 2020-05-30 14:17:26 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'root'@'localhost' (using password: YES) /home/kaysmbfnu0fv/public_html/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2020-05-30 14:17:26 --> Unable to connect to the database
ERROR - 2020-05-30 14:26:46 --> Severity: Warning --> mysqli::real_connect(): (42000/1044): Access denied for user 'BrandonGuess'@'localhost' to database 'learnme' /home/kaysmbfnu0fv/public_html/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2020-05-30 14:26:46 --> Unable to connect to the database
ERROR - 2020-05-30 14:26:49 --> Severity: Warning --> mysqli::real_connect(): (42000/1044): Access denied for user 'BrandonGuess'@'localhost' to database 'learnme' /home/kaysmbfnu0fv/public_html/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2020-05-30 14:26:49 --> Unable to connect to the database
ERROR - 2020-05-30 14:27:32 --> Severity: Warning --> mysqli::real_connect(): (42000/1044): Access denied for user 'BrandonGuess'@'localhost' to database 'learnme' /home/kaysmbfnu0fv/public_html/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2020-05-30 14:27:32 --> Unable to connect to the database
ERROR - 2020-05-30 14:28:14 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'root'@'localhost' (using password: YES) /home/kaysmbfnu0fv/public_html/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2020-05-30 14:28:14 --> Unable to connect to the database
ERROR - 2020-05-30 14:28:32 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'root'@'localhost' (using password: YES) /home/kaysmbfnu0fv/public_html/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2020-05-30 14:28:32 --> Unable to connect to the database
ERROR - 2020-05-30 14:29:11 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'root'@'localhost' (using password: YES) /home/kaysmbfnu0fv/public_html/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2020-05-30 14:29:11 --> Unable to connect to the database
ERROR - 2020-05-30 14:29:12 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'root'@'localhost' (using password: YES) /home/kaysmbfnu0fv/public_html/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2020-05-30 14:29:12 --> Unable to connect to the database
ERROR - 2020-05-30 15:06:00 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'root'@'localhost' (using password: YES) /home/kaysmbfnu0fv/public_html/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2020-05-30 15:06:00 --> Unable to connect to the database
ERROR - 2020-05-30 17:36:30 --> Severity: Warning --> mysqli::real_connect(): (42000/1044): Access denied for user 'learnme'@'localhost' to database 'learnme' /home/kaysmbfnu0fv/public_html/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2020-05-30 17:36:30 --> Unable to connect to the database
ERROR - 2020-05-30 18:38:40 --> Severity: Notice --> Undefined variable: categories /home/kaysmbfnu0fv/public_html/application/views/admin/dashboard.php 55
ERROR - 2020-05-30 18:38:40 --> Severity: Warning --> Invalid argument supplied for foreach() /home/kaysmbfnu0fv/public_html/application/views/admin/dashboard.php 55
ERROR - 2020-05-30 17:43:37 --> 404 Page Not Found: GetSellers/index
ERROR - 2020-05-30 17:43:41 --> 404 Page Not Found: GetBooking/index
ERROR - 2020-05-30 17:43:43 --> 404 Page Not Found: GetBooking/index
ERROR - 2020-05-30 17:43:45 --> 404 Page Not Found: GetBooking/index
ERROR - 2020-05-30 17:43:47 --> 404 Page Not Found: GetSellers/index
ERROR - 2020-05-30 17:44:04 --> 404 Page Not Found: GetSellers/index
ERROR - 2020-05-30 17:44:30 --> 404 Page Not Found: GetSellers/index
ERROR - 2020-05-30 17:46:34 --> 404 Page Not Found: GetNotificationState/index
ERROR - 2020-05-30 17:47:22 --> 404 Page Not Found: Payoutschedule/index
ERROR - 2020-05-30 17:50:03 --> 404 Page Not Found: Wordpress/index
ERROR - 2020-05-30 17:50:10 --> 404 Page Not Found: Payoutschedule/index
ERROR - 2020-05-30 17:51:46 --> 404 Page Not Found: Payoutschedule/index
ERROR - 2020-05-30 17:52:30 --> 404 Page Not Found: Payoutschedule/index
ERROR - 2020-05-30 17:54:40 --> 404 Page Not Found: Change_password/index
ERROR - 2020-05-30 17:55:35 --> 404 Page Not Found: GetSellers/index
ERROR - 2020-05-30 17:55:36 --> 404 Page Not Found: GetNotificationState/index
ERROR - 2020-05-30 17:55:59 --> 404 Page Not Found: Signin/index
ERROR - 2020-05-30 18:58:34 --> Severity: Notice --> Undefined index: user_id /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 692
ERROR - 2020-05-30 18:58:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 697
ERROR - 2020-05-30 18:58:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 735
ERROR - 2020-05-30 19:00:36 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 697
ERROR - 2020-05-30 19:00:36 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 735
ERROR - 2020-05-30 18:06:41 --> 404 Page Not Found: Signin/index
ERROR - 2020-05-30 19:06:57 --> Severity: Notice --> Undefined index: emailorphone /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 237
ERROR - 2020-05-30 19:06:57 --> Severity: Notice --> Undefined index: device_token /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 239
ERROR - 2020-05-30 19:06:57 --> Severity: Notice --> Undefined index: type /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 240
ERROR - 2020-05-30 19:06:57 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 251
ERROR - 2020-05-30 19:06:57 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 255
ERROR - 2020-05-30 19:07:19 --> Severity: Notice --> Undefined index: emailorphone /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 237
ERROR - 2020-05-30 19:07:19 --> Severity: Notice --> Undefined index: device_token /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 239
ERROR - 2020-05-30 19:07:19 --> Severity: Notice --> Undefined index: type /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 240
ERROR - 2020-05-30 19:07:19 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 251
ERROR - 2020-05-30 19:07:19 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 255
ERROR - 2020-05-30 19:07:51 --> Severity: Notice --> Undefined index: device_token /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 239
ERROR - 2020-05-30 19:07:51 --> Severity: Notice --> Undefined index: type /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 240
ERROR - 2020-05-30 19:07:51 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 251
ERROR - 2020-05-30 19:07:51 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 255
ERROR - 2020-05-30 19:08:13 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 251
ERROR - 2020-05-30 19:17:26 --> Severity: Notice --> Trying to get property 'password' of non-object /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 261
ERROR - 2020-05-30 19:17:52 --> Severity: Notice --> Trying to get property 'password' of non-object /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 261
ERROR - 2020-05-30 19:18:29 --> Severity: Notice --> Trying to get property 'password' of non-object /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 261
ERROR - 2020-05-30 19:18:38 --> Severity: Notice --> Trying to get property 'password' of non-object /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 261
ERROR - 2020-05-30 19:19:13 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 251
ERROR - 2020-05-30 19:19:13 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 255
ERROR - 2020-05-30 19:19:21 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 251
ERROR - 2020-05-30 19:19:21 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 255
ERROR - 2020-05-30 19:23:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 251
ERROR - 2020-05-30 19:23:25 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$password /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 261
ERROR - 2020-05-30 19:24:24 --> Severity: Notice --> Trying to get property 'password' of non-object /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 261
ERROR - 2020-05-30 19:25:29 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$password /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 261
ERROR - 2020-05-30 19:25:30 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$password /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 261
ERROR - 2020-05-30 19:28:21 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 697
ERROR - 2020-05-30 19:28:21 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 735
ERROR - 2020-05-30 19:30:09 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 697
ERROR - 2020-05-30 19:30:09 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 735
ERROR - 2020-05-30 19:31:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 698
ERROR - 2020-05-30 19:31:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 736
ERROR - 2020-05-30 19:33:45 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 736
ERROR - 2020-05-30 19:34:52 --> Severity: error --> Exception: Call to undefined method stdClass::num_rows() /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 736
ERROR - 2020-05-30 19:34:52 --> Severity: error --> Exception: Call to undefined method stdClass::num_rows() /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 736
ERROR - 2020-05-30 19:34:52 --> Severity: error --> Exception: Call to undefined method stdClass::num_rows() /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 736
ERROR - 2020-05-30 19:34:52 --> Severity: error --> Exception: Call to undefined method stdClass::num_rows() /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 736
ERROR - 2020-05-30 19:35:09 --> Severity: error --> Exception: Call to undefined method stdClass::num_rows() /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 736
ERROR - 2020-05-30 19:37:12 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$id /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 738
ERROR - 2020-05-30 19:37:12 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$mon /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 739
ERROR - 2020-05-30 19:37:12 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$tue /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 740
ERROR - 2020-05-30 19:37:12 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$wed /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 741
ERROR - 2020-05-30 19:37:12 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$thr /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 742
ERROR - 2020-05-30 19:37:12 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$fri /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 743
ERROR - 2020-05-30 19:37:12 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$sat /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 744
ERROR - 2020-05-30 19:37:12 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$sun /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 745
ERROR - 2020-05-30 19:39:50 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$mon /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 739
ERROR - 2020-05-30 19:39:50 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$tue /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 740
ERROR - 2020-05-30 19:39:50 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$wed /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 741
ERROR - 2020-05-30 19:39:50 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$thr /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 742
ERROR - 2020-05-30 19:39:50 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$fri /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 743
ERROR - 2020-05-30 19:39:50 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$sat /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 744
ERROR - 2020-05-30 19:39:50 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$sun /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 745
ERROR - 2020-05-30 19:56:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 736
ERROR - 2020-05-30 19:03:21 --> 404 Page Not Found: Signin/index
ERROR - 2020-05-30 19:03:24 --> 404 Page Not Found: Signin/index
ERROR - 2020-05-30 19:03:59 --> 404 Page Not Found: Signin/index
ERROR - 2020-05-30 19:04:51 --> 404 Page Not Found: Signin/index
ERROR - 2020-05-30 19:07:06 --> 404 Page Not Found: Signin/index
ERROR - 2020-05-30 19:09:00 --> 404 Page Not Found: Signin/index
ERROR - 2020-05-30 19:10:24 --> 404 Page Not Found: GetSellers/index
ERROR - 2020-05-30 19:11:04 --> 404 Page Not Found: GetBooking/index
ERROR - 2020-05-30 19:12:36 --> 404 Page Not Found: GetSellers/index
ERROR - 2020-05-30 19:14:10 --> 404 Page Not Found: GetSellers/index
