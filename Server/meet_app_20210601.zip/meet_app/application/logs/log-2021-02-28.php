<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-28 07:50:33 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-02-28 07:50:34 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-02-28 08:40:45 --> 404 Page Not Found: Downloader/index
ERROR - 2021-02-28 08:43:21 --> 404 Page Not Found: Downloader/index
ERROR - 2021-02-28 14:50:09 --> 404 Page Not Found: Robotstxt/index
