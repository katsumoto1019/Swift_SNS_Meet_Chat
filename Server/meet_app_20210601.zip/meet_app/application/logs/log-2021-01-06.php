<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-06 03:28:58 --> 404 Page Not Found: Env/index
ERROR - 2021-01-06 03:29:10 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2021-01-06 07:46:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-01-06 07:50:19 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-01-06 07:50:19 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-01-06 10:29:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-01-06 10:30:01 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-01-06 17:17:54 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-01-06 18:34:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-01-06 22:09:44 --> 404 Page Not Found: Env/index
