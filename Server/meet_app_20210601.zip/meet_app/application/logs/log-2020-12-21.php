<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-21 06:21:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'LIKE5fd1d592f19b1535b3730b4a%OR%5fd1d592f19b1535b3730b4a%OR%5fd1d592f19b1535b373' at line 1 - Invalid query: SELECT user_id FROM `tb_blockusers` WHERE blocks LIKE5fd1d592f19b1535b3730b4a%OR%5fd1d592f19b1535b3730b4a%OR%5fd1d592f19b1535b3730b4a
ERROR - 2020-12-21 01:01:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-21 07:41:15 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-12-21 07:41:16 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-12-21 18:20:10 --> 404 Page Not Found: Robotstxt/index
