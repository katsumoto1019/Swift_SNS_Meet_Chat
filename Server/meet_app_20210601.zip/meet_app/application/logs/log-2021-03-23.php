<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-23 00:44:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-03-23 03:36:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-03-23 06:39:56 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-03-23 06:39:57 --> 404 Page Not Found: 404javascriptjs/index
