<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-27 02:05:18 --> 404 Page Not Found: Wp_admin/install.php
ERROR - 2020-12-27 07:44:43 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-12-27 07:44:44 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-12-27 23:14:56 --> 404 Page Not Found: Robotstxt/index
