<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-02 02:26:34 --> Severity: error --> Exception: Too few arguments to function Api::sendRefund(), 0 passed in /home/kaysmbfnu0fv/public_html/system/core/CodeIgniter.php on line 514 and exactly 2 expected /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 1288
ERROR - 2020-06-02 05:44:05 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-06-02 05:44:05 --> 404 Page Not Found: Well_known/autoconfig
ERROR - 2020-06-02 06:07:02 --> 404 Page Not Found: Wp_admin/index
ERROR - 2020-06-02 09:04:18 --> 404 Page Not Found: Blackhatphp/index
ERROR - 2020-06-02 12:40:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-02 12:40:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-02 14:27:19 --> 404 Page Not Found: Cache/s_noeval.php
ERROR - 2020-06-02 14:47:13 --> 404 Page Not Found: Well_known/acme_challenge
ERROR - 2020-06-02 14:47:13 --> 404 Page Not Found: Well_known/acme_challenge
ERROR - 2020-06-02 15:41:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-02 16:16:11 --> Severity: error --> Exception: syntax error, unexpected 's' (T_STRING), expecting function (T_FUNCTION) or const (T_CONST) /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 20
ERROR - 2020-06-02 16:30:41 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-06-02 16:59:16 --> 404 Page Not Found: Wp_configphpswp/index
ERROR - 2020-06-02 23:40:16 --> 404 Page Not Found: Wp_admin/css
