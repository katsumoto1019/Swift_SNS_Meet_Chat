<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-14 04:47:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-01-14 04:47:56 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-01-14 04:47:57 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-01-14 07:48:26 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-01-14 07:48:26 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-01-14 14:29:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-01-14 16:20:57 --> 404 Page Not Found: Wp_admin/admin_ajax.php
ERROR - 2021-01-14 23:06:31 --> 404 Page Not Found: Wp_loginphp/index
