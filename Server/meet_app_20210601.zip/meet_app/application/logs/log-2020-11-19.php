<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-19 07:48:03 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-11-19 07:48:04 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-11-19 18:15:53 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-11-19 22:29:38 --> 404 Page Not Found: Apple_touch_icon_120x120_precomposedpng/index
ERROR - 2020-11-19 22:29:39 --> 404 Page Not Found: Apple_touch_icon_120x120png/index
ERROR - 2020-11-19 22:29:39 --> 404 Page Not Found: Apple_touch_iconpng/index
ERROR - 2020-11-19 22:29:39 --> 404 Page Not Found: Apple_touch_iconpng/index
ERROR - 2020-11-19 22:34:50 --> 404 Page Not Found: Apple_touch_icon_120x120_precomposedpng/index
ERROR - 2020-11-19 22:34:50 --> 404 Page Not Found: Apple_touch_icon_120x120png/index
ERROR - 2020-11-19 22:34:50 --> 404 Page Not Found: Apple_touch_iconpng/index
ERROR - 2020-11-19 22:34:50 --> 404 Page Not Found: Apple_touch_iconpng/index
