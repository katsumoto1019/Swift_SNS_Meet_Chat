<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-11 01:58:26 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-11-11 11:59:10 --> Query error: Unknown column 'joined_date' in 'field list' - Invalid query: UPDATE `tb_user1` SET `token` = 'c9p4b8LCD0axlBcgxzGQOW:APA91bFmfCoDcAI3dp0dee8NkfbMVBAr7px-oiMJl7HRI5R9xDpMX9ZO4DJwjL65flnZK2VXQDg-mqyP6JxywFjshjdkTU2VFrNorTW3YGILRUyI35AUD1PjJyvm4yAI8174TgqhLIwA', `joined_date` = '2020-11-11 02:59:05 +0000', `is_plus_member` = 'false'
ERROR - 2020-11-11 12:00:29 --> Query error: Unknown column 'joined_date' in 'field list' - Invalid query: INSERT INTO `tb_user1` (`user_id`, `token`, `joined_date`, `is_plus_member`) VALUES ('5f22d9cdd2c7032c76cf9457', 'c9p4b8LCD0axlBcgxzGQOW:APA91bFmfCoDcAI3dp0dee8NkfbMVBAr7px-oiMJl7HRI5R9xDpMX9ZO4DJwjL65flnZK2VXQDg-mqyP6JxywFjshjdkTU2VFrNorTW3YGILRUyI35AUD1PjJyvm4yAI8174TgqhLIwA', '2020-11-11 03:00:28 +0000', 'false')
ERROR - 2020-11-11 12:03:51 --> Query error: Unknown column 'joined_date' in 'field list' - Invalid query: INSERT INTO `tb_user1` (`user_id`, `token`, `joined_date`, `is_plus_member`) VALUES ('5f22d9cdd2c7032c76cf9457', 'c9p4b8LCD0axlBcgxzGQOW:APA91bFmfCoDcAI3dp0dee8NkfbMVBAr7px-oiMJl7HRI5R9xDpMX9ZO4DJwjL65flnZK2VXQDg-mqyP6JxywFjshjdkTU2VFrNorTW3YGILRUyI35AUD1PjJyvm4yAI8174TgqhLIwA', '2020-11-11 03:02:54 +0000', 'false')
ERROR - 2020-11-11 12:11:24 --> Query error: Unknown column 'joined_date' in 'field list' - Invalid query: INSERT INTO `tb_user1` (`user_id`, `token`, `joined_date`, `is_plus_member`) VALUES ('5f56eccb100a7d372df45a51', '123456789011', '2020-10-11', 'false')
ERROR - 2020-11-11 03:14:31 --> 404 Page Not Found: Apple_touch_icon_120x120_precomposedpng/index
ERROR - 2020-11-11 03:14:31 --> 404 Page Not Found: Apple_touch_icon_120x120png/index
ERROR - 2020-11-11 03:14:31 --> 404 Page Not Found: Apple_touch_iconpng/index
ERROR - 2020-11-11 03:14:31 --> 404 Page Not Found: Apple_touch_iconpng/index
ERROR - 2020-11-11 03:14:44 --> 404 Page Not Found: Apple_touch_icon_120x120_precomposedpng/index
ERROR - 2020-11-11 03:14:44 --> 404 Page Not Found: Apple_touch_icon_120x120png/index
ERROR - 2020-11-11 03:14:45 --> 404 Page Not Found: Apple_touch_iconpng/index
ERROR - 2020-11-11 03:14:45 --> 404 Page Not Found: Apple_touch_iconpng/index
ERROR - 2020-11-11 07:44:22 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-11-11 07:44:23 --> 404 Page Not Found: 404javascriptjs/index
