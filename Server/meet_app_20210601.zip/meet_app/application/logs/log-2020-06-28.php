<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-28 01:24:08 --> 404 Page Not Found: Wp_dbsphp/index
ERROR - 2020-06-28 01:24:09 --> 404 Page Not Found: Wp_dbsphp/index
ERROR - 2020-06-28 02:45:34 --> Severity: error --> Exception: No such token: tok_1GypaKH3tb3qjpqaCr6eyth8; a similar object exists in test mode, but a live mode key was used to make this request. /home/kaysmbfnu0fv/public_html/vendor/stripe/stripe-php/lib/Exception/ApiErrorException.php 38
ERROR - 2020-06-28 02:49:47 --> Severity: error --> Exception: No such token: tok_1GypePH3tb3qjpqalgBPDFpW; a similar object exists in test mode, but a live mode key was used to make this request. /home/kaysmbfnu0fv/public_html/vendor/stripe/stripe-php/lib/Exception/ApiErrorException.php 38
ERROR - 2020-06-28 02:23:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-28 02:23:09 --> 404 Page Not Found: Terms_of_use/index
ERROR - 2020-06-28 04:00:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-28 04:15:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-28 04:15:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-28 04:15:26 --> 404 Page Not Found: App_adstxt/index
ERROR - 2020-06-28 04:16:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-28 04:16:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-28 04:16:03 --> 404 Page Not Found: App_adstxt/index
ERROR - 2020-06-28 04:16:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-28 04:16:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-28 04:16:08 --> 404 Page Not Found: App_adstxt/index
ERROR - 2020-06-28 04:16:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-28 04:16:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-28 04:16:40 --> 404 Page Not Found: App_adstxt/index
ERROR - 2020-06-28 04:17:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-28 04:17:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-28 04:17:07 --> 404 Page Not Found: App_adstxt/index
ERROR - 2020-06-28 04:17:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-28 04:17:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-28 04:17:13 --> 404 Page Not Found: App_adstxt/index
ERROR - 2020-06-28 08:02:30 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-06-28 08:02:31 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-06-28 08:43:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-28 09:26:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-28 09:26:07 --> 404 Page Not Found: Feed/index
ERROR - 2020-06-28 11:35:35 --> Severity: error --> Exception: No such token: tok_1GyxrDH3tb3qjpqakRCJLina; a similar object exists in test mode, but a live mode key was used to make this request. /home/kaysmbfnu0fv/public_html/vendor/stripe/stripe-php/lib/Exception/ApiErrorException.php 38
ERROR - 2020-06-28 10:47:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-28 10:47:26 --> 404 Page Not Found: Homepage_2/feed
ERROR - 2020-06-28 10:57:08 --> 404 Page Not Found: Comments/feed
ERROR - 2020-06-28 11:42:59 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-06-28 11:43:00 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-06-28 12:47:01 --> Severity: error --> Exception: No such token: tok_1GyyyOH3tb3qjpqaejDXFjsg; a similar object exists in test mode, but a live mode key was used to make this request. /home/kaysmbfnu0fv/public_html/vendor/stripe/stripe-php/lib/Exception/ApiErrorException.php 38
ERROR - 2020-06-28 12:28:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-28 14:40:50 --> Severity: error --> Exception: Amount must be at least $0.50 usd /home/kaysmbfnu0fv/public_html/vendor/stripe/stripe-php/lib/Exception/ApiErrorException.php 38
ERROR - 2020-06-28 14:50:58 --> Severity: error --> Exception: Amount must be at least $0.50 usd /home/kaysmbfnu0fv/public_html/vendor/stripe/stripe-php/lib/Exception/ApiErrorException.php 38
ERROR - 2020-06-28 14:57:46 --> Severity: error --> Exception: Amount must be at least $0.50 usd /home/kaysmbfnu0fv/public_html/vendor/stripe/stripe-php/lib/Exception/ApiErrorException.php 38
ERROR - 2020-06-28 15:04:05 --> Severity: error --> Exception: Amount must be at least $0.50 usd /home/kaysmbfnu0fv/public_html/vendor/stripe/stripe-php/lib/Exception/ApiErrorException.php 38
ERROR - 2020-06-28 15:12:30 --> Severity: error --> Exception: Amount must be at least $0.50 usd /home/kaysmbfnu0fv/public_html/vendor/stripe/stripe-php/lib/Exception/ApiErrorException.php 38
ERROR - 2020-06-28 15:20:58 --> Severity: error --> Exception: Amount must be at least $0.50 usd /home/kaysmbfnu0fv/public_html/vendor/stripe/stripe-php/lib/Exception/ApiErrorException.php 38
ERROR - 2020-06-28 16:20:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-28 17:40:59 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-06-28 17:41:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-06-28 17:41:40 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-06-28 17:41:46 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-06-28 17:41:48 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-06-28 17:41:50 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-06-28 17:41:52 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-06-28 17:41:59 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-06-28 17:42:01 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-06-28 21:10:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-28 21:10:24 --> 404 Page Not Found: App_adstxt/index
ERROR - 2020-06-28 23:18:10 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-06-28 23:18:38 --> 404 Page Not Found: Manifestjson/index
