<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-04 01:27:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-04 01:27:20 --> 404 Page Not Found: Asset_manifestjson/index
ERROR - 2021-05-04 06:34:31 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-05-04 06:34:32 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-05-04 09:52:26 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-05-04 09:52:26 --> 404 Page Not Found: Wordpress/wp_login.php
ERROR - 2021-05-04 09:52:27 --> 404 Page Not Found: Blog/wp_login.php
ERROR - 2021-05-04 09:52:27 --> 404 Page Not Found: Wp/wp_login.php
ERROR - 2021-05-04 12:52:38 --> 404 Page Not Found: Wp_json/wp
ERROR - 2021-05-04 17:27:51 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-05-04 17:27:51 --> 404 Page Not Found: Wordpress/wp_login.php
ERROR - 2021-05-04 17:27:52 --> 404 Page Not Found: Blog/wp_login.php
ERROR - 2021-05-04 17:27:52 --> 404 Page Not Found: Wp/wp_login.php
ERROR - 2021-05-04 18:02:43 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-05-04 21:47:17 --> 404 Page Not Found: Env/index
