<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-14 23:52:55 --> 404 Page Not Found: Shopphp/index
ERROR - 2020-08-14 23:52:58 --> 404 Page Not Found: Newsphp/index
