<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-26 04:17:55 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-01-26 06:31:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-01-26 07:50:20 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-01-26 07:50:21 --> 404 Page Not Found: 404javascriptjs/index
