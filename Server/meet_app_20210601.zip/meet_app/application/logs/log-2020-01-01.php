<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-01 06:09:45 --> 404 Page Not Found: Api/submitFCM
