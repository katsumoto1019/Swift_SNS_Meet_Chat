<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-21 00:37:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-10-21 01:28:22 --> 404 Page Not Found: Apple_touch_iconpng/index
ERROR - 2020-10-21 01:28:22 --> 404 Page Not Found: Apple_touch_icon_precomposedpng/index
ERROR - 2020-10-21 01:53:47 --> 404 Page Not Found: Skins/landingassets
ERROR - 2020-10-21 01:53:47 --> 404 Page Not Found: Skins/landingassets
ERROR - 2020-10-21 05:30:43 --> 404 Page Not Found: Skins/landingassets
ERROR - 2020-10-21 05:30:43 --> 404 Page Not Found: Skins/landingassets
ERROR - 2020-10-21 06:44:08 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-10-21 06:44:09 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-10-21 07:45:22 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-10-21 15:34:20 --> 404 Page Not Found: Robotstxt/index
