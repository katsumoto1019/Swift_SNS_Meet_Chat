<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-20 14:54:16 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-20 14:54:16 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-20 16:54:21 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-20 16:38:08 --> Severity: Notice --> Undefined index: realname C:\xampp\htdocs\application\controllers\Api.php 90
ERROR - 2020-07-20 16:38:08 --> Severity: Notice --> Undefined index: token C:\xampp\htdocs\application\controllers\Api.php 94
ERROR - 2020-07-20 17:38:13 --> 404 Page Not Found: Api/getRecommend
ERROR - 2020-07-20 16:38:13 --> Severity: Notice --> Undefined index: mail C:\xampp\htdocs\application\controllers\Api.php 247
ERROR - 2020-07-20 17:38:16 --> 404 Page Not Found: Api/getCategories
ERROR - 2020-07-20 17:38:17 --> 404 Page Not Found: EduLive/api
ERROR - 2020-07-20 17:38:17 --> 404 Page Not Found: Api/removeContent
ERROR - 2020-07-20 17:38:20 --> 404 Page Not Found: Api/getMyContents
ERROR - 2020-07-20 17:38:21 --> 404 Page Not Found: EduLive/api
ERROR - 2020-07-20 17:38:22 --> 404 Page Not Found: Api/getPaid
ERROR - 2020-07-20 17:38:22 --> 404 Page Not Found: Api/getUsers
ERROR - 2020-07-20 17:38:22 --> 404 Page Not Found: Api/favorite
ERROR - 2020-07-20 16:38:22 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\application\controllers\Api.php 194
ERROR - 2020-07-20 16:38:22 --> Severity: Notice --> Undefined index: first_name C:\xampp\htdocs\application\controllers\Api.php 195
ERROR - 2020-07-20 16:38:22 --> Severity: Notice --> Undefined index: last_name C:\xampp\htdocs\application\controllers\Api.php 196
ERROR - 2020-07-20 16:38:22 --> Severity: Notice --> Undefined index: user_name C:\xampp\htdocs\application\controllers\Api.php 197
ERROR - 2020-07-20 16:38:22 --> Severity: Notice --> Undefined index: dob C:\xampp\htdocs\application\controllers\Api.php 200
ERROR - 2020-07-20 16:38:22 --> Severity: Notice --> Undefined index: gender C:\xampp\htdocs\application\controllers\Api.php 201
ERROR - 2020-07-20 16:38:22 --> Severity: Notice --> Undefined index: ssn C:\xampp\htdocs\application\controllers\Api.php 202
ERROR - 2020-07-20 16:38:22 --> Query error: Unknown column 'first_name' in 'field list' - Invalid query: UPDATE `tb_user` SET `first_name` = NULL, `last_name` = NULL, `email` = 'teacher3@gmail.com', `phone` = '+8642614733', `username` = NULL, `dob` = NULL, `gender` = NULL, `ssn` = NULL, `picture` = 'http://127.0.0.1:8080/uploadfiles/userphoto/1595259502462.png'
WHERE `id` IS NULL
ERROR - 2020-07-20 17:38:22 --> 404 Page Not Found: Api/emailExist
ERROR - 2020-07-20 17:38:24 --> 404 Page Not Found: EduLive/api
ERROR - 2020-07-20 17:38:27 --> 404 Page Not Found: EduLive/api
ERROR - 2020-07-20 17:38:27 --> 404 Page Not Found: EduLive/api
ERROR - 2020-07-20 17:49:42 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\application\controllers\Api.php 185
ERROR - 2020-07-20 18:55:28 --> Severity: error --> Exception: syntax error, unexpected 'w' (T_STRING), expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\application\controllers\Api.php 57
ERROR - 2020-07-20 18:14:37 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\application\controllers\Api.php 177
ERROR - 2020-07-20 19:15:23 --> Severity: error --> Exception: syntax error, unexpected 'class' (T_CLASS) C:\xampp\htdocs\application\controllers\Api.php 18
ERROR - 2020-07-20 18:54:08 --> Severity: Notice --> Undefined index: timestamp C:\xampp\htdocs\application\controllers\Api.php 285
ERROR - 2020-07-20 18:54:08 --> Query error: Table 'emoglass.tb_choice' doesn't exist - Invalid query: SELECT *
FROM `tb_choice`
WHERE `timestamp` IS NULL
ERROR - 2020-07-20 21:24:16 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\application\controllers\Api.php 316
ERROR - 2020-07-20 21:24:16 --> Query error: Table 'emoglass.tb_choice' doesn't exist - Invalid query: SELECT *
FROM `tb_choice`
ORDER BY `id` DESC
ERROR - 2020-07-20 22:07:41 --> Query error: Table 'emoglass.tb_favorite' doesn't exist - Invalid query: INSERT INTO `tb_favorite` (`owner_id`, `post_id`, `user_id`, `user_name`, `user_photo`) VALUES ('6', '1', '6', 'sdfsdfsdf', 'sdfsdfsdf')
ERROR - 2020-07-20 23:10:09 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\application\controllers\Api.php 326
ERROR - 2020-07-20 23:10:20 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\application\controllers\Api.php 326
ERROR - 2020-07-20 23:13:32 --> Severity: Compile Error --> Cannot redeclare Api::like() C:\xampp\htdocs\application\controllers\Api.php 330
ERROR - 2020-07-20 22:15:14 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-20 22:15:14 --> Severity: Notice --> Undefined property: stdClass::$first_name C:\xampp\htdocs\application\views\admin\users.php 93
ERROR - 2020-07-20 22:15:14 --> Severity: Notice --> Undefined property: stdClass::$last_name C:\xampp\htdocs\application\views\admin\users.php 94
ERROR - 2020-07-20 22:15:14 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\application\views\admin\users.php 98
ERROR - 2020-07-20 22:15:14 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\application\views\admin\users.php 99
ERROR - 2020-07-20 22:15:14 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\application\views\admin\users.php 100
ERROR - 2020-07-20 22:15:14 --> Severity: Notice --> Undefined property: stdClass::$zipcode C:\xampp\htdocs\application\views\admin\users.php 101
ERROR - 2020-07-20 22:15:14 --> Severity: Notice --> Undefined property: stdClass::$provinces C:\xampp\htdocs\application\views\admin\users.php 102
ERROR - 2020-07-20 22:15:14 --> Severity: Notice --> Undefined property: stdClass::$unit C:\xampp\htdocs\application\views\admin\users.php 103
ERROR - 2020-07-20 22:15:14 --> Severity: Notice --> Undefined property: stdClass::$unit_name C:\xampp\htdocs\application\views\admin\users.php 104
ERROR - 2020-07-20 22:15:14 --> Severity: Notice --> Undefined property: stdClass::$occupation C:\xampp\htdocs\application\views\admin\users.php 105
ERROR - 2020-07-20 22:15:14 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\application\views\admin\users.php 106
ERROR - 2020-07-20 22:15:14 --> Severity: Notice --> Undefined property: stdClass::$p_first_name C:\xampp\htdocs\application\views\admin\users.php 107
ERROR - 2020-07-20 22:15:14 --> Severity: Notice --> Undefined property: stdClass::$p_last_name C:\xampp\htdocs\application\views\admin\users.php 108
ERROR - 2020-07-20 22:15:14 --> Severity: Notice --> Undefined property: stdClass::$p_relation C:\xampp\htdocs\application\views\admin\users.php 109
ERROR - 2020-07-20 22:15:14 --> Severity: Notice --> Undefined property: stdClass::$p_phone C:\xampp\htdocs\application\views\admin\users.php 110
ERROR - 2020-07-20 22:20:09 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-20 22:22:13 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-20 22:22:26 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-20 22:22:35 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-20 22:39:54 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-20 22:40:43 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-20 22:41:48 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-20 22:46:34 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-20 22:47:19 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-20 22:48:17 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-20 22:48:25 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-20 22:49:10 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-20 22:49:10 --> Severity: Notice --> Undefined property: stdClass::$amount C:\xampp\htdocs\application\views\admin\comments.php 77
ERROR - 2020-07-20 22:49:10 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\application\views\admin\comments.php 78
ERROR - 2020-07-20 22:49:10 --> Severity: Notice --> Undefined property: stdClass::$amount C:\xampp\htdocs\application\views\admin\comments.php 77
ERROR - 2020-07-20 22:49:10 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\application\views\admin\comments.php 78
ERROR - 2020-07-20 22:54:45 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-20 22:55:03 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-20 22:55:07 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-20 22:55:09 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-20 22:56:04 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-20 22:56:50 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-20 22:56:54 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-20 22:58:49 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-20 22:58:49 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\application\views\admin\comments.php 80
ERROR - 2020-07-20 22:58:49 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\application\views\admin\comments.php 80
ERROR - 2020-07-20 22:59:58 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-20 22:59:58 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\application\views\admin\comments.php 80
ERROR - 2020-07-20 22:59:58 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\application\views\admin\comments.php 80
ERROR - 2020-07-20 22:59:59 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-20 22:59:59 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\application\views\admin\comments.php 80
ERROR - 2020-07-20 22:59:59 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\application\views\admin\comments.php 80
ERROR - 2020-07-20 23:00:54 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-20 23:01:03 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-20 23:03:58 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-20 23:05:51 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-20 23:05:53 --> Severity: Notice --> Undefined variable: portofolio C:\xampp\htdocs\application\views\admin\user-detail.php 68
ERROR - 2020-07-20 23:05:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\user-detail.php 68
ERROR - 2020-07-20 23:06:49 --> Severity: Notice --> Undefined variable: portofolio C:\xampp\htdocs\application\views\admin\user-detail.php 68
ERROR - 2020-07-20 23:06:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\user-detail.php 68
ERROR - 2020-07-20 23:08:27 --> Severity: Notice --> Undefined variable: portofolio C:\xampp\htdocs\application\views\admin\user-detail.php 68
ERROR - 2020-07-20 23:08:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\user-detail.php 68
ERROR - 2020-07-20 23:09:05 --> Severity: Notice --> Undefined variable: portofolio C:\xampp\htdocs\application\views\admin\user-detail.php 68
ERROR - 2020-07-20 23:09:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\user-detail.php 68
ERROR - 2020-07-20 23:09:17 --> Severity: Notice --> Undefined variable: portofolio C:\xampp\htdocs\application\views\admin\user-detail.php 68
ERROR - 2020-07-20 23:09:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\user-detail.php 68
ERROR - 2020-07-20 23:09:39 --> Severity: Notice --> Undefined variable: portofolio C:\xampp\htdocs\application\views\admin\user-detail.php 68
ERROR - 2020-07-20 23:09:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\user-detail.php 68
ERROR - 2020-07-20 23:15:54 --> Severity: Notice --> Undefined variable: service C:\xampp\htdocs\application\views\admin\user-detail.php 78
ERROR - 2020-07-20 23:15:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\user-detail.php 78
ERROR - 2020-07-20 23:15:54 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\application\views\admin\user-detail.php 95
ERROR - 2020-07-20 23:15:54 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\application\views\admin\user-detail.php 95
ERROR - 2020-07-20 23:15:54 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\application\views\admin\user-detail.php 95
ERROR - 2020-07-20 23:15:54 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\application\views\admin\user-detail.php 95
ERROR - 2020-07-20 23:15:54 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\application\views\admin\user-detail.php 95
ERROR - 2020-07-20 23:15:54 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\application\views\admin\user-detail.php 95
ERROR - 2020-07-20 23:15:54 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\application\views\admin\user-detail.php 95
ERROR - 2020-07-20 23:15:54 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\application\views\admin\user-detail.php 95
ERROR - 2020-07-20 23:15:54 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\application\views\admin\user-detail.php 95
ERROR - 2020-07-20 23:15:54 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\application\views\admin\user-detail.php 95
ERROR - 2020-07-20 23:15:54 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\application\views\admin\user-detail.php 95
ERROR - 2020-07-20 23:15:54 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\application\views\admin\user-detail.php 95
ERROR - 2020-07-20 23:15:54 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\application\views\admin\user-detail.php 95
ERROR - 2020-07-20 23:15:54 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\application\views\admin\user-detail.php 95
ERROR - 2020-07-20 23:15:54 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\application\views\admin\user-detail.php 95
ERROR - 2020-07-20 23:15:54 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\application\views\admin\user-detail.php 95
ERROR - 2020-07-20 23:15:54 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\application\views\admin\user-detail.php 95
ERROR - 2020-07-20 23:15:54 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\application\views\admin\user-detail.php 95
ERROR - 2020-07-20 23:15:54 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\application\views\admin\user-detail.php 95
ERROR - 2020-07-20 23:15:54 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\application\views\admin\user-detail.php 95
ERROR - 2020-07-20 23:15:54 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\application\views\admin\user-detail.php 95
ERROR - 2020-07-20 23:15:54 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\application\views\admin\user-detail.php 95
ERROR - 2020-07-20 23:15:54 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:15:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:15:54 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:15:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:15:54 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:15:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:15:54 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:15:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:15:54 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:15:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:15:54 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 59
ERROR - 2020-07-20 23:15:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 59
ERROR - 2020-07-20 23:15:54 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 60
ERROR - 2020-07-20 23:15:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 60
ERROR - 2020-07-20 23:15:54 --> Severity: Notice --> Undefined variable: service C:\xampp\htdocs\application\views\admin\user-detail.php 78
ERROR - 2020-07-20 23:15:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\user-detail.php 78
ERROR - 2020-07-20 23:15:55 --> Severity: Notice --> Undefined variable: service C:\xampp\htdocs\application\views\admin\user-detail.php 78
ERROR - 2020-07-20 23:15:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\user-detail.php 78
ERROR - 2020-07-20 23:15:55 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\application\views\admin\user-detail.php 95
ERROR - 2020-07-20 23:15:55 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\application\views\admin\user-detail.php 95
ERROR - 2020-07-20 23:15:55 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\application\views\admin\user-detail.php 95
ERROR - 2020-07-20 23:15:55 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\application\views\admin\user-detail.php 95
ERROR - 2020-07-20 23:15:55 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\application\views\admin\user-detail.php 95
ERROR - 2020-07-20 23:15:55 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\application\views\admin\user-detail.php 95
ERROR - 2020-07-20 23:15:55 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\application\views\admin\user-detail.php 95
ERROR - 2020-07-20 23:15:55 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\application\views\admin\user-detail.php 95
ERROR - 2020-07-20 23:15:55 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\application\views\admin\user-detail.php 95
ERROR - 2020-07-20 23:15:55 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\application\views\admin\user-detail.php 95
ERROR - 2020-07-20 23:15:55 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\application\views\admin\user-detail.php 95
ERROR - 2020-07-20 23:15:55 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\application\views\admin\user-detail.php 95
ERROR - 2020-07-20 23:15:55 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\application\views\admin\user-detail.php 95
ERROR - 2020-07-20 23:15:55 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\application\views\admin\user-detail.php 95
ERROR - 2020-07-20 23:15:55 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\application\views\admin\user-detail.php 95
ERROR - 2020-07-20 23:15:55 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\application\views\admin\user-detail.php 95
ERROR - 2020-07-20 23:15:55 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\application\views\admin\user-detail.php 95
ERROR - 2020-07-20 23:15:55 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\application\views\admin\user-detail.php 95
ERROR - 2020-07-20 23:15:55 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\application\views\admin\user-detail.php 95
ERROR - 2020-07-20 23:15:55 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\application\views\admin\user-detail.php 95
ERROR - 2020-07-20 23:15:55 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\application\views\admin\user-detail.php 95
ERROR - 2020-07-20 23:15:55 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\application\views\admin\user-detail.php 95
ERROR - 2020-07-20 23:15:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:15:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:15:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:15:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:15:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:15:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:15:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:15:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:15:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:15:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:15:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 59
ERROR - 2020-07-20 23:15:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 59
ERROR - 2020-07-20 23:15:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 60
ERROR - 2020-07-20 23:15:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 60
ERROR - 2020-07-20 23:15:56 --> Severity: Notice --> Undefined variable: service C:\xampp\htdocs\application\views\admin\user-detail.php 78
ERROR - 2020-07-20 23:15:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\user-detail.php 78
ERROR - 2020-07-20 23:16:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:16:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:16:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:16:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:16:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:16:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:16:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:16:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:16:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:16:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:16:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 59
ERROR - 2020-07-20 23:16:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 59
ERROR - 2020-07-20 23:16:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 60
ERROR - 2020-07-20 23:16:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 60
ERROR - 2020-07-20 23:16:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:16:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:16:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:16:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:16:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:16:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:16:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:16:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:16:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:16:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:16:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 59
ERROR - 2020-07-20 23:16:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 59
ERROR - 2020-07-20 23:16:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 60
ERROR - 2020-07-20 23:16:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 60
ERROR - 2020-07-20 23:16:53 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:16:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:16:53 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:16:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:16:53 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:16:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:16:53 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:16:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:16:53 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:16:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:16:53 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 59
ERROR - 2020-07-20 23:16:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 59
ERROR - 2020-07-20 23:16:53 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 60
ERROR - 2020-07-20 23:16:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 60
ERROR - 2020-07-20 23:16:53 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:16:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:16:53 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:16:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:16:53 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:16:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:16:53 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:16:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:16:53 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:16:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:16:53 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 59
ERROR - 2020-07-20 23:16:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 59
ERROR - 2020-07-20 23:16:53 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 60
ERROR - 2020-07-20 23:16:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 60
ERROR - 2020-07-20 23:17:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:17:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:17:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:17:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:17:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:17:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:17:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:17:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:17:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:17:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:17:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 59
ERROR - 2020-07-20 23:17:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 59
ERROR - 2020-07-20 23:17:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 60
ERROR - 2020-07-20 23:17:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 60
ERROR - 2020-07-20 23:17:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:17:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:17:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:17:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:17:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:17:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:17:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:17:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:17:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:17:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:17:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 59
ERROR - 2020-07-20 23:17:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 59
ERROR - 2020-07-20 23:17:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 60
ERROR - 2020-07-20 23:17:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 60
ERROR - 2020-07-20 23:17:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:17:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:17:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:17:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:17:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:17:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:17:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:17:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:17:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:17:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:17:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 59
ERROR - 2020-07-20 23:17:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 59
ERROR - 2020-07-20 23:17:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 60
ERROR - 2020-07-20 23:17:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 60
ERROR - 2020-07-20 23:17:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:17:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:17:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:17:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:17:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:17:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:17:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:17:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:17:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:17:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:17:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 59
ERROR - 2020-07-20 23:17:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 59
ERROR - 2020-07-20 23:17:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 60
ERROR - 2020-07-20 23:17:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 60
ERROR - 2020-07-20 23:18:34 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:18:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:18:34 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:18:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:18:34 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:18:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:18:34 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:18:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:18:34 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:18:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:18:34 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 59
ERROR - 2020-07-20 23:18:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 59
ERROR - 2020-07-20 23:18:34 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 60
ERROR - 2020-07-20 23:18:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 60
ERROR - 2020-07-20 23:18:34 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:18:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:18:34 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:18:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:18:34 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:18:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:18:34 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:18:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:18:34 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:18:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:18:34 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 59
ERROR - 2020-07-20 23:18:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 59
ERROR - 2020-07-20 23:18:34 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 60
ERROR - 2020-07-20 23:18:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 60
ERROR - 2020-07-20 23:19:19 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-20 23:19:48 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-20 23:19:48 --> Severity: Notice --> Undefined property: stdClass::$user_id C:\xampp\htdocs\application\views\admin\users.php 87
ERROR - 2020-07-20 23:19:48 --> Severity: Notice --> Undefined property: stdClass::$user_name C:\xampp\htdocs\application\views\admin\users.php 88
ERROR - 2020-07-20 23:19:58 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-20 23:19:58 --> Severity: Notice --> Undefined property: stdClass::$user_id C:\xampp\htdocs\application\views\admin\users.php 87
ERROR - 2020-07-20 23:20:06 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-20 23:20:08 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:20:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:20:08 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:20:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:20:09 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:20:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:20:09 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:20:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:20:09 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:20:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:20:09 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 59
ERROR - 2020-07-20 23:20:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 59
ERROR - 2020-07-20 23:20:09 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 60
ERROR - 2020-07-20 23:20:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 60
ERROR - 2020-07-20 23:20:09 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:20:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:20:09 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:20:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:20:09 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:20:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:20:09 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:20:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:20:09 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:20:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:20:09 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 59
ERROR - 2020-07-20 23:20:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 59
ERROR - 2020-07-20 23:20:09 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 60
ERROR - 2020-07-20 23:20:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 60
ERROR - 2020-07-20 23:20:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:20:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:20:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:20:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:20:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:20:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:20:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:20:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:20:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:20:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:20:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 59
ERROR - 2020-07-20 23:20:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 59
ERROR - 2020-07-20 23:20:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 60
ERROR - 2020-07-20 23:20:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 60
ERROR - 2020-07-20 23:20:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:20:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:20:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:20:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:20:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:20:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:20:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:20:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:20:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:20:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:20:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 59
ERROR - 2020-07-20 23:20:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 59
ERROR - 2020-07-20 23:20:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 60
ERROR - 2020-07-20 23:20:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 60
ERROR - 2020-07-20 23:20:16 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-20 23:20:18 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:20:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:20:18 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:20:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:20:18 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:20:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:20:18 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:20:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:20:18 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:20:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:20:18 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 59
ERROR - 2020-07-20 23:20:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 59
ERROR - 2020-07-20 23:20:18 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 60
ERROR - 2020-07-20 23:20:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 60
ERROR - 2020-07-20 23:20:18 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:20:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:20:18 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:20:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:20:18 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:20:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:20:18 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:20:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:20:18 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:20:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:20:18 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 59
ERROR - 2020-07-20 23:20:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 59
ERROR - 2020-07-20 23:20:18 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 60
ERROR - 2020-07-20 23:20:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 60
ERROR - 2020-07-20 23:23:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:23:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:23:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:23:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:23:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:23:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:23:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:23:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:23:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:23:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:23:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:23:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:23:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:23:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:23:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:23:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:23:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:23:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:23:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:23:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:23:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:23:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:23:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:23:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:23:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:23:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:23:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:23:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:23:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:23:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:23:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:23:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:23:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:23:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:23:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:23:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:23:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:23:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:23:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:23:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:23:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:23:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:23:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:23:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:23:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:23:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:23:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:23:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:23:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:23:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:23:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:23:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:23:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:23:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:23:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:23:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:24:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:24:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:24:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:24:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:24:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:24:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:24:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:24:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:24:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:24:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:24:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:24:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:24:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:24:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:24:14 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:24:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:24:14 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:24:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:24:14 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:24:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:24:14 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:24:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:24:14 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:24:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:24:14 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:24:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:24:14 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:24:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:24:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:24:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:24:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:24:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:24:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:24:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:24:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:24:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:24:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:24:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:24:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:24:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:24:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:24:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:24:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:24:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:24:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:24:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:24:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:24:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:24:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:24:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:24:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:24:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:24:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:24:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:24:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:24:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:24:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:24:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:24:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:24:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:24:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:24:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:24:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:24:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:24:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:24:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:24:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:24:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:24:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:24:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:24:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:24:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:24:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:24:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:24:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:24:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:24:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:24:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:24:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:24:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:24:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:24:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:24:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:24:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:25:11 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:25:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:25:11 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:25:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:25:11 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:25:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:25:11 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:25:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:25:11 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:25:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:25:11 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:25:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:25:11 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:25:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:25:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:25:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:25:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:25:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:25:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:25:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:25:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:25:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:25:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:25:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:25:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:25:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:25:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:25:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:26:46 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:26:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:26:46 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:26:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:26:46 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:26:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:26:46 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:26:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:26:46 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:26:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:26:46 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:26:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:26:46 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:26:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:26:46 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:26:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:26:46 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:26:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:26:46 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:26:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:26:46 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:26:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:26:46 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:26:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:26:46 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:26:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:26:46 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:26:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:27:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:27:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:27:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:27:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:27:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:27:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:27:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:27:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:27:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:27:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:27:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:27:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:27:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:27:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:27:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:27:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:27:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:27:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:27:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:27:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:27:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:27:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:27:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:27:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:27:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:27:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:27:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:27:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:27:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:27:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:27:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:27:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:27:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:27:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:27:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:27:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:27:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:27:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:27:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:27:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:27:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:27:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:27:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:27:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:27:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:27:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:27:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:27:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:27:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:27:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:27:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:27:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:27:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:27:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:27:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:27:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:27:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:27:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:27:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:27:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:27:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:27:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:27:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:27:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:27:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:27:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:27:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:27:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:27:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:27:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:27:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:27:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:27:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:27:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:27:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:27:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:27:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:27:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:27:51 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:27:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:27:51 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:27:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:27:51 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:27:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:27:52 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:27:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:27:52 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:27:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:27:52 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:27:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:27:52 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:27:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:27:52 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:27:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:27:52 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:27:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:27:52 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:27:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:27:52 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:27:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:27:52 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:27:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:27:52 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:27:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:27:52 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:27:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:27:52 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:27:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:27:52 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:27:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:27:52 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:27:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:27:55 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:27:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:27:55 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:27:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:27:55 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:27:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:27:55 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:27:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:27:55 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:27:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:27:55 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:27:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:27:55 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:27:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:27:55 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:27:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:27:55 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:27:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:27:55 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:27:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:27:55 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:27:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:27:55 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:27:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:27:55 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:27:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:27:55 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:27:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:28:21 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:28:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:28:21 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:28:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:28:21 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:28:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:28:21 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:28:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:28:21 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:28:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:28:21 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:28:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:28:21 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:28:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:28:21 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:28:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:28:21 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:28:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:28:21 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:28:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:28:21 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:28:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:28:21 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:28:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:28:21 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:28:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:28:21 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:28:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:28:49 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:28:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:28:49 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:28:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:28:49 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:28:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:28:49 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:28:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:28:49 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:28:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:28:49 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:28:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:28:49 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:28:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:28:49 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:28:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:28:49 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:28:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:28:49 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:28:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:28:49 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:28:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:28:49 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:28:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:28:49 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:28:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:28:49 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:28:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:30:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:30:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:30:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:30:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:30:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:30:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:30:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:30:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:30:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:30:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:30:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:30:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:30:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:30:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:30:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:30:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:30:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:30:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:30:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:30:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:30:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:30:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:30:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:30:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:30:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:30:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:30:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:30:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:30:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:30:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:30:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:30:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:30:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:30:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:30:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:30:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:30:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:30:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:30:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:30:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:30:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:30:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:30:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:30:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:30:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:30:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:30:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:30:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:30:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:30:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:30:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:30:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:30:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:30:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:30:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:30:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:30:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:30:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:30:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:30:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:30:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:30:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:30:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:30:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:30:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:30:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:30:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:30:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:30:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:30:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:30:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:30:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 49
ERROR - 2020-07-20 23:30:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:30:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 52
ERROR - 2020-07-20 23:30:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:30:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:30:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:30:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:30:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:30:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:30:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:30:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:30:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:30:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:31:20 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:31:20 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:31:20 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:31:20 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:31:20 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:31:20 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:31:20 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:31:20 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:31:20 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:31:20 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:31:20 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:31:20 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:31:20 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:31:20 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:31:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:31:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:31:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:31:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:31:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:31:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:31:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:31:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:31:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:31:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:31:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:31:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:31:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:31:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:31:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:31:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:31:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:31:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:31:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:31:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:31:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:31:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:31:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:31:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:31:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:31:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:31:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:31:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:31:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:31:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:31:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:31:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:31:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:31:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:31:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:31:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:31:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:31:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:31:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:31:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:31:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:31:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:31:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:31:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:31:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:31:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:31:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:31:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:31:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:31:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:31:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:31:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:31:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:31:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:31:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:31:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:31:59 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:31:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:31:59 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:31:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:31:59 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:31:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:31:59 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:31:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:31:59 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:31:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:31:59 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:31:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:31:59 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:31:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:31:59 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:31:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:31:59 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:31:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:31:59 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:31:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:31:59 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:31:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:31:59 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:31:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:31:59 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:31:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:31:59 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:31:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:32:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:32:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:32:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:32:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:32:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:32:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:32:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:32:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:32:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:32:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:32:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:32:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:32:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:32:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:32:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:32:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:32:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:32:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:32:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:32:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:32:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:32:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:32:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:32:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:32:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:32:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:32:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:32:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:32:55 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:32:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:32:55 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:32:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:32:55 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:32:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:32:55 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:32:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:32:55 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:32:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:32:55 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:32:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:32:55 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:32:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:32:55 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:32:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:32:55 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:32:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:32:55 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:32:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:32:55 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:32:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:32:55 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:32:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:32:55 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:32:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:32:55 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:32:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:33:24 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:33:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:33:24 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:33:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:33:24 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:33:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:33:24 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:33:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:33:24 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:33:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:33:24 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:33:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:33:24 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:33:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:33:24 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:33:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:33:24 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:33:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:33:24 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:33:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:33:24 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:33:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:33:24 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:33:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:33:24 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:33:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:33:24 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:33:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:33:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:33:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:33:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:33:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:33:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:33:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:33:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:33:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:33:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:33:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:33:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:33:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:33:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:33:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:33:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:33:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:33:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:33:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:33:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:33:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:33:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:33:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:33:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:33:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:33:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:33:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:33:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:33:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:34:23 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:34:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:34:23 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:34:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:34:23 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:34:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:34:23 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:34:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:34:23 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:34:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:34:23 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:34:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:34:23 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:34:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:34:23 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:34:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:34:23 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:34:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:34:23 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:34:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:34:23 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:34:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:34:23 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:34:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:34:23 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:34:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:34:23 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:34:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:35:18 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:35:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:35:18 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:35:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:35:18 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:35:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:35:18 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:35:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:35:18 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:35:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:35:18 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:35:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:35:18 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:35:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:35:18 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:35:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:35:18 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:35:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:35:18 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:35:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:35:18 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:35:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:35:18 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:35:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:35:18 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:35:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:35:18 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:35:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:36:02 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:36:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:36:02 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:36:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:36:02 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:36:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:36:02 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:36:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:36:02 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:36:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:36:02 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:36:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:36:02 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:36:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:36:02 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:36:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:36:02 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:36:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:36:02 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:36:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:36:02 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:36:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:36:02 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:36:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:36:02 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:36:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:36:02 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:36:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:38:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:38:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:38:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:38:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:38:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:38:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:38:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:38:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:38:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:38:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:38:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:38:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:38:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:38:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:38:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:38:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:38:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:38:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:38:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:38:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:38:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:38:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:38:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:38:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:38:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:38:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:38:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:38:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:39:36 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:39:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:39:36 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:39:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:39:36 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:39:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:39:36 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:39:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:39:36 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:39:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:39:36 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:39:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:39:36 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:39:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:39:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:39:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:39:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:39:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:39:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:39:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:39:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:39:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:39:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:39:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:39:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:39:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:39:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:39:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:39:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:39:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:39:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:39:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:39:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:39:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:39:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:39:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:39:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:39:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:39:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:39:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:39:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:39:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:40:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:40:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:40:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:40:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:40:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:40:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:40:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:40:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:40:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:40:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:40:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:40:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:40:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:40:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:40:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:40:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:40:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:40:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:40:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:40:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:40:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:40:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:40:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:40:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:40:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:40:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:40:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:40:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:42:33 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:42:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:42:33 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:42:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:42:33 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:42:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:42:33 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:42:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:42:33 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:42:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:42:33 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:42:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:42:33 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:42:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:42:33 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:42:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:42:33 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:42:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:42:33 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:42:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:42:33 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:42:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:42:33 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:42:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:42:33 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:42:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:42:33 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:42:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:47:02 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-20 23:47:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:47:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:47:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:47:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:47:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:47:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:47:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:47:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:47:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:47:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:47:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:47:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:47:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:47:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:47:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:47:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:47:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:47:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:47:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:47:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:47:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:47:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:47:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:47:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:47:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:47:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:47:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:47:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:47:07 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-20 23:47:08 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:47:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:47:08 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:47:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:47:08 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:47:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:47:08 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:47:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:47:08 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:47:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:47:08 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:47:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:47:08 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:47:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:47:08 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:47:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:47:08 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:47:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:47:08 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:47:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:47:08 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:47:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:47:08 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:47:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:47:08 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:47:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:47:08 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:47:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:47:16 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:47:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:47:16 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:47:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:47:16 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:47:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:47:16 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:47:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:47:16 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:47:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:47:16 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:47:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:47:16 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:47:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:47:16 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:47:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-20 23:47:16 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:47:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-20 23:47:16 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:47:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-20 23:47:16 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:47:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-20 23:47:16 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:47:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-20 23:47:16 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:47:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-20 23:47:16 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:47:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-20 23:49:51 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-20 23:50:15 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-20 23:50:15 --> Severity: Notice --> Undefined property: stdClass::$post_id C:\xampp\htdocs\application\views\admin\posts.php 77
ERROR - 2020-07-20 23:50:15 --> Severity: Notice --> Undefined property: stdClass::$content C:\xampp\htdocs\application\views\admin\posts.php 85
ERROR - 2020-07-20 23:50:15 --> Severity: Notice --> Undefined property: stdClass::$post_id C:\xampp\htdocs\application\views\admin\posts.php 77
ERROR - 2020-07-20 23:50:15 --> Severity: Notice --> Undefined property: stdClass::$content C:\xampp\htdocs\application\views\admin\posts.php 85
ERROR - 2020-07-20 23:50:15 --> Severity: Notice --> Undefined property: stdClass::$post_id C:\xampp\htdocs\application\views\admin\posts.php 77
ERROR - 2020-07-20 23:50:15 --> Severity: Notice --> Undefined property: stdClass::$content C:\xampp\htdocs\application\views\admin\posts.php 85
ERROR - 2020-07-20 23:50:15 --> Severity: Notice --> Undefined property: stdClass::$post_id C:\xampp\htdocs\application\views\admin\posts.php 77
ERROR - 2020-07-20 23:50:15 --> Severity: Notice --> Undefined property: stdClass::$content C:\xampp\htdocs\application\views\admin\posts.php 85
ERROR - 2020-07-20 23:50:15 --> Severity: Notice --> Undefined property: stdClass::$post_id C:\xampp\htdocs\application\views\admin\posts.php 77
ERROR - 2020-07-20 23:50:15 --> Severity: Notice --> Undefined property: stdClass::$content C:\xampp\htdocs\application\views\admin\posts.php 85
ERROR - 2020-07-20 23:50:15 --> Severity: Notice --> Undefined property: stdClass::$post_id C:\xampp\htdocs\application\views\admin\posts.php 77
ERROR - 2020-07-20 23:50:15 --> Severity: Notice --> Undefined property: stdClass::$content C:\xampp\htdocs\application\views\admin\posts.php 85
ERROR - 2020-07-20 23:50:15 --> Severity: Notice --> Undefined property: stdClass::$post_id C:\xampp\htdocs\application\views\admin\posts.php 77
ERROR - 2020-07-20 23:50:15 --> Severity: Notice --> Undefined property: stdClass::$content C:\xampp\htdocs\application\views\admin\posts.php 85
ERROR - 2020-07-20 23:50:15 --> Severity: Notice --> Undefined property: stdClass::$post_id C:\xampp\htdocs\application\views\admin\posts.php 77
ERROR - 2020-07-20 23:50:15 --> Severity: Notice --> Undefined property: stdClass::$content C:\xampp\htdocs\application\views\admin\posts.php 85
ERROR - 2020-07-20 23:50:15 --> Severity: Notice --> Undefined property: stdClass::$post_id C:\xampp\htdocs\application\views\admin\posts.php 77
ERROR - 2020-07-20 23:50:15 --> Severity: Notice --> Undefined property: stdClass::$content C:\xampp\htdocs\application\views\admin\posts.php 85
ERROR - 2020-07-20 23:50:15 --> Severity: Notice --> Undefined property: stdClass::$post_id C:\xampp\htdocs\application\views\admin\posts.php 77
ERROR - 2020-07-20 23:50:15 --> Severity: Notice --> Undefined property: stdClass::$content C:\xampp\htdocs\application\views\admin\posts.php 85
ERROR - 2020-07-20 23:50:15 --> Severity: Notice --> Undefined property: stdClass::$post_id C:\xampp\htdocs\application\views\admin\posts.php 77
ERROR - 2020-07-20 23:50:15 --> Severity: Notice --> Undefined property: stdClass::$content C:\xampp\htdocs\application\views\admin\posts.php 85
ERROR - 2020-07-20 23:50:15 --> Severity: Notice --> Undefined property: stdClass::$post_id C:\xampp\htdocs\application\views\admin\posts.php 77
ERROR - 2020-07-20 23:50:15 --> Severity: Notice --> Undefined property: stdClass::$content C:\xampp\htdocs\application\views\admin\posts.php 85
ERROR - 2020-07-20 23:52:23 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-20 23:52:23 --> Severity: Notice --> Undefined variable: posts C:\xampp\htdocs\application\views\admin\posts.php 68
ERROR - 2020-07-20 23:52:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\posts.php 68
