<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-03 07:45:22 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-01-03 07:45:23 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-01-03 17:25:50 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-01-03 17:25:50 --> 404 Page Not Found: Adstxt/index
