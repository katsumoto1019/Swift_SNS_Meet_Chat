<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-28 03:49:50 --> 404 Page Not Found: Apple_touch_icon_120x120_precomposedpng/index
ERROR - 2020-12-28 03:49:50 --> 404 Page Not Found: Apple_touch_icon_120x120png/index
ERROR - 2020-12-28 03:49:51 --> 404 Page Not Found: Apple_touch_iconpng/index
ERROR - 2020-12-28 03:49:51 --> 404 Page Not Found: Apple_touch_iconpng/index
ERROR - 2020-12-28 07:49:24 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-12-28 07:49:26 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-12-28 13:10:03 --> 404 Page Not Found: Wordpress/wp_admin
ERROR - 2020-12-28 16:30:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-28 17:29:11 --> 404 Page Not Found: Wp_loginphp/index
