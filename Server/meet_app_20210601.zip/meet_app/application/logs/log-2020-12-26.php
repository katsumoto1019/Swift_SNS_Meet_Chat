<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-26 00:08:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-26 07:51:29 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-12-26 07:51:30 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-12-26 08:44:22 --> 404 Page Not Found: Wp_loginphp/index
