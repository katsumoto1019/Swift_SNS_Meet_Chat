<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-29 06:38:34 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-03-29 06:38:35 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-03-29 06:58:41 --> 404 Page Not Found: Public/admin
ERROR - 2021-03-29 06:58:41 --> 404 Page Not Found: Admin/assets
ERROR - 2021-03-29 18:05:44 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-03-29 18:12:01 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-03-29 20:33:12 --> 404 Page Not Found: Plugins/jquery_file_upload
ERROR - 2021-03-29 21:10:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-03-29 22:00:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-03-29 22:05:08 --> 404 Page Not Found: Wp_admin/install.php
