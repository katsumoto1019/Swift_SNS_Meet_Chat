<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-23 02:50:03 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-11-23 07:29:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-23 07:43:01 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-11-23 07:43:02 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-11-23 08:26:50 --> 404 Page Not Found: Robotstxt/index
