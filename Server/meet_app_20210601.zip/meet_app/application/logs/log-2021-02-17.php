<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-17 05:38:18 --> 404 Page Not Found: Env/index
ERROR - 2021-02-17 07:44:52 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-02-17 07:44:52 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-02-17 10:11:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-02-17 22:30:04 --> 404 Page Not Found: Env/index
