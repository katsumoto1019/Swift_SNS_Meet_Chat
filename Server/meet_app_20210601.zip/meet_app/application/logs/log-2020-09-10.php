<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-10 01:09:29 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-09-10 08:13:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-09-10 16:36:46 --> 404 Page Not Found: Robotstxt/index
