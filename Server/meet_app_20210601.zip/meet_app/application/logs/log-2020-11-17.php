<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-17 10:24:45 --> Query error: Column 'user_id' cannot be null - Invalid query: INSERT INTO `tb_user1` (`user_id`, `token`, `joined_date`, `is_plus_member`) VALUES (NULL, NULL, NULL, NULL)
ERROR - 2020-11-17 07:44:42 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-11-17 07:44:43 --> 404 Page Not Found: 404javascriptjs/index
