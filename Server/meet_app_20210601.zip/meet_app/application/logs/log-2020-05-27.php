<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-27 05:52:03 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-05-27 05:52:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-05-27 06:52:06 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-05-27 07:24:21 --> Severity: Notice --> Undefined variable: last_name C:\xampp\htdocs\application\controllers\Api.php 176
ERROR - 2020-05-27 07:24:21 --> Query error: Column 'last_name' cannot be null - Invalid query: INSERT INTO `tb_user` (`fb_id`, `google_id`, `first_name`, `last_name`, `username`, `email`, `dob`, `type`, `token`, `picture`, `profile_complete`, `approve`, `state`, `rating`, created_at) VALUES ('', '116538361265230495605', 'PK', NULL, 'PK Jinling', 'atopfreelancer@gmail.com', 'Jul/19/1990', 'buyer', 'f2MdFDMoSy6OaTnFqYuY62:APA91bFnOVADSXUH26DZ1bnxMALaZQxOCXgiLjg3yqnQKYGPXjfO86g7J0UnRmT766p268PwFkKuobx1z1QFNrFq71qLtq07Fr56FZ2rlJURIavo-jenH2jKxE86I9LQOQ-AMQPxrzbT', 'https://lh3.googleusercontent.com/a-/AOh14GjsgyyfKPOkoyl50lV3xanmnSEqASvpAZFwVXGwPQ', '0', '0', 'online', '0', NOW())
ERROR - 2020-05-27 08:33:34 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ',' or ')' C:\xampp\htdocs\application\controllers\Api.php 252
ERROR - 2020-05-27 08:35:14 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ',' or ')' C:\xampp\htdocs\application\controllers\Api.php 251
ERROR - 2020-05-27 08:36:48 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ',' or ')' C:\xampp\htdocs\application\controllers\Api.php 251
ERROR - 2020-05-27 07:49:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Api.php 261
ERROR - 2020-05-27 07:49:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Api.php 261
ERROR - 2020-05-27 07:49:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Api.php 261
ERROR - 2020-05-27 07:49:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Api.php 261
ERROR - 2020-05-27 07:50:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Api.php 261
ERROR - 2020-05-27 07:50:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Api.php 261
ERROR - 2020-05-27 07:50:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Api.php 261
ERROR - 2020-05-27 07:51:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Api.php 261
ERROR - 2020-05-27 07:51:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Api.php 261
ERROR - 2020-05-27 08:12:38 --> Severity: Notice --> Undefined variable: row2 C:\xampp\htdocs\application\controllers\Api.php 696
ERROR - 2020-05-27 08:12:38 --> Severity: Notice --> Undefined variable: user_name C:\xampp\htdocs\application\controllers\Api.php 731
ERROR - 2020-05-27 08:12:38 --> Severity: Notice --> Undefined variable: row2 C:\xampp\htdocs\application\controllers\Api.php 696
ERROR - 2020-05-27 08:12:38 --> Severity: Notice --> Undefined variable: user_name C:\xampp\htdocs\application\controllers\Api.php 731
ERROR - 2020-05-27 09:51:52 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\application\controllers\Api.php 743
ERROR - 2020-05-27 09:52:23 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\application\controllers\Api.php 743
ERROR - 2020-05-27 09:52:36 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\application\controllers\Api.php 743
ERROR - 2020-05-27 08:57:49 --> Severity: Notice --> Undefined variable: user_name C:\xampp\htdocs\application\controllers\Api.php 731
ERROR - 2020-05-27 08:57:49 --> Severity: Notice --> Undefined variable: availabletimeArr C:\xampp\htdocs\application\controllers\Api.php 735
ERROR - 2020-05-27 08:57:49 --> Severity: Notice --> Undefined variable: serviceArr C:\xampp\htdocs\application\controllers\Api.php 736
ERROR - 2020-05-27 08:57:49 --> Severity: Notice --> Undefined variable: user_name C:\xampp\htdocs\application\controllers\Api.php 731
ERROR - 2020-05-27 08:57:49 --> Severity: Notice --> Undefined variable: availabletimeArr C:\xampp\htdocs\application\controllers\Api.php 735
ERROR - 2020-05-27 08:57:49 --> Severity: Notice --> Undefined variable: serviceArr C:\xampp\htdocs\application\controllers\Api.php 736
ERROR - 2020-05-27 08:58:27 --> Severity: Notice --> Undefined variable: availabletimeArr C:\xampp\htdocs\application\controllers\Api.php 735
ERROR - 2020-05-27 08:58:27 --> Severity: Notice --> Undefined variable: serviceArr C:\xampp\htdocs\application\controllers\Api.php 736
ERROR - 2020-05-27 08:58:27 --> Severity: Notice --> Undefined variable: availabletimeArr C:\xampp\htdocs\application\controllers\Api.php 735
ERROR - 2020-05-27 08:58:27 --> Severity: Notice --> Undefined variable: serviceArr C:\xampp\htdocs\application\controllers\Api.php 736
ERROR - 2020-05-27 08:59:43 --> Severity: Notice --> Undefined variable: row2 C:\xampp\htdocs\application\controllers\Api.php 696
ERROR - 2020-05-27 08:59:43 --> Severity: Notice --> Undefined variable: row2 C:\xampp\htdocs\application\controllers\Api.php 696
ERROR - 2020-05-27 10:34:20 --> 404 Page Not Found: Api/submitFCM
ERROR - 2020-05-27 10:34:33 --> 404 Page Not Found: Api/submitFCM
ERROR - 2020-05-27 10:35:02 --> 404 Page Not Found: Api/mkContact
ERROR - 2020-05-27 15:12:17 --> Severity: Notice --> Undefined variable: web C:\xampp\htdocs\application\controllers\Api.php 487
ERROR - 2020-05-27 15:12:17 --> Query error: Unknown column 'wed' in 'field list' - Invalid query: INSERT INTO `tb_availabletime` (`user_id`, `mon`, `tue`, `wed`, `thr`, `fri`, `sat`, `sun`) VALUES ('3', '1590480000000 ~ 1590516000000', '1590480000000 ~ 1590516000000', NULL, '1590480000000 ~ 1590516000000', '1590480000000 ~ 1590516000000', '1590480000000 ~ 1590516000000', '1590480000000 ~ 1590516000000')
ERROR - 2020-05-27 15:18:32 --> Severity: Notice --> Undefined variable: web C:\xampp\htdocs\application\controllers\Api.php 487
ERROR - 2020-05-27 15:18:32 --> Query error: Unknown column 'wed' in 'field list' - Invalid query: INSERT INTO `tb_availabletime` (`user_id`, `mon`, `tue`, `wed`, `thr`, `fri`, `sat`, `sun`) VALUES ('3', '1590480000000 ~ 1590516000000', '1590480000000 ~ 1590516000000', NULL, '1590480000000 ~ 1590516000000', '1590480000000 ~ 1590516000000', '1590480000000 ~ 1590516000000', '1590480000000 ~ 1590516000000')
ERROR - 2020-05-27 15:31:01 --> Severity: Notice --> Undefined variable: web C:\xampp\htdocs\application\controllers\Api.php 487
ERROR - 2020-05-27 15:31:01 --> Query error: Unknown column 'wed' in 'field list' - Invalid query: INSERT INTO `tb_availabletime` (`user_id`, `mon`, `tue`, `wed`, `thr`, `fri`, `sat`, `sun`) VALUES ('3', '1590480000000 ~ 1590516000000', '1590480000000 ~ 1590516000000', NULL, '1590480000000 ~ 1590516000000', '1590480000000 ~ 1590516000000', '1590480000000 ~ 1590516000000', '1590480000000 ~ 1590516000000')
ERROR - 2020-05-27 15:31:07 --> Severity: Notice --> Undefined variable: web C:\xampp\htdocs\application\controllers\Api.php 487
ERROR - 2020-05-27 15:31:07 --> Query error: Unknown column 'wed' in 'field list' - Invalid query: INSERT INTO `tb_availabletime` (`user_id`, `mon`, `tue`, `wed`, `thr`, `fri`, `sat`, `sun`) VALUES ('3', '1590480000000 ~ 1590516000000', '1590480000000 ~ 1590516000000', NULL, '1590480000000 ~ 1590516000000', '1590480000000 ~ 1590516000000', '1590480000000 ~ 1590516000000', '1590480000000 ~ 1590516000000')
ERROR - 2020-05-27 16:02:16 --> Severity: Notice --> Undefined variable: web C:\xampp\htdocs\application\controllers\Api.php 487
ERROR - 2020-05-27 16:02:16 --> Query error: Unknown column 'wed' in 'field list' - Invalid query: INSERT INTO `tb_availabletime` (`user_id`, `mon`, `tue`, `wed`, `thr`, `fri`, `sat`, `sun`) VALUES ('3', '1590566400000 ~ 1590602400000', '1590566400000 ~ 1590602400000', NULL, '1590566400000 ~ 1590602400000', '1590566400000 ~ 1590602400000', 'Closed', 'Closed')
ERROR - 2020-05-27 16:04:42 --> Severity: Notice --> Undefined variable: web C:\xampp\htdocs\application\controllers\Api.php 487
ERROR - 2020-05-27 16:04:42 --> Query error: Unknown column 'wed' in 'field list' - Invalid query: INSERT INTO `tb_availabletime` (`user_id`, `mon`, `tue`, `wed`, `thr`, `fri`, `sat`, `sun`) VALUES ('3', '1590566400000 ~ 1590595200000', '1590566400000 ~ 1590602400000', NULL, '1590566400000 ~ 1590602400000', '1590566400000 ~ 1590602400000', 'Closed', 'Closed')
ERROR - 2020-05-27 16:05:57 --> Severity: Notice --> Undefined variable: web C:\xampp\htdocs\application\controllers\Api.php 487
ERROR - 2020-05-27 16:05:57 --> Query error: Unknown column 'wed' in 'field list' - Invalid query: INSERT INTO `tb_availabletime` (`user_id`, `mon`, `tue`, `wed`, `thr`, `fri`, `sat`, `sun`) VALUES ('3', '1590566400000 ~ 1590595200000', '1590566400000 ~ 1590602400000', NULL, '1590566400000 ~ 1590602400000', '1590566400000 ~ 1590602400000', 'Closed', 'Closed')
ERROR - 2020-05-27 16:11:34 --> Severity: Notice --> Undefined variable: web C:\xampp\htdocs\application\controllers\Api.php 487
ERROR - 2020-05-27 16:11:34 --> Query error: Unknown column 'wed' in 'field list' - Invalid query: INSERT INTO `tb_availabletime` (`user_id`, `mon`, `tue`, `wed`, `thr`, `fri`, `sat`, `sun`) VALUES ('3', '1590566400000 ~ 1590595200000', '1590566400000 ~ 1590602400000', NULL, '1590566400000 ~ 1590602400000', '1590566400000 ~ 1590602400000', 'Closed', 'Closed')
ERROR - 2020-05-27 16:11:39 --> Severity: Notice --> Undefined variable: web C:\xampp\htdocs\application\controllers\Api.php 487
ERROR - 2020-05-27 16:11:39 --> Query error: Unknown column 'wed' in 'field list' - Invalid query: INSERT INTO `tb_availabletime` (`user_id`, `mon`, `tue`, `wed`, `thr`, `fri`, `sat`, `sun`) VALUES ('3', '1590566400000 ~ 1590595200000', '1590566400000 ~ 1590602400000', NULL, '1590566400000 ~ 1590602400000', '1590566400000 ~ 1590602400000', 'Closed', 'Closed')
ERROR - 2020-05-27 16:11:44 --> Severity: Notice --> Undefined variable: web C:\xampp\htdocs\application\controllers\Api.php 487
ERROR - 2020-05-27 16:11:44 --> Query error: Unknown column 'wed' in 'field list' - Invalid query: INSERT INTO `tb_availabletime` (`user_id`, `mon`, `tue`, `wed`, `thr`, `fri`, `sat`, `sun`) VALUES ('3', '1590566400000 ~ 1590595200000', '1590566400000 ~ 1590602400000', NULL, '1590566400000 ~ 1590602400000', '1590566400000 ~ 1590602400000', 'Closed', 'Closed')
ERROR - 2020-05-27 16:13:43 --> Severity: Notice --> Undefined variable: web C:\xampp\htdocs\application\controllers\Api.php 487
ERROR - 2020-05-27 16:13:43 --> Query error: Column 'wed' cannot be null - Invalid query: INSERT INTO `tb_availabletime` (`user_id`, `mon`, `tue`, `wed`, `thr`, `fri`, `sat`, `sun`) VALUES ('3', '1590566400000 ~ 1590595200000', '1590566400000 ~ 1590602400000', NULL, '1590566400000 ~ 1590602400000', '1590566400000 ~ 1590602400000', 'Closed', 'Closed')
ERROR - 2020-05-27 16:14:30 --> Severity: Notice --> Undefined variable: web C:\xampp\htdocs\application\controllers\Api.php 487
ERROR - 2020-05-27 16:14:30 --> Query error: Column 'wed' cannot be null - Invalid query: INSERT INTO `tb_availabletime` (`user_id`, `mon`, `tue`, `wed`, `thr`, `fri`, `sat`, `sun`) VALUES ('3', '1590566400000 ~ 1590595200000', '1590566400000 ~ 1590602400000', NULL, '1590566400000 ~ 1590602400000', '1590566400000 ~ 1590602400000', 'Closed', 'Closed')
ERROR - 2020-05-27 16:23:47 --> Query error: Unknown column 'user_id' in 'where clause' - Invalid query: SELECT *
FROM `tb_user`
WHERE `user_id` = '3'
ERROR - 2020-05-27 16:24:45 --> Query error: Unknown column 'user_id' in 'where clause' - Invalid query: SELECT *
FROM `tb_user`
WHERE `user_id` = '3'
ERROR - 2020-05-27 16:26:00 --> Query error: Unknown column 'user_id' in 'where clause' - Invalid query: SELECT *
FROM `tb_user`
WHERE `user_id` = '3'
ERROR - 2020-05-27 16:31:05 --> Query error: Unknown column 'user_id' in 'where clause' - Invalid query: SELECT *
FROM `tb_user`
WHERE `user_id` = '3'
ERROR - 2020-05-27 16:38:10 --> Query error: Unknown column 'user_id' in 'where clause' - Invalid query: SELECT *
FROM `tb_user`
WHERE `user_id` = '3'
ERROR - 2020-05-27 17:16:44 --> Query error: Unknown column 'user_id' in 'where clause' - Invalid query: SELECT *
FROM `tb_user`
WHERE `user_id` = '3'
ERROR - 2020-05-27 17:19:31 --> Query error: Unknown column 'user_id' in 'where clause' - Invalid query: SELECT *
FROM `tb_user`
WHERE `user_id` = '3'
ERROR - 2020-05-27 17:21:09 --> Query error: Unknown column 'user_id' in 'where clause' - Invalid query: SELECT *
FROM `tb_user`
WHERE `user_id` = '3'
ERROR - 2020-05-27 18:03:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Api.php 640
ERROR - 2020-05-27 18:03:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Api.php 641
ERROR - 2020-05-27 20:34:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Api.php 640
ERROR - 2020-05-27 20:34:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Api.php 641
