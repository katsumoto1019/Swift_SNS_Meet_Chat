<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-28 01:56:32 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-01-28 01:56:32 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-01-28 02:47:44 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-01-28 07:51:55 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-01-28 07:51:57 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-01-28 20:57:54 --> 404 Page Not Found: Wp_includes/wlwmanifest.xml
ERROR - 2021-01-28 20:57:54 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2021-01-28 20:57:54 --> 404 Page Not Found: Blog/wp_includes
ERROR - 2021-01-28 20:57:54 --> 404 Page Not Found: Web/wp_includes
ERROR - 2021-01-28 20:57:54 --> 404 Page Not Found: Wordpress/wp_includes
ERROR - 2021-01-28 20:57:54 --> 404 Page Not Found: Website/wp_includes
ERROR - 2021-01-28 20:57:54 --> 404 Page Not Found: Wp/wp_includes
ERROR - 2021-01-28 20:57:54 --> 404 Page Not Found: News/wp_includes
ERROR - 2021-01-28 20:57:54 --> 404 Page Not Found: 2018/wp_includes
ERROR - 2021-01-28 20:57:54 --> 404 Page Not Found: 2019/wp_includes
ERROR - 2021-01-28 20:57:55 --> 404 Page Not Found: Shop/wp_includes
ERROR - 2021-01-28 20:57:55 --> 404 Page Not Found: Wp1/wp_includes
ERROR - 2021-01-28 20:57:55 --> 404 Page Not Found: Test/wp_includes
ERROR - 2021-01-28 20:57:55 --> 404 Page Not Found: Media/wp_includes
ERROR - 2021-01-28 20:57:55 --> 404 Page Not Found: Wp2/wp_includes
ERROR - 2021-01-28 20:57:55 --> 404 Page Not Found: Site/wp_includes
ERROR - 2021-01-28 20:57:55 --> 404 Page Not Found: Cms/wp_includes
ERROR - 2021-01-28 20:57:55 --> 404 Page Not Found: Sito/wp_includes
