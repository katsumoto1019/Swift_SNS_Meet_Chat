<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-29 09:51:57 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 12:08:37 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 12:08:43 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 12:41:11 --> Severity: Compile Error --> Cannot redeclare Admin::add_workoutvideo() C:\xampp\htdocs\application\controllers\Admin.php 945
ERROR - 2020-03-29 12:42:39 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 11:42:55 --> Query error: Unknown column 'category_id' in 'where clause' - Invalid query: SELECT *
FROM `tb_programs`
WHERE `category_id` = '3'
ERROR - 2020-03-29 11:45:26 --> Severity: Notice --> Undefined variable: workoutvideos C:\xampp\htdocs\application\views\video\programs.php 69
ERROR - 2020-03-29 11:45:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\video\programs.php 69
ERROR - 2020-03-29 12:45:27 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 12:45:39 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 11:45:45 --> Severity: Notice --> Undefined variable: workoutvideos C:\xampp\htdocs\application\views\video\programs.php 69
ERROR - 2020-03-29 11:45:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\video\programs.php 69
ERROR - 2020-03-29 12:45:46 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 13:02:34 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 13:02:39 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 13:02:51 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 13:02:53 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 13:05:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 13:06:26 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 13:06:33 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 13:06:40 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 12:31:53 --> Severity: error --> Exception: Too few arguments to function Admin::programs(), 0 passed in C:\xampp\htdocs\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\application\controllers\Admin.php 943
ERROR - 2020-03-29 13:34:25 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 12:34:27 --> Severity: error --> Exception: Too few arguments to function Admin::programs(), 0 passed in C:\xampp\htdocs\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\application\controllers\Admin.php 943
ERROR - 2020-03-29 12:34:33 --> Severity: error --> Exception: Too few arguments to function Admin::programs(), 0 passed in C:\xampp\htdocs\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\application\controllers\Admin.php 943
ERROR - 2020-03-29 13:34:36 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 13:34:40 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 13:34:43 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 13:34:46 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 13:34:49 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 13:34:51 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 13:34:52 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 13:34:55 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 13:34:57 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 13:35:57 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 13:35:57 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 13:35:58 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 13:35:59 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 13:36:01 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 13:36:08 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 13:40:30 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 12:40:34 --> Severity: error --> Exception: Too few arguments to function Admin::programs(), 0 passed in C:\xampp\htdocs\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\application\controllers\Admin.php 943
ERROR - 2020-03-29 13:40:48 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 13:43:17 --> Severity: Compile Error --> Cannot redeclare Admin::delete_vnc() C:\xampp\htdocs\application\controllers\Admin.php 936
ERROR - 2020-03-29 13:43:19 --> Severity: Compile Error --> Cannot redeclare Admin::delete_vnc() C:\xampp\htdocs\application\controllers\Admin.php 936
ERROR - 2020-03-29 13:43:50 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 13:43:56 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 16:02:35 --> Severity: error --> Exception: Too few arguments to function Admin::edit_programvideo(), 1 passed in C:\xampp\htdocs\system\core\CodeIgniter.php on line 514 and exactly 2 expected C:\xampp\htdocs\application\controllers\Admin.php 1025
ERROR - 2020-03-29 17:02:42 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:02:43 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:02:45 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 16:02:49 --> Severity: Notice --> Undefined property: stdClass::$price C:\xampp\htdocs\application\views\video\edit_workoutvideo.php 38
ERROR - 2020-03-29 16:02:49 --> Severity: Notice --> Undefined property: stdClass::$period C:\xampp\htdocs\application\views\video\edit_workoutvideo.php 42
ERROR - 2020-03-29 17:02:49 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:05:06 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:05:08 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:05:18 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:05:20 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:05:24 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:05:25 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:05:27 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:05:31 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:05:38 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:05:52 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:05:57 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:06:18 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:06:36 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:10:03 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:10:06 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:10:10 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:11:10 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:11:12 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:11:22 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:11:26 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:11:32 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:11:35 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:11:45 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:11:47 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:12:02 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:13:05 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:13:17 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:13:20 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 16:18:33 --> Severity: error --> Exception: Too few arguments to function Admin::add_programvideo(), 0 passed in C:\xampp\htdocs\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\application\controllers\Admin.php 964
ERROR - 2020-03-29 17:18:36 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:18:39 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:19:23 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:19:26 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:20:00 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:20:04 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:20:19 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:20:26 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:20:41 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:20:46 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:20:51 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:20:52 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:20:58 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:21:00 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:21:03 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:21:13 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:31:37 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:31:40 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:31:43 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:31:46 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:31:48 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 17:31:52 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 18:56:42 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 18:01:04 --> Severity: Notice --> Undefined index: categories C:\xampp\htdocs\application\controllers\Api.php 86
ERROR - 2020-03-29 18:01:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\controllers\Api.php 86
ERROR - 2020-03-29 19:31:05 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 19:37:09 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-29 19:38:45 --> 404 Page Not Found: Manifestjson/index
