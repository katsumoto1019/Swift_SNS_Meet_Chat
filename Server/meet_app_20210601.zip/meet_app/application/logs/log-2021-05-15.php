<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-15 00:02:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-15 00:02:06 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-05-15 00:02:07 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-05-15 06:30:01 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-05-15 06:30:02 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-05-15 18:12:15 --> 404 Page Not Found: Robotstxt/index
