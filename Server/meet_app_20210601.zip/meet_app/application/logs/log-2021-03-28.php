<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-28 02:00:08 --> 404 Page Not Found: Wp_includes/css
ERROR - 2021-03-28 02:00:24 --> 404 Page Not Found: Wp_includes/fonts
ERROR - 2021-03-28 06:25:40 --> 404 Page Not Found: Admin/assets
ERROR - 2021-03-28 06:46:43 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-03-28 06:46:44 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-03-28 18:31:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-03-28 19:06:49 --> 404 Page Not Found: Admin/assets
