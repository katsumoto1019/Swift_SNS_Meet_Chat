<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-07 02:29:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-04-07 04:28:58 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-04-07 06:16:28 --> 404 Page Not Found: Assets/backend
ERROR - 2021-04-07 06:33:53 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-04-07 06:33:54 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-04-07 07:13:27 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-04-07 14:31:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-04-07 17:39:03 --> 404 Page Not Found: Env/index
ERROR - 2021-04-07 17:39:04 --> 404 Page Not Found: Env/index
ERROR - 2021-04-07 22:47:21 --> 404 Page Not Found: Robotstxt/index
