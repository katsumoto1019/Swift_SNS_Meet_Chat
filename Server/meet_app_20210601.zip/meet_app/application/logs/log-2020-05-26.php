<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-26 03:54:35 --> 404 Page Not Found: Uploadfiles/category
ERROR - 2020-05-26 03:54:38 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-05-26 03:54:42 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-05-26 03:54:44 --> 404 Page Not Found: Uploadfiles/userphoto
ERROR - 2020-05-26 03:54:44 --> 404 Page Not Found: Uploadfiles/userphoto
ERROR - 2020-05-26 03:54:44 --> 404 Page Not Found: Uploadfiles/userphoto
ERROR - 2020-05-26 03:54:44 --> 404 Page Not Found: Uploadfiles/userphoto
ERROR - 2020-05-26 03:54:44 --> 404 Page Not Found: Uploadfiles/userphoto
ERROR - 2020-05-26 03:54:44 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-05-26 03:54:53 --> 404 Page Not Found: Uploadfiles/userphoto
ERROR - 2020-05-26 03:54:53 --> 404 Page Not Found: Uploadfiles/userphoto
ERROR - 2020-05-26 03:54:53 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-05-26 03:55:58 --> 404 Page Not Found: Uploadfiles/userphoto
ERROR - 2020-05-26 03:55:58 --> 404 Page Not Found: Uploadfiles/userphoto
ERROR - 2020-05-26 03:55:58 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-05-26 12:11:46 --> Query error: Unknown column 'online' in 'field list' - Invalid query: INSERT INTO `tb_user` (`fb_id`, `google_id`, `first_name`, `last_name`, `username`, `email`, `dob`, `type`, `token`, `picture`, `profile_complete`, `approve`, `online`, `rating`, created_at) VALUES ('267902841235761', '', 'Ling', 'Li', 'Ling Li', 'saville1986713@gmail.com', '', 'buyer', 'dYoQr8JOT8WEIy1km2FYrr:APA91bG3d_rEVJonoOq6nslAL6X3s5JfuhrmwDq9KpemStjrmn-hiHzldDg5zlQgag8AsFMVtKustxo-mLp3LWdzS4alnLbkdpnau0TFgLo-B1M1wRuAcyj2ltK5732o-60jltfQ3oit', 'http%3A%2F%2Fgraph.facebook.com%2F%28Id%29%2Fpicture%3Ftype%3Dlarge', '0', '0', 'online', '0', NOW())
ERROR - 2020-05-26 12:25:52 --> Query error: Unknown column 'online' in 'field list' - Invalid query: INSERT INTO `tb_user` (`fb_id`, `google_id`, `first_name`, `last_name`, `username`, `email`, `dob`, `type`, `token`, `picture`, `profile_complete`, `approve`, `online`, `rating`, created_at) VALUES ('267902841235761', '', 'Ling', 'Li', 'Ling Li', 'saville1986713@gmail.com', '', 'buyer', 'dYoQr8JOT8WEIy1km2FYrr:APA91bG3d_rEVJonoOq6nslAL6X3s5JfuhrmwDq9KpemStjrmn-hiHzldDg5zlQgag8AsFMVtKustxo-mLp3LWdzS4alnLbkdpnau0TFgLo-B1M1wRuAcyj2ltK5732o-60jltfQ3oit', 'http%3A%2F%2Fgraph.facebook.com%2F%28Id%29%2Fpicture%3Ftype%3Dlarge', '0', '0', 'online', '0', NOW())
ERROR - 2020-05-26 13:41:15 --> Query error: Unknown column 'online' in 'field list' - Invalid query: INSERT INTO `tb_user` (`fb_id`, `google_id`, `first_name`, `last_name`, `username`, `email`, `dob`, `type`, `token`, `picture`, `profile_complete`, `approve`, `online`, `rating`, created_at) VALUES ('267902841235761', '', 'Ling', 'Li', 'Ling Li', 'saville1986713@gmail.com', '', 'buyer', 'dYoQr8JOT8WEIy1km2FYrr:APA91bG3d_rEVJonoOq6nslAL6X3s5JfuhrmwDq9KpemStjrmn-hiHzldDg5zlQgag8AsFMVtKustxo-mLp3LWdzS4alnLbkdpnau0TFgLo-B1M1wRuAcyj2ltK5732o-60jltfQ3oit', 'http%3A%2F%2Fgraph.facebook.com%2F%28Id%29%2Fpicture%3Ftype%3Dlarge', '0', '0', 'online', '0', NOW())
ERROR - 2020-05-26 13:46:43 --> Severity: Notice --> Undefined index: first_name C:\xampp\htdocs\application\controllers\Api.php 150
ERROR - 2020-05-26 13:46:43 --> Severity: Notice --> Undefined index: last_name C:\xampp\htdocs\application\controllers\Api.php 151
ERROR - 2020-05-26 13:46:43 --> Severity: Notice --> Undefined index: user_name C:\xampp\htdocs\application\controllers\Api.php 152
ERROR - 2020-05-26 13:46:43 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\application\controllers\Api.php 153
ERROR - 2020-05-26 13:46:43 --> Severity: Notice --> Undefined index: dob C:\xampp\htdocs\application\controllers\Api.php 154
ERROR - 2020-05-26 13:46:43 --> Severity: Notice --> Undefined index: picture C:\xampp\htdocs\application\controllers\Api.php 155
ERROR - 2020-05-26 13:46:43 --> Severity: Notice --> Undefined index: fb_id C:\xampp\htdocs\application\controllers\Api.php 156
ERROR - 2020-05-26 13:46:43 --> Severity: Notice --> Undefined index: google_id C:\xampp\htdocs\application\controllers\Api.php 157
ERROR - 2020-05-26 13:46:43 --> Severity: Notice --> Undefined index: device_token C:\xampp\htdocs\application\controllers\Api.php 158
ERROR - 2020-05-26 13:46:43 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\application\controllers\Api.php 159
ERROR - 2020-05-26 13:46:43 --> Query error: Unknown column 'online' in 'field list' - Invalid query: INSERT INTO `tb_user` (`fb_id`, `google_id`, `first_name`, `last_name`, `username`, `email`, `dob`, `type`, `token`, `picture`, `profile_complete`, `approve`, `online`, `rating`, created_at) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', 'online', '0', NOW())
ERROR - 2020-05-26 13:46:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\system\core\Exceptions.php:272) C:\xampp\htdocs\system\core\Common.php 573
ERROR - 2020-05-26 14:25:54 --> Query error: Unknown column 'online' in 'field list' - Invalid query: INSERT INTO `tb_user` (`fb_id`, `google_id`, `first_name`, `last_name`, `username`, `email`, `dob`, `type`, `token`, `picture`, `profile_complete`, `approve`, `online`, `rating`, created_at) VALUES ('267902841235761', '', 'Ling', 'Li', 'Ling Li', 'saville1986713@gmail.com', '', 'buyer', 'dYoQr8JOT8WEIy1km2FYrr:APA91bG3d_rEVJonoOq6nslAL6X3s5JfuhrmwDq9KpemStjrmn-hiHzldDg5zlQgag8AsFMVtKustxo-mLp3LWdzS4alnLbkdpnau0TFgLo-B1M1wRuAcyj2ltK5732o-60jltfQ3oit', 'http%3A%2F%2Fgraph.facebook.com%2F%28Id%29%2Fpicture%3Ftype%3Dlarge', '0', '0', 'online', '0', NOW())
ERROR - 2020-05-26 15:55:29 --> Query error: Unknown column 'user_id' in 'where clause' - Invalid query: UPDATE `tb_user` SET `google_id` = '106339419369689831830', `picture` = 'https://lh3.googleusercontent.com/a-/AOh14GhX5KXjk4dCpqKQTtY9c7HUALihW7InOxuAfgQw', `token` = 'dYoQr8JOT8WEIy1km2FYrr:APA91bG3d_rEVJonoOq6nslAL6X3s5JfuhrmwDq9KpemStjrmn-hiHzldDg5zlQgag8AsFMVtKustxo-mLp3LWdzS4alnLbkdpnau0TFgLo-B1M1wRuAcyj2ltK5732o-60jltfQ3oit'
WHERE `user_id` = '1'
ERROR - 2020-05-26 16:04:40 --> Query error: Unknown column 'user_id' in 'where clause' - Invalid query: UPDATE `tb_user` SET `google_id` = '106339419369689831830', `picture` = 'https://lh3.googleusercontent.com/a-/AOh14GhX5KXjk4dCpqKQTtY9c7HUALihW7InOxuAfgQw', `token` = 'dYoQr8JOT8WEIy1km2FYrr:APA91bG3d_rEVJonoOq6nslAL6X3s5JfuhrmwDq9KpemStjrmn-hiHzldDg5zlQgag8AsFMVtKustxo-mLp3LWdzS4alnLbkdpnau0TFgLo-B1M1wRuAcyj2ltK5732o-60jltfQ3oit'
WHERE `user_id` = '1'
ERROR - 2020-05-26 17:14:25 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ',' or ')' C:\xampp\htdocs\application\controllers\Api.php 189
ERROR - 2020-05-26 17:18:08 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ',' or ')' C:\xampp\htdocs\application\controllers\Api.php 189
ERROR - 2020-05-26 17:19:34 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ',' or ')' C:\xampp\htdocs\application\controllers\Api.php 192
ERROR - 2020-05-26 17:20:06 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ',' or ')' C:\xampp\htdocs\application\controllers\Api.php 189
ERROR - 2020-05-26 17:21:55 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ',' or ')' C:\xampp\htdocs\application\controllers\Api.php 189
ERROR - 2020-05-26 16:37:32 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-05-26 16:37:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-05-26 17:37:33 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-05-26 17:37:40 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-05-26 17:42:17 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\application\controllers\Api.php 259
ERROR - 2020-05-26 17:43:25 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\application\controllers\Api.php 259
ERROR - 2020-05-26 20:11:48 --> Severity: Notice --> Undefined index: device_token C:\xampp\htdocs\application\controllers\Api.php 93
