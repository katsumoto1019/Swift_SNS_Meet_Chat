<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-01 08:51:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-09-01 10:18:32 --> 404 Page Not Found: Robotstxt/index
