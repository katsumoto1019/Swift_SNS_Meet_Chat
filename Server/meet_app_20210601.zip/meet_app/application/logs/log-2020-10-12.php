<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-12 06:56:15 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-10-12 06:56:16 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-10-12 20:01:41 --> 404 Page Not Found: Robotstxt/index
