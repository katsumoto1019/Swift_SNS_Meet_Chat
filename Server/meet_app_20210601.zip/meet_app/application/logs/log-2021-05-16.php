<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-16 05:36:00 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-05-16 06:36:42 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-05-16 06:36:44 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-05-16 10:49:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-16 14:25:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-16 18:08:06 --> 404 Page Not Found: Theme/assets
ERROR - 2021-05-16 18:22:52 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-05-16 19:59:15 --> 404 Page Not Found: Robotstxt/index
