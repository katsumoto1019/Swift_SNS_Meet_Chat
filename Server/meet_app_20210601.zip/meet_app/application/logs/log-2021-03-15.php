<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-15 06:43:23 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-03-15 06:43:23 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-03-15 17:13:58 --> 404 Page Not Found: Wp_includes/css
ERROR - 2021-03-15 17:14:12 --> 404 Page Not Found: Wp_includes/fonts
ERROR - 2021-03-15 23:08:41 --> 404 Page Not Found: Laravel/.env
ERROR - 2021-03-15 23:09:07 --> 404 Page Not Found: Admin/.env
ERROR - 2021-03-15 23:09:09 --> 404 Page Not Found: Sites/.env
