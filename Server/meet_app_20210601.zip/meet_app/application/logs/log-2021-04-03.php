<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-03 06:32:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-04-03 06:32:28 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2021-04-03 06:32:29 --> 404 Page Not Found: Blog/robots.txt
ERROR - 2021-04-03 06:32:30 --> 404 Page Not Found: Blog/index
ERROR - 2021-04-03 06:32:30 --> 404 Page Not Found: Wordpress/index
ERROR - 2021-04-03 06:32:30 --> 404 Page Not Found: Wp/index
ERROR - 2021-04-03 06:38:02 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-04-03 06:38:03 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-04-03 11:53:12 --> 404 Page Not Found: Theme/assets
ERROR - 2021-04-03 21:26:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-04-03 22:22:27 --> 404 Page Not Found: Wp_loginphp/index
