<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-05 05:17:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-01-05 07:46:58 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-01-05 07:46:59 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-01-05 09:02:11 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-01-05 18:53:31 --> 404 Page Not Found: Wp_loginphp/index
