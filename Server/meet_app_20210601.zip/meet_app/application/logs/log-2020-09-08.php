<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-08 09:57:34 --> 404 Page Not Found: Robotstxt/index
