<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-03 01:15:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-09-03 01:15:35 --> 404 Page Not Found: Humanstxt/index
ERROR - 2020-09-03 01:15:36 --> 404 Page Not Found: Adstxt/index
ERROR - 2020-09-03 17:18:26 --> 404 Page Not Found: Robotstxt/index
