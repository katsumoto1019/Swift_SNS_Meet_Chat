<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-21 06:33:52 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-04-21 06:33:53 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-04-21 07:47:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-04-21 09:16:23 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-04-21 09:16:24 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-04-21 11:01:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-04-21 12:08:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-04-21 14:53:29 --> 404 Page Not Found: Asset/plugins
ERROR - 2021-04-21 20:43:53 --> 404 Page Not Found: Env/index
ERROR - 2021-04-21 21:19:39 --> 404 Page Not Found: Env/index
ERROR - 2021-04-21 21:19:40 --> 404 Page Not Found: Env/index
