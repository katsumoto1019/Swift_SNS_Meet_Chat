<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-16 00:12:01 --> 404 Page Not Found: Robotstxt/index
