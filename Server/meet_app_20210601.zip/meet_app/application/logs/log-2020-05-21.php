<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-21 18:58:21 --> Query error: Table 'learnme.tb_categories' doesn't exist - Invalid query: SELECT *
FROM `tb_categories`
ORDER BY `id` ASC
ERROR - 2020-05-21 18:58:32 --> Query error: Table 'learnme.tb_categories' doesn't exist - Invalid query: SELECT *
FROM `tb_categories`
ORDER BY `id` ASC
ERROR - 2020-05-21 19:58:57 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-05-21 19:03:06 --> Query error: Table 'learnme.tb_categories' doesn't exist - Invalid query: SELECT *
FROM `tb_categories`
ORDER BY `id` ASC
