<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-07 00:56:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-07 07:47:10 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-11-07 07:47:11 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-11-07 12:38:59 --> 404 Page Not Found: Js/mage
ERROR - 2020-11-07 21:00:58 --> 404 Page Not Found: Wp_includes/wlwmanifest.xml
ERROR - 2020-11-07 21:00:58 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2020-11-07 21:00:59 --> 404 Page Not Found: Blog/wp_includes
ERROR - 2020-11-07 21:00:59 --> 404 Page Not Found: Web/wp_includes
ERROR - 2020-11-07 21:00:59 --> 404 Page Not Found: Wordpress/wp_includes
ERROR - 2020-11-07 21:00:59 --> 404 Page Not Found: Website/wp_includes
ERROR - 2020-11-07 21:00:59 --> 404 Page Not Found: Wp/wp_includes
ERROR - 2020-11-07 21:00:59 --> 404 Page Not Found: News/wp_includes
ERROR - 2020-11-07 21:00:59 --> 404 Page Not Found: 2018/wp_includes
ERROR - 2020-11-07 21:00:59 --> 404 Page Not Found: 2019/wp_includes
ERROR - 2020-11-07 21:00:59 --> 404 Page Not Found: Shop/wp_includes
ERROR - 2020-11-07 21:00:59 --> 404 Page Not Found: Wp1/wp_includes
ERROR - 2020-11-07 21:00:59 --> 404 Page Not Found: Test/wp_includes
ERROR - 2020-11-07 21:00:59 --> 404 Page Not Found: Media/wp_includes
ERROR - 2020-11-07 21:00:59 --> 404 Page Not Found: Wp2/wp_includes
ERROR - 2020-11-07 21:00:59 --> 404 Page Not Found: Site/wp_includes
ERROR - 2020-11-07 21:00:59 --> 404 Page Not Found: Cms/wp_includes
ERROR - 2020-11-07 21:00:59 --> 404 Page Not Found: Sito/wp_includes
ERROR - 2020-11-07 21:16:04 --> 404 Page Not Found: Robotstxt/index
