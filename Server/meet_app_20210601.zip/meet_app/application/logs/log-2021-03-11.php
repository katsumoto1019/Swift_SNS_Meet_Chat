<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-11 07:27:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-03-11 07:44:08 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-03-11 07:44:09 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-03-11 16:19:32 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-03-11 16:35:21 --> 404 Page Not Found: Wp_admin/upgrade.php
ERROR - 2021-03-11 22:39:12 --> 404 Page Not Found: Robotstxt/index
