<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-08 07:52:19 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-12-08 07:52:19 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-12-08 20:32:33 --> Query error: Column 'user_id' cannot be null - Invalid query: INSERT INTO `tb_user1` (`user_id`, `token`, `joined_date`, `is_plus_member`) VALUES (NULL, NULL, NULL, NULL)
ERROR - 2020-12-08 21:22:29 --> 404 Page Not Found: Robotstxt/index
