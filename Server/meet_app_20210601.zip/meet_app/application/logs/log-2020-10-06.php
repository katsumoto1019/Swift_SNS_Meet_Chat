<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-06 05:17:38 --> 404 Page Not Found: Wp_admin/setup_config.php
ERROR - 2020-10-06 05:17:39 --> 404 Page Not Found: Wp_admin/install.php
ERROR - 2020-10-06 05:41:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-10-06 07:00:00 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-10-06 07:00:00 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-10-06 07:59:14 --> 404 Page Not Found: Wp/wp_admin
ERROR - 2020-10-06 07:59:16 --> 404 Page Not Found: Wp/wp_admin
ERROR - 2020-10-06 07:59:17 --> 404 Page Not Found: Wordpress/wp_admin
ERROR - 2020-10-06 07:59:18 --> 404 Page Not Found: Wordpress/wp_admin
ERROR - 2020-10-06 07:59:20 --> 404 Page Not Found: Blog/wp_admin
ERROR - 2020-10-06 07:59:21 --> 404 Page Not Found: Blog/wp_admin
ERROR - 2020-10-06 07:59:22 --> 404 Page Not Found: New/wp_admin
ERROR - 2020-10-06 07:59:23 --> 404 Page Not Found: New/wp_admin
ERROR - 2020-10-06 07:59:24 --> 404 Page Not Found: News/wp_admin
ERROR - 2020-10-06 07:59:24 --> 404 Page Not Found: News/wp_admin
ERROR - 2020-10-06 09:42:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-10-06 09:48:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-10-06 09:48:46 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2020-10-06 09:48:48 --> 404 Page Not Found: Adstxt/index
ERROR - 2020-10-06 21:32:13 --> Query error: Unknown column 'email' in 'where clause' - Invalid query: SELECT *
FROM `tb_user`
WHERE `email` = 'iOSTester'
ERROR - 2020-10-06 21:33:37 --> Query error: Column 'follower' cannot be null - Invalid query: INSERT INTO `tb_user` (`username`, `password`, `picture`, `follower`, `notification`, `token`, created_at, `about_me`, `user_location`, `user_birthday`) VALUES ('iOSTester', '$2y$10$la21pq2YbPc.0kMTFX3m8ugZW7DoT2XJMNSy17dIBv3Hqvg5F9KdC', 'http://meets.email/uploadfiles/userphoto/1601987617113.png', NULL, 1, '123afe34gedyt5 bwr5tb54567un35e6w', NOW(), 'hello, world come here', 'Osaka', '2000-10-11')
ERROR - 2020-10-06 12:48:17 --> 404 Page Not Found: Api/edifProfile
ERROR - 2020-10-06 14:18:27 --> 404 Page Not Found: Wp_admin/install.php
ERROR - 2020-10-06 16:28:37 --> 404 Page Not Found: Wp_admin/setup_config.php
ERROR - 2020-10-06 16:28:37 --> 404 Page Not Found: Wp_admin/install.php
ERROR - 2020-10-06 17:59:34 --> 404 Page Not Found: Wp_includes/wlwmanifest.xml
ERROR - 2020-10-06 17:59:34 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2020-10-06 17:59:35 --> 404 Page Not Found: Blog/wp_includes
ERROR - 2020-10-06 17:59:35 --> 404 Page Not Found: Wordpress/wp_includes
ERROR - 2020-10-06 17:59:35 --> 404 Page Not Found: Wp/wp_includes
ERROR - 2020-10-06 17:59:35 --> 404 Page Not Found: Site/wp_includes
ERROR - 2020-10-06 17:59:36 --> 404 Page Not Found: Cms/wp_includes
ERROR - 2020-10-06 21:24:26 --> 404 Page Not Found: Wp_includes/js
ERROR - 2020-10-06 21:24:26 --> 404 Page Not Found: Administrator/help
ERROR - 2020-10-06 21:24:26 --> 404 Page Not Found: Administrator/language
ERROR - 2020-10-06 21:24:26 --> 404 Page Not Found: Plugins/system
ERROR - 2020-10-06 21:24:27 --> 404 Page Not Found: Administrator/index
ERROR - 2020-10-06 21:24:27 --> 404 Page Not Found: Misc/ajax.js
ERROR - 2020-10-06 21:24:28 --> 404 Page Not Found: Admin/view
ERROR - 2020-10-06 21:24:28 --> 404 Page Not Found: Admin/includes
ERROR - 2020-10-06 21:24:28 --> 404 Page Not Found: Images/editor
ERROR - 2020-10-06 21:24:28 --> 404 Page Not Found: Js/header_rollup_554.js
ERROR - 2020-10-06 21:24:28 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-10-06 21:24:29 --> 404 Page Not Found: Fckeditor/editor
ERROR - 2020-10-06 21:24:29 --> 404 Page Not Found: Env/index
ERROR - 2020-10-06 22:23:44 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-10-06 22:47:53 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-10-06 22:47:53 --> 404 Page Not Found: Administrator/index.php
ERROR - 2020-10-06 22:51:24 --> 404 Page Not Found: Wp_includes/js
ERROR - 2020-10-06 22:51:25 --> 404 Page Not Found: Administrator/help
ERROR - 2020-10-06 22:51:25 --> 404 Page Not Found: Administrator/language
ERROR - 2020-10-06 22:51:26 --> 404 Page Not Found: Plugins/system
ERROR - 2020-10-06 22:51:26 --> 404 Page Not Found: Administrator/index
ERROR - 2020-10-06 22:51:27 --> 404 Page Not Found: Misc/ajax.js
ERROR - 2020-10-06 22:51:28 --> 404 Page Not Found: Admin/view
ERROR - 2020-10-06 22:51:28 --> 404 Page Not Found: Admin/includes
ERROR - 2020-10-06 22:51:29 --> 404 Page Not Found: Images/editor
ERROR - 2020-10-06 22:51:29 --> 404 Page Not Found: Js/header_rollup_554.js
ERROR - 2020-10-06 22:51:30 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-10-06 22:51:30 --> 404 Page Not Found: Fckeditor/editor
ERROR - 2020-10-06 22:51:31 --> 404 Page Not Found: Env/index
