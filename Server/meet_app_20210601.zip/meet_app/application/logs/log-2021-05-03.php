<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-03 03:53:02 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-05-03 06:32:30 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-05-03 06:32:31 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-05-03 06:59:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-03 07:46:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-03 13:21:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-03 19:02:56 --> 404 Page Not Found: Dede/login.php
ERROR - 2021-05-03 19:31:36 --> 404 Page Not Found: Wp_includes/wlwmanifest.xml
ERROR - 2021-05-03 19:31:36 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2021-05-03 19:31:37 --> 404 Page Not Found: Blog/wp_includes
ERROR - 2021-05-03 19:31:37 --> 404 Page Not Found: Web/wp_includes
ERROR - 2021-05-03 19:31:37 --> 404 Page Not Found: Wordpress/wp_includes
ERROR - 2021-05-03 19:31:38 --> 404 Page Not Found: Website/wp_includes
ERROR - 2021-05-03 19:31:38 --> 404 Page Not Found: Wp/wp_includes
ERROR - 2021-05-03 19:31:38 --> 404 Page Not Found: News/wp_includes
ERROR - 2021-05-03 19:31:38 --> 404 Page Not Found: 2018/wp_includes
ERROR - 2021-05-03 19:31:39 --> 404 Page Not Found: 2019/wp_includes
ERROR - 2021-05-03 19:31:39 --> 404 Page Not Found: Shop/wp_includes
ERROR - 2021-05-03 19:31:39 --> 404 Page Not Found: Wp1/wp_includes
ERROR - 2021-05-03 19:31:39 --> 404 Page Not Found: Test/wp_includes
ERROR - 2021-05-03 19:31:40 --> 404 Page Not Found: Media/wp_includes
ERROR - 2021-05-03 19:31:40 --> 404 Page Not Found: Wp2/wp_includes
ERROR - 2021-05-03 19:31:40 --> 404 Page Not Found: Site/wp_includes
ERROR - 2021-05-03 19:31:40 --> 404 Page Not Found: Cms/wp_includes
ERROR - 2021-05-03 19:31:41 --> 404 Page Not Found: Sito/wp_includes
