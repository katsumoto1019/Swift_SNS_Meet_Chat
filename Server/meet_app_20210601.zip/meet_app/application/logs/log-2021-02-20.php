<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-20 00:45:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-02-20 00:45:40 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-02-20 00:45:42 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-02-20 07:50:48 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-02-20 07:50:49 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-02-20 10:59:28 --> 404 Page Not Found: Git/HEAD
ERROR - 2021-02-20 13:51:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-02-20 16:40:07 --> 404 Page Not Found: Git/HEAD
ERROR - 2021-02-20 21:44:37 --> 404 Page Not Found: Wp_includes/js
