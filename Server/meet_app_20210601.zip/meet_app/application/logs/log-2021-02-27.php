<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-27 01:06:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-02-27 07:44:08 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-02-27 07:44:09 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-02-27 11:48:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-02-27 18:48:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-02-27 23:54:35 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-02-27 23:54:36 --> 404 Page Not Found: App_adstxt/index
