<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-07 07:47:28 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-12-07 07:47:29 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-12-07 19:17:56 --> 404 Page Not Found: Robotstxt/index
