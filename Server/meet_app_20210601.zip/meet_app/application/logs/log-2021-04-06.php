<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-06 03:23:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-04-06 05:09:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-04-06 06:35:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2021-04-06 06:45:33 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-04-06 06:45:33 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-04-06 09:19:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-04-06 17:24:43 --> 404 Page Not Found: Assets/global
ERROR - 2021-04-06 18:22:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-04-06 22:01:30 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-04-06 22:01:31 --> 404 Page Not Found: 404javascriptjs/index
