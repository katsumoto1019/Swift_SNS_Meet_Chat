<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-25 06:30:48 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-10-25 06:47:43 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-10-25 06:47:44 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-10-25 08:00:35 --> 404 Page Not Found: Env/index
ERROR - 2020-10-25 13:42:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-10-25 22:18:27 --> 404 Page Not Found: Wp_loginphp/index
