<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-05 06:51:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-05 07:45:58 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-12-05 07:45:59 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-12-05 08:31:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-05 10:32:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-05 11:03:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-05 11:03:06 --> 404 Page Not Found: Humanstxt/index
ERROR - 2020-12-05 11:03:06 --> 404 Page Not Found: Adstxt/index
