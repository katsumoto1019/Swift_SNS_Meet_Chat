<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-08 04:32:00 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-01-08 06:41:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-01-08 06:41:23 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-01-08 07:51:50 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-01-08 07:51:50 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-01-08 10:58:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-01-08 10:58:02 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-01-08 18:48:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-01-08 23:31:56 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-01-08 23:31:57 --> 404 Page Not Found: Adstxt/index
