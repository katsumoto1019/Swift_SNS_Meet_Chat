<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-09 05:18:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-09-09 05:18:46 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2020-09-09 20:57:59 --> 404 Page Not Found: Wp_loginphp/index
