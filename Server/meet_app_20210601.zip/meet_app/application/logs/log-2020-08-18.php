<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-18 11:00:18 --> 404 Page Not Found: Android_icon_192x192png/index
