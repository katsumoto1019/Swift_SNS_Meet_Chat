<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-05 03:01:07 --> 404 Page Not Found: Wordpress/wp_login.php
ERROR - 2021-03-05 03:01:37 --> 404 Page Not Found: Wp/wp_login.php
ERROR - 2021-03-05 07:41:40 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-03-05 07:41:41 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-03-05 12:04:39 --> 404 Page Not Found: Blog/wp_login.php
ERROR - 2021-03-05 22:01:54 --> 404 Page Not Found: Wp_includes/wlwmanifest.xml
ERROR - 2021-03-05 22:01:54 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2021-03-05 22:01:55 --> 404 Page Not Found: Blog/wp_includes
ERROR - 2021-03-05 22:01:55 --> 404 Page Not Found: Web/wp_includes
ERROR - 2021-03-05 22:01:55 --> 404 Page Not Found: Wordpress/wp_includes
ERROR - 2021-03-05 22:01:56 --> 404 Page Not Found: Website/wp_includes
ERROR - 2021-03-05 22:01:56 --> 404 Page Not Found: Wp/wp_includes
ERROR - 2021-03-05 22:01:56 --> 404 Page Not Found: News/wp_includes
ERROR - 2021-03-05 22:01:56 --> 404 Page Not Found: 2018/wp_includes
ERROR - 2021-03-05 22:01:57 --> 404 Page Not Found: 2019/wp_includes
ERROR - 2021-03-05 22:01:57 --> 404 Page Not Found: Shop/wp_includes
ERROR - 2021-03-05 22:01:57 --> 404 Page Not Found: Wp1/wp_includes
ERROR - 2021-03-05 22:01:57 --> 404 Page Not Found: Test/wp_includes
ERROR - 2021-03-05 22:01:58 --> 404 Page Not Found: Media/wp_includes
ERROR - 2021-03-05 22:01:58 --> 404 Page Not Found: Wp2/wp_includes
ERROR - 2021-03-05 22:01:58 --> 404 Page Not Found: Site/wp_includes
ERROR - 2021-03-05 22:01:58 --> 404 Page Not Found: Cms/wp_includes
ERROR - 2021-03-05 22:01:59 --> 404 Page Not Found: Sito/wp_includes
