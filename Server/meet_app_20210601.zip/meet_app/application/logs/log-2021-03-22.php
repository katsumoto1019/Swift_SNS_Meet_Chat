<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-22 04:27:58 --> 404 Page Not Found: __media__/js
ERROR - 2021-03-22 06:43:44 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-03-22 06:43:46 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-03-22 14:46:32 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-03-22 19:23:59 --> 404 Page Not Found: Robotstxt/index
