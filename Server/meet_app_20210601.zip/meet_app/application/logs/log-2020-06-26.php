<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-26 00:00:16 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-06-26 07:46:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-26 07:46:24 --> 404 Page Not Found: Wp_content/uploads
ERROR - 2020-06-26 10:02:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-26 10:02:59 --> 404 Page Not Found: Terms_of_use/index
ERROR - 2020-06-26 10:30:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-26 10:30:04 --> 404 Page Not Found: Wp_content/uploads
ERROR - 2020-06-26 14:08:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-26 14:08:28 --> 404 Page Not Found: Wp_json/oembed
ERROR - 2020-06-26 14:25:51 --> 404 Page Not Found: Wp_includes/wlwmanifest.xml
ERROR - 2020-06-26 15:51:54 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-06-26 15:51:58 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-06-26 15:52:02 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-06-26 15:52:12 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-06-26 16:35:58 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-06-26 20:14:11 --> 404 Page Not Found: App_adstxt/index
ERROR - 2020-06-26 20:14:11 --> 404 Page Not Found: App_adstxt/index
ERROR - 2020-06-26 20:30:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-26 20:30:51 --> 404 Page Not Found: Feed/index
ERROR - 2020-06-26 21:09:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-26 21:09:48 --> 404 Page Not Found: App_adstxt/index
