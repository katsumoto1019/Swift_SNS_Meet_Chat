<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-03 03:14:05 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-02-03 03:14:05 --> 404 Page Not Found: Wordpress/wp_login.php
ERROR - 2021-02-03 03:14:06 --> 404 Page Not Found: Blog/wp_login.php
ERROR - 2021-02-03 03:14:06 --> 404 Page Not Found: Wp/wp_login.php
ERROR - 2021-02-03 07:44:29 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-02-03 07:44:29 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-02-03 21:18:31 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-02-03 22:46:04 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-02-03 22:46:04 --> 404 Page Not Found: Wordpress/wp_login.php
ERROR - 2021-02-03 22:46:05 --> 404 Page Not Found: Blog/wp_login.php
ERROR - 2021-02-03 22:46:05 --> 404 Page Not Found: Wp/wp_login.php
