<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-26 04:11:13 --> 404 Page Not Found: Env/index
ERROR - 2021-04-26 06:33:41 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-04-26 06:33:42 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-04-26 09:19:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-04-26 14:34:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-04-26 18:47:53 --> 404 Page Not Found: Admin/jQuery_File_Upload
ERROR - 2021-04-26 23:52:26 --> 404 Page Not Found: Robotstxt/index
