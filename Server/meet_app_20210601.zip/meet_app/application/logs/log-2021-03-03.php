<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-03 07:44:53 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-03-03 07:44:54 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-03-03 17:50:49 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-03-03 21:43:41 --> 404 Page Not Found: Robotstxt/index
