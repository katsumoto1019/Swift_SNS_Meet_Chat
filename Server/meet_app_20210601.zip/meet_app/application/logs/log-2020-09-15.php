<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-15 12:40:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-09-15 16:52:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-09-15 23:29:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-09-15 23:29:39 --> 404 Page Not Found: Humanstxt/index
ERROR - 2020-09-15 23:29:39 --> 404 Page Not Found: Adstxt/index
