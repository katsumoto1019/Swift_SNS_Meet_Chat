<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-16 12:50:39 --> 404 Page Not Found: Api/getContents
