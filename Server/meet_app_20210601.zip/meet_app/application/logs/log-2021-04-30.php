<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-30 04:34:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-04-30 06:37:32 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-04-30 06:37:33 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-04-30 09:13:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-04-30 10:12:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-04-30 14:05:28 --> 404 Page Not Found: Plugins/jQuery_File_Upload
