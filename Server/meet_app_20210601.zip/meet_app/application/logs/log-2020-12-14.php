<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-14 02:22:04 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-12-14 03:01:28 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-12-14 03:58:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-14 04:45:57 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-12-14 04:45:59 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-12-14 07:49:52 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-12-14 07:49:53 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-12-14 08:24:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-14 10:58:46 --> 404 Page Not Found: Wp_admin/links.php
ERROR - 2020-12-14 10:58:46 --> 404 Page Not Found: Wp_admin/links.php
