<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-15 03:19:24 --> 404 Page Not Found: Wp_loginphp/index
