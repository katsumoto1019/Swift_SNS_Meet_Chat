<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-08 06:31:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-08 06:31:21 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2021-05-08 06:31:24 --> 404 Page Not Found: Blog/robots.txt
ERROR - 2021-05-08 06:31:24 --> 404 Page Not Found: Blog/index
ERROR - 2021-05-08 06:31:24 --> 404 Page Not Found: Wordpress/index
ERROR - 2021-05-08 06:31:24 --> 404 Page Not Found: Wp/index
ERROR - 2021-05-08 06:36:32 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-05-08 06:36:33 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-05-08 14:48:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-08 16:08:06 --> 404 Page Not Found: Sxd/sxd.js
ERROR - 2021-05-08 16:08:07 --> 404 Page Not Found: SypexDumper/sxd
ERROR - 2021-05-08 16:08:07 --> 404 Page Not Found: Dumper/sxd.js
ERROR - 2021-05-08 16:08:08 --> 404 Page Not Found: Admin/dumper
ERROR - 2021-05-08 16:08:08 --> 404 Page Not Found: Admin/sxd
ERROR - 2021-05-08 16:08:09 --> 404 Page Not Found: Backup/sxd
ERROR - 2021-05-08 16:08:10 --> 404 Page Not Found: Dump/sxd.js
ERROR - 2021-05-08 20:14:24 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-05-08 22:38:54 --> 404 Page Not Found: Robotstxt/index
