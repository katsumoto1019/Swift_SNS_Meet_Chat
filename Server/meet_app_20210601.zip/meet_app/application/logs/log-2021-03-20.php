<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-20 06:44:28 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-03-20 06:44:29 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-03-20 10:01:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-03-20 11:00:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-03-20 23:42:58 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-03-20 23:43:16 --> 404 Page Not Found: Wp_loginphp/index
