<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-17 06:19:11 --> 404 Page Not Found: Robotstxt/index
