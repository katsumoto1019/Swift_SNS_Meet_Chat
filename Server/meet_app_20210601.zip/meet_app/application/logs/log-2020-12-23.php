<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-23 16:23:50 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `tb_attr` (`user_id`, `attribute`) VALUES (38, 'パンセクシュアル')
ERROR - 2020-12-23 16:29:34 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `tb_attr` (`user_id`, `attribute`) VALUES (39, 'タチ')
ERROR - 2020-12-23 16:31:51 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `tb_attr` (`user_id`, `attribute`) VALUES (40, 'タチ')
ERROR - 2020-12-23 16:34:28 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `tb_attr` (`user_id`, `attribute`) VALUES (41, 'ストレート ')
ERROR - 2020-12-23 16:38:34 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `tb_attr` (`user_id`, `attribute`) VALUES (42, 'ストレート ')
ERROR - 2020-12-23 16:39:56 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `tb_attr` (`user_id`, `attribute`) VALUES (43, 'ストレート ')
ERROR - 2020-12-23 07:41:57 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-12-23 07:41:58 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-12-23 22:06:20 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `tb_attr` (`user_id`, `attribute`) VALUES (44, 'パンセクシュアル')
ERROR - 2020-12-23 22:10:42 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `tb_attr` (`user_id`, `attribute`) VALUES (45, 'パンセクシュアル ')
ERROR - 2020-12-23 22:23:04 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `tb_attr` (`user_id`, `attribute`) VALUES (46, 'ストレート')
ERROR - 2020-12-23 23:15:03 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `tb_attr` (`user_id`, `attribute`) VALUES (48, 'クエスチョニング')
ERROR - 2020-12-23 23:17:21 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `tb_attr` (`user_id`, `attribute`) VALUES (49, 'クエスチョニング')
ERROR - 2020-12-23 23:17:52 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `tb_attr` (`user_id`, `attribute`) VALUES (50, 'クエスチョニング')
ERROR - 2020-12-23 18:30:31 --> 404 Page Not Found: Skins/landingassets
ERROR - 2020-12-23 18:30:31 --> 404 Page Not Found: Skins/landingassets
ERROR - 2020-12-23 22:36:25 --> 404 Page Not Found: Robotstxt/index
