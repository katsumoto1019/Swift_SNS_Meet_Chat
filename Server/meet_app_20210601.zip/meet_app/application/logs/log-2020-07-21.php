<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-21 01:34:03 --> Query error: Unknown column 'post_id' in 'field list' - Invalid query: INSERT INTO `tb_notification` (`owner_id`, `post_id`, `user_id`, `user_name`, `user_photo`, `created_at`, `type`) VALUES ('6', '1', '6', 'sdfsdfsdf', 'sdfsdfsdf', '2020-07-21 01:34:02', 'like')
ERROR - 2020-07-21 01:36:32 --> Query error: Unknown column 'post_id' in 'field list' - Invalid query: INSERT INTO `tb_notification` (`owner_id`, `post_id`, `user_id`, `user_name`, `user_photo`, `created_at`, `type`) VALUES ('6', '1', '6', 'sdfsdfsdf', 'sdfsdfsdf', '2020-07-21 01:36:32', 'like')
ERROR - 2020-07-21 01:48:24 --> Severity: Notice --> Undefined index: post_id C:\xampp\htdocs\application\controllers\Api.php 371
ERROR - 2020-07-21 01:48:24 --> Query error: Unknown column 'post_id' in 'where clause' - Invalid query: DELETE FROM `tb_follow`
WHERE `post_id` IS NULL
AND `user_id` = '6'
ERROR - 2020-07-21 02:09:47 --> Severity: Notice --> Undefined property: stdClass::$device_token C:\xampp\htdocs\application\models\Api_model.php 85
ERROR - 2020-07-21 02:09:48 --> Severity: Notice --> Undefined variable: user_id C:\xampp\htdocs\application\controllers\Api.php 394
ERROR - 2020-07-21 02:09:55 --> Severity: Notice --> Undefined property: stdClass::$device_token C:\xampp\htdocs\application\models\Api_model.php 85
ERROR - 2020-07-21 02:09:56 --> Severity: Notice --> Undefined variable: user_id C:\xampp\htdocs\application\controllers\Api.php 394
ERROR - 2020-07-21 02:10:17 --> Severity: Notice --> Undefined property: stdClass::$device_token C:\xampp\htdocs\application\models\Api_model.php 85
ERROR - 2020-07-21 02:10:17 --> Severity: Notice --> Undefined variable: user_id C:\xampp\htdocs\application\controllers\Api.php 394
ERROR - 2020-07-21 02:19:20 --> Query error: Unknown column 'content' in 'field list' - Invalid query: INSERT INTO `tb_like` (`post_id`, `user_id`, `user_name`, `user_photo`, `content`, `created_at`) VALUES ('1', '6', 'sdfsdfsdf', 'sdfsdfsdf', 'asdasdas', '2020-07-21 02:19:20')
ERROR - 2020-07-21 03:33:01 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::insert_query() C:\xampp\htdocs\application\controllers\Api.php 464
ERROR - 2020-07-21 04:34:09 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 04:34:28 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 04:47:38 --> Severity: Notice --> date_default_timezone_set(): Timezone ID 'UTC +9' is invalid C:\xampp\htdocs\application\controllers\Api.php 33
ERROR - 2020-07-21 04:48:54 --> Severity: Notice --> date_default_timezone_set(): Timezone ID 'Tokyo' is invalid C:\xampp\htdocs\application\controllers\Api.php 33
ERROR - 2020-07-21 04:49:17 --> Severity: Notice --> date_default_timezone_set(): Timezone ID 'JST' is invalid C:\xampp\htdocs\application\controllers\Api.php 33
ERROR - 2020-07-21 11:58:08 --> Query error: Table 'emoglass.tb_donate' doesn't exist - Invalid query: SELECT *
FROM `tb_donate`
WHERE `type` = 'money'
ERROR - 2020-07-21 11:58:15 --> Query error: Table 'emoglass.tb_donate' doesn't exist - Invalid query: SELECT *
FROM `tb_donate`
WHERE `type` = 'money'
ERROR - 2020-07-21 11:58:19 --> Query error: Table 'emoglass.tb_donate' doesn't exist - Invalid query: SELECT *
FROM `tb_donate`
WHERE `type` = 'money'
ERROR - 2020-07-21 12:01:38 --> Query error: Table 'emoglass.tb_donate' doesn't exist - Invalid query: SELECT *
FROM `tb_donate`
WHERE `type` = 'money'
ERROR - 2020-07-21 05:07:17 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-21 05:07:37 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-21 05:08:55 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-21 05:13:03 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-21 05:13:18 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-21 05:14:09 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-21 05:14:51 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-21 05:15:18 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-21 05:20:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-21 05:20:10 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-21 05:22:14 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-21 05:22:27 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-21 05:22:36 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-21 12:29:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Api.php 367
ERROR - 2020-07-21 12:29:06 --> Severity: Notice --> Undefined index: user_id C:\xampp\htdocs\application\controllers\Api.php 374
ERROR - 2020-07-21 12:29:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Api.php 376
ERROR - 2020-07-21 12:29:06 --> Severity: Notice --> Undefined index: user_id C:\xampp\htdocs\application\controllers\Api.php 378
ERROR - 2020-07-21 12:29:40 --> Severity: Notice --> Undefined property: stdClass::$device_token C:\xampp\htdocs\application\models\Api_model.php 93
ERROR - 2020-07-21 12:29:40 --> Severity: Notice --> Undefined index: user_id C:\xampp\htdocs\application\controllers\Api.php 374
ERROR - 2020-07-21 12:29:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Api.php 376
ERROR - 2020-07-21 12:29:40 --> Severity: Notice --> Undefined index: user_id C:\xampp\htdocs\application\controllers\Api.php 378
ERROR - 2020-07-21 12:32:12 --> Severity: Notice --> Undefined property: stdClass::$device_token C:\xampp\htdocs\application\models\Api_model.php 93
ERROR - 2020-07-21 12:34:42 --> Severity: Notice --> Undefined property: stdClass::$device_token C:\xampp\htdocs\application\models\Api_model.php 93
ERROR - 2020-07-21 12:35:43 --> Severity: Notice --> Undefined property: stdClass::$device_token C:\xampp\htdocs\application\models\Api_model.php 93
ERROR - 2020-07-21 12:36:18 --> Severity: Notice --> Undefined property: stdClass::$device_token C:\xampp\htdocs\application\models\Api_model.php 93
ERROR - 2020-07-21 12:39:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Api.php 404
ERROR - 2020-07-21 05:39:55 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-21 05:40:13 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-21 05:40:39 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-21 05:40:43 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-21 05:41:44 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-21 05:41:46 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-21 05:41:48 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-21 05:46:34 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-21 05:48:23 --> 404 Page Not Found: Admin/posts
ERROR - 2020-07-21 05:54:46 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 05:55:09 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 13:00:57 --> Query error: Table 'emoglass.tb_paymentinfo' doesn't exist - Invalid query: SELECT *
FROM `tb_paymentinfo`
WHERE `user_id` = '6'
ORDER BY `id` DESC
ERROR - 2020-07-21 06:16:15 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:16:15 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:16:53 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:16:53 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:17:15 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:17:15 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:17:44 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:17:44 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:18:34 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:18:34 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:20:09 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:20:09 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:20:13 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:20:13 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:20:18 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:20:18 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:23:13 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:23:13 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:23:45 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:23:45 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:24:14 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:24:14 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:24:39 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:24:39 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:24:56 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:24:56 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:25:11 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:25:11 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:26:46 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:26:46 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:27:12 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:27:12 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:27:43 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:27:43 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:27:50 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:27:50 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:27:52 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:27:52 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:27:55 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:27:55 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:28:21 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:28:21 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:28:49 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:28:49 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:30:01 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:30:01 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:30:15 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:30:15 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:30:19 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:30:19 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:31:21 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:31:21 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:31:39 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:31:39 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:31:56 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:31:56 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:31:59 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:31:59 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:32:27 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:32:27 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:32:55 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:32:55 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:33:24 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:33:24 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:33:58 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:33:58 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:34:23 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:34:23 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:35:18 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:35:18 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:36:02 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:36:02 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:38:46 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:38:46 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:39:36 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:39:44 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:39:44 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:40:27 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:40:27 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:42:33 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:42:33 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:47:04 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:47:04 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:47:08 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:47:08 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:47:13 --> 404 Page Not Found: Admin/posts
ERROR - 2020-07-21 06:47:16 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:47:16 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 06:50:00 --> 404 Page Not Found: Admin/posts
ERROR - 2020-07-21 06:50:15 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 06:50:15 --> 404 Page Not Found: Admin/sdfsdfsdfsdf
ERROR - 2020-07-21 00:21:40 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 00:21:40 --> Severity: Notice --> Undefined variable: posts C:\xampp\htdocs\application\views\admin\posts.php 70
ERROR - 2020-07-21 00:21:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\posts.php 70
ERROR - 2020-07-21 00:21:53 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-21 00:22:02 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 00:22:02 --> Severity: Notice --> Undefined variable: posts C:\xampp\htdocs\application\views\admin\posts.php 70
ERROR - 2020-07-21 00:22:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\posts.php 70
ERROR - 2020-07-21 00:22:04 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 00:22:04 --> Severity: Notice --> Undefined variable: posts C:\xampp\htdocs\application\views\admin\posts.php 70
ERROR - 2020-07-21 00:22:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\posts.php 70
ERROR - 2020-07-21 00:23:38 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 00:23:38 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\application\views\admin\posts.php 74
ERROR - 2020-07-21 00:23:38 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\application\views\admin\posts.php 76
ERROR - 2020-07-21 00:23:38 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\application\views\admin\posts.php 74
ERROR - 2020-07-21 00:23:38 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\application\views\admin\posts.php 76
ERROR - 2020-07-21 00:23:38 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\application\views\admin\posts.php 74
ERROR - 2020-07-21 00:23:38 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\application\views\admin\posts.php 76
ERROR - 2020-07-21 00:23:38 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\application\views\admin\posts.php 74
ERROR - 2020-07-21 00:23:38 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\application\views\admin\posts.php 76
ERROR - 2020-07-21 00:23:38 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\application\views\admin\posts.php 74
ERROR - 2020-07-21 00:23:38 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\application\views\admin\posts.php 76
ERROR - 2020-07-21 00:23:38 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\application\views\admin\posts.php 74
ERROR - 2020-07-21 00:23:38 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\application\views\admin\posts.php 76
ERROR - 2020-07-21 00:23:38 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\application\views\admin\posts.php 74
ERROR - 2020-07-21 00:23:38 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\application\views\admin\posts.php 76
ERROR - 2020-07-21 00:23:38 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\application\views\admin\posts.php 74
ERROR - 2020-07-21 00:23:38 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\application\views\admin\posts.php 76
ERROR - 2020-07-21 00:23:38 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\application\views\admin\posts.php 74
ERROR - 2020-07-21 00:23:38 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\application\views\admin\posts.php 76
ERROR - 2020-07-21 00:23:38 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\application\views\admin\posts.php 74
ERROR - 2020-07-21 00:23:38 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\application\views\admin\posts.php 76
ERROR - 2020-07-21 00:23:38 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\application\views\admin\posts.php 74
ERROR - 2020-07-21 00:23:38 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\application\views\admin\posts.php 76
ERROR - 2020-07-21 00:23:38 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\application\views\admin\posts.php 74
ERROR - 2020-07-21 00:23:38 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\application\views\admin\posts.php 76
ERROR - 2020-07-21 07:23:38 --> 404 Page Not Found: Admin/%3Cdiv
ERROR - 2020-07-21 07:23:38 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 07:23:39 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 07:23:39 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:23:39 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 00:24:01 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:24:01 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:24:02 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:24:02 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:24:02 --> 404 Page Not Found: Admin/sdfsdfsdfsdf
ERROR - 2020-07-21 07:24:02 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 07:24:02 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 00:25:02 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:25:02 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:25:02 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 07:25:02 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 07:25:02 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:25:02 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 00:25:07 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-21 00:25:26 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:25:26 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:25:26 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:25:26 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:25:26 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 07:25:26 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 00:26:19 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:26:19 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:26:19 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:26:19 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:26:19 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 07:26:19 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 00:26:59 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:26:59 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:27:00 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:27:00 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:27:00 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 07:27:00 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 00:27:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 00:27:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 00:27:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 00:27:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 00:27:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 00:27:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 00:27:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 00:27:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 00:27:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 00:27:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 00:27:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 00:27:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 00:27:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 00:27:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 00:27:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 00:27:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 00:27:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 00:27:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 00:27:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 00:27:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 00:27:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 00:27:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 00:27:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 00:27:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 00:27:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 00:27:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 00:27:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 00:27:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 00:27:31 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:27:32 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:27:32 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 00:28:10 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:28:10 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:28:10 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:28:10 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:28:10 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 07:28:11 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 07:28:12 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:28:12 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 00:28:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 00:28:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 00:28:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 00:28:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 00:28:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 00:28:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 00:28:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 00:28:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 00:28:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 00:28:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 00:28:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 00:28:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 00:28:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 00:28:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 00:28:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 00:28:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 00:28:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 00:28:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 00:28:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 00:28:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 00:28:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 00:28:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 00:28:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 00:28:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 00:28:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 00:28:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 00:28:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 00:28:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 07:29:06 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:29:06 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 00:29:06 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 00:29:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 00:29:06 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 00:29:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 00:29:06 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 00:29:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 00:29:06 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 00:29:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 00:29:06 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 00:29:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 00:29:06 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 00:29:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 00:29:06 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 00:29:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 00:29:06 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 00:29:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 00:29:06 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 00:29:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 00:29:06 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 00:29:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 00:29:06 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 00:29:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 00:29:06 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 00:29:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 00:29:06 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 00:29:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 00:29:06 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 00:29:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 00:29:19 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:29:19 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:29:19 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:29:19 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:29:19 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 07:29:19 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 00:30:30 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:30:30 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:30:30 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:30:30 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:30:30 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 07:30:30 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 00:32:00 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:32:00 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:32:00 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 07:32:01 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 07:32:02 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:32:02 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 00:33:52 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:33:52 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:33:52 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 07:33:52 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 00:34:04 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:34:04 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:34:04 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:34:04 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:34:04 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 07:34:04 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 00:34:11 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:34:11 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:34:11 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:34:11 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:34:11 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 07:34:11 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 00:34:12 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:34:12 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:34:12 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:34:12 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:34:12 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 07:34:12 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 00:34:23 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:34:23 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:34:23 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:34:23 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:34:23 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 07:34:23 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 00:34:26 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:34:27 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:34:27 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:34:27 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:34:27 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 07:34:27 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 00:34:42 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:34:42 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:34:42 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:34:42 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:34:42 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 07:34:42 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 00:34:44 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:34:44 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:34:44 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:34:44 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:34:44 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 07:34:44 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 00:34:46 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:34:47 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:34:47 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:34:47 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:34:47 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 07:34:47 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 00:34:59 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:35:00 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:35:01 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:35:01 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:35:01 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 07:35:01 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 00:35:15 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:35:15 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:35:15 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:35:15 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:35:15 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 07:35:15 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 00:35:17 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:35:17 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:35:17 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:35:17 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:35:17 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 07:35:17 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 00:35:17 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:35:18 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:35:18 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:35:18 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:35:18 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 07:35:18 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 00:35:23 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:35:23 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:35:23 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:35:23 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:35:23 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 07:35:23 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 00:35:32 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:35:32 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:35:32 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:35:32 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:35:32 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 07:35:32 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 00:36:30 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:36:31 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:36:31 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 07:36:31 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 07:36:32 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:36:32 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 00:36:51 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:36:51 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:36:51 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:36:51 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:36:51 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 07:36:51 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 00:38:08 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:38:08 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:38:08 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:38:08 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:38:08 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 07:38:08 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 00:38:10 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:38:10 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:38:10 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:38:10 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:38:10 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 07:38:10 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 00:38:28 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:38:28 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:38:28 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:38:28 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:38:28 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 07:38:28 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 00:39:32 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:39:32 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:39:32 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:39:32 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:39:32 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 07:39:32 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 00:39:50 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:39:50 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:39:50 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:39:50 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:39:50 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 07:39:50 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 00:40:10 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:40:10 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:40:10 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:40:10 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:40:10 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 07:40:10 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 00:40:58 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:40:58 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:40:58 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:40:58 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:40:58 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 07:40:58 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 00:41:44 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:41:44 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:41:44 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 07:41:44 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:41:44 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:41:44 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 00:42:02 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:42:02 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:42:02 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:42:02 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:42:02 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 07:42:02 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 00:42:11 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:42:12 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:42:12 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:42:12 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:42:12 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 07:42:12 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 00:43:04 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:43:04 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:43:04 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:43:04 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:43:04 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 07:43:04 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 00:43:34 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:43:34 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:43:35 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:43:35 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:43:35 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 07:43:35 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 00:43:48 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:43:48 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:43:48 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:43:48 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:43:48 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 07:43:48 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 00:44:19 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:44:20 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:44:20 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:44:20 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:44:20 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 07:44:20 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 00:44:22 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:44:23 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:44:23 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:44:23 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:44:23 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 07:44:23 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 00:44:31 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:44:31 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:44:31 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:44:31 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:44:31 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 07:44:31 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 00:45:28 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:45:28 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:45:28 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 07:45:28 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:45:29 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 07:45:29 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 00:46:02 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:46:02 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:46:02 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:46:02 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 00:46:10 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:46:10 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:46:10 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 07:46:10 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 07:46:11 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:46:11 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 00:46:50 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:46:50 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:46:50 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:46:50 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:46:50 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 07:46:50 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 00:46:54 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:46:54 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:46:54 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:46:54 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:46:54 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 07:46:54 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 00:46:59 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:46:59 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:46:59 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:46:59 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:46:59 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 07:46:59 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 00:47:01 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:47:02 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:47:02 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:47:02 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:47:02 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 07:47:02 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 00:47:32 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:47:32 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:47:32 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:47:32 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:47:32 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 07:47:32 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 00:47:52 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:47:52 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:47:52 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:47:52 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:47:52 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 07:47:52 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 00:47:54 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:47:55 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:47:56 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:47:56 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:47:56 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 07:47:56 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 00:48:25 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:48:26 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:48:26 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 07:48:26 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:48:26 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 07:48:27 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 00:48:36 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:48:36 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:48:36 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 07:48:36 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 00:50:04 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:50:04 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:50:04 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:50:04 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:50:04 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 07:50:04 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 00:51:33 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:51:33 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:51:33 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 07:51:34 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:51:34 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:51:34 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 00:52:22 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:52:22 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:52:22 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 07:52:22 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 07:52:22 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:52:22 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 00:52:31 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:52:32 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:52:32 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:52:32 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:52:32 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 07:52:32 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 00:52:41 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:52:41 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:52:41 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:52:41 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:52:41 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 07:52:41 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 00:52:58 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:52:58 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:52:58 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:52:58 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:52:58 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 07:52:58 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 00:53:02 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:53:03 --> 404 Page Not Found: Admin/width
ERROR - 2020-07-21 07:53:03 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:53:03 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:53:03 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 07:53:03 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 00:53:27 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:53:27 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:53:27 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:53:27 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 07:53:27 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 00:53:29 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:53:30 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:53:30 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:53:31 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 07:53:31 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 00:55:00 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:55:00 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:55:00 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:55:00 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 07:55:00 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 00:55:02 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-21 07:55:02 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 00:55:05 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 00:55:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 00:55:05 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 00:55:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 00:55:05 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 00:55:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 00:55:05 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 00:55:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 00:55:05 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 00:55:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 00:55:05 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 00:55:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 00:55:05 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 00:55:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 00:55:05 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 00:55:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 00:55:05 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 00:55:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 00:55:05 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 00:55:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 00:55:05 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 00:55:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 00:55:05 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 00:55:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 00:55:05 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 00:55:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 00:55:05 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 00:55:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 07:55:05 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:55:05 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 00:55:06 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-21 07:55:06 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 00:55:16 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-21 07:55:16 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 00:55:28 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-21 07:55:28 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 00:55:38 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-21 07:55:38 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 00:55:45 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-21 07:55:45 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 00:55:53 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-21 07:55:53 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 00:56:33 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-21 00:56:39 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-21 07:56:39 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 00:57:15 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-21 07:57:15 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 00:57:38 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-21 07:57:38 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 00:58:11 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-21 07:58:11 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 00:58:30 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-21 00:58:39 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:58:40 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:58:40 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:58:40 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 07:58:40 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 07:58:43 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:58:43 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 00:58:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 00:58:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 00:58:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 00:58:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 00:58:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 00:58:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 00:58:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 00:58:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 00:58:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 00:58:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 00:58:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 00:58:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 00:58:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 00:58:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 00:58:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 00:58:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 00:58:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 00:58:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 00:58:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 00:58:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 00:58:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 00:58:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 00:58:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 00:58:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 00:58:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 00:58:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 00:58:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 00:58:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 00:58:49 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:58:50 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:58:50 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:58:50 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 07:58:50 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 00:58:53 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-21 07:58:53 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 00:58:59 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:59:00 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:59:00 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:59:00 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 07:59:00 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 00:59:02 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-21 00:59:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 00:59:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 00:59:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 00:59:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 00:59:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 00:59:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 00:59:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 00:59:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 00:59:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 00:59:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 00:59:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 00:59:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 00:59:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 00:59:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 00:59:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 00:59:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 07:59:04 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:59:04 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 00:59:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 00:59:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 00:59:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 00:59:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 00:59:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 00:59:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 00:59:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 00:59:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 00:59:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 00:59:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 00:59:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 00:59:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 00:59:26 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 07:59:26 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:59:26 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:59:27 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 07:59:27 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 00:59:29 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-21 07:59:35 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 07:59:35 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 00:59:35 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 00:59:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 00:59:35 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 00:59:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 00:59:35 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 00:59:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 00:59:35 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 00:59:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 00:59:35 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 00:59:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 00:59:35 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 00:59:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 00:59:35 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 00:59:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 00:59:35 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 00:59:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 00:59:35 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 00:59:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 00:59:35 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 00:59:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 00:59:35 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 00:59:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 00:59:35 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 00:59:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 00:59:35 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 00:59:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 00:59:35 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 00:59:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 08:00:03 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 08:00:03 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 01:00:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:00:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:00:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:00:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:00:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:00:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:00:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:00:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:00:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:00:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:00:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:00:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:00:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:00:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:00:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:00:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:00:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:00:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:00:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:00:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:00:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:00:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:00:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:00:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:00:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:00:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:00:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:00:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:01:00 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 08:01:00 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 08:01:00 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 08:01:01 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 08:01:01 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 01:01:08 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-21 01:01:10 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:01:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:01:10 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:01:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:01:10 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:01:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:01:10 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:01:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:01:10 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:01:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:01:10 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:01:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:01:10 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:01:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:01:10 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:01:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:01:10 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:01:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:01:10 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:01:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:01:10 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:01:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:01:10 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:01:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:01:10 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:01:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:01:10 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:01:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 08:01:11 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 08:01:11 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 01:01:17 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 08:01:17 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 08:01:17 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 08:01:17 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 08:01:17 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 08:01:18 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 08:01:18 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 01:01:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:01:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:01:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:01:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:01:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:01:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:01:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:01:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:01:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:01:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:01:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:01:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:01:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:01:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:01:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:01:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:01:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:01:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:01:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:01:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:01:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:01:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:01:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:01:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:01:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:01:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:01:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:01:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:01:29 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-21 01:01:31 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:01:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:01:31 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:01:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:01:31 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:01:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:01:31 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:01:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:01:31 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:01:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:01:31 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:01:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:01:31 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:01:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:01:31 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:01:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:01:31 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:01:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:01:31 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:01:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:01:31 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:01:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:01:31 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:01:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:01:31 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:01:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:01:31 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:01:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 08:01:32 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 08:01:32 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 01:01:34 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 08:01:35 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 08:01:35 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 08:01:35 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 08:01:35 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 01:02:13 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-21 01:02:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:02:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:02:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:02:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:02:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:02:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:02:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:02:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:02:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:02:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:02:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:02:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:02:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:02:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:02:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:02:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:02:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:02:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:02:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:02:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:02:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:02:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:02:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:02:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:02:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:02:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:02:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:02:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 08:02:16 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 08:02:16 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 01:02:54 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-21 08:02:55 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 01:02:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:02:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:02:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:02:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:02:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:02:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:02:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 08:02:57 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 08:02:57 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 01:02:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:02:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:02:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:02:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:02:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:02:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:02:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:02:59 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 08:02:59 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 08:02:59 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 08:02:59 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 08:02:59 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 08:03:00 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 08:03:00 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 01:03:00 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:03:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:03:00 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:03:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:03:00 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:03:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:03:00 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:03:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:03:00 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:03:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:03:00 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:03:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:03:00 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:03:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:03:00 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:03:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:03:00 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:03:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:03:00 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:03:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:03:00 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:03:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:03:00 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:03:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:03:00 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:03:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:03:00 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:03:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:03:02 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 08:03:02 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 08:03:02 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 08:03:02 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 08:03:02 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 01:03:03 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-21 08:03:03 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 01:03:05 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-21 01:03:06 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-21 01:03:08 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:03:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:03:08 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:03:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:03:08 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:03:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:03:08 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:03:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:03:08 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:03:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:03:08 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:03:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:03:08 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:03:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:03:08 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:03:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:03:08 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:03:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:03:08 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:03:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:03:08 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:03:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:03:08 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:03:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:03:08 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:03:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:03:08 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:03:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 08:03:08 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 08:03:08 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 01:03:32 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 08:03:32 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 08:03:32 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 01:03:35 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-21 08:03:35 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 01:04:05 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-21 08:04:05 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 01:04:24 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-21 08:04:24 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 01:05:11 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 08:05:11 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 08:05:12 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 08:05:12 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 08:05:12 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 01:05:23 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 08:05:23 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 08:05:23 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 08:05:23 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 08:05:23 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 01:05:38 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-21 08:05:38 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 01:05:40 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-21 01:06:24 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:06:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:06:24 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:06:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:06:24 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:06:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:06:24 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:06:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:06:24 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:06:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:06:24 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:06:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:06:24 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:06:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:06:25 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:06:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:06:25 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:06:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:06:25 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:06:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:06:25 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:06:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:06:25 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:06:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:06:25 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:06:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:06:25 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:06:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 08:06:25 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 08:06:25 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 08:06:39 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 08:06:39 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 01:06:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:06:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:06:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:06:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:06:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:06:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:06:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:06:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:06:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:06:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:06:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:06:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:06:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:06:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:06:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:06:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:06:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:06:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:06:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:06:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:06:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:06:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:06:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:06:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:06:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:06:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:06:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:06:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:07:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:07:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:07:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:07:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:07:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:07:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:07:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 08:07:32 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 08:07:32 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 01:07:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:07:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:07:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:07:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:07:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:07:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:07:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:08:21 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-21 08:08:22 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 01:08:25 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 08:08:25 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 08:08:25 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 01:12:21 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 08:12:21 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 08:12:21 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 08:12:21 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 08:12:21 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 01:12:22 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-21 08:12:22 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 01:12:24 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-21 01:12:26 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:12:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:12:26 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:12:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:12:26 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:12:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:12:26 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:12:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:12:26 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:12:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:12:26 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:12:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:12:26 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:12:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 08:12:26 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 08:12:26 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 01:12:26 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:12:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:12:26 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:12:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:12:26 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:12:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:12:26 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:12:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:12:26 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:12:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:12:26 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:12:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:12:26 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:12:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:14:39 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-21 08:14:40 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 01:17:55 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-21 01:25:13 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 08:25:14 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 08:25:14 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 08:25:14 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 08:25:14 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 01:25:29 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 08:25:29 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 08:25:29 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 08:25:29 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 08:25:29 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 01:25:32 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 08:25:32 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 08:25:32 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 08:25:32 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 08:25:32 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 01:26:02 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-21 08:26:02 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 01:26:04 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 08:26:04 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 08:26:04 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 08:26:04 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 08:26:04 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 08:26:06 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 08:26:06 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 01:26:06 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:26:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:26:06 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:26:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:26:06 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:26:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:26:06 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:26:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:26:06 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:26:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:26:06 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:26:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:26:06 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:26:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:26:06 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:26:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:26:06 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:26:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:26:06 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:26:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:26:06 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:26:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:26:06 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:26:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:26:06 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:26:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:26:06 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:26:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:26:09 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 08:26:09 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 08:26:09 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 08:26:09 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 08:26:09 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 08:26:13 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 08:26:13 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 01:26:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:26:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:26:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:26:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:26:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:26:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:26:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:26:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:26:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:26:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:26:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:26:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:26:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:26:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:26:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:26:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:26:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:26:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:26:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:26:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:26:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:26:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:26:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:26:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:26:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:26:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:26:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:26:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:26:18 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-21 01:26:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:26:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:26:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:26:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:26:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:26:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:26:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:26:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:26:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:26:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:26:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:26:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:26:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:26:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:26:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:26:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:26:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:26:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:26:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:26:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:26:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:26:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:26:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:26:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:26:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:26:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:26:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:26:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:26:33 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-21 01:26:40 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-21 01:26:46 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-21 01:26:53 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 08:26:53 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 08:26:53 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 01:26:54 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-21 08:26:54 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 01:26:56 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-21 08:26:56 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 01:26:57 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-21 08:26:57 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 01:26:57 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-21 08:26:57 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 01:26:58 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 08:26:58 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 08:26:58 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 01:26:59 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-21 01:27:01 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 08:27:02 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 08:27:02 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 01:27:02 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-21 01:27:07 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-21 08:27:07 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 01:27:18 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 08:27:19 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 08:27:19 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 08:27:19 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 08:27:19 --> 404 Page Not Found: Uploadfiles/file
ERROR - 2020-07-21 01:27:38 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 08:27:38 --> 404 Page Not Found: Admin/sdfsdfsdf
ERROR - 2020-07-21 08:27:38 --> 404 Page Not Found: Admin/sadfasdfasdf
ERROR - 2020-07-21 01:27:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:27:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:27:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:27:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:27:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:27:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:27:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:27:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:27:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:27:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:27:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:27:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:27:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:27:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:27:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:27:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 50
ERROR - 2020-07-21 01:27:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:27:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 53
ERROR - 2020-07-21 01:27:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:27:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 54
ERROR - 2020-07-21 01:27:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:27:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 55
ERROR - 2020-07-21 01:27:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:27:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 56
ERROR - 2020-07-21 01:27:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:27:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 57
ERROR - 2020-07-21 01:27:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:27:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\user-detail.php 58
ERROR - 2020-07-21 01:28:21 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 01:28:23 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 01:28:25 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-21 01:28:26 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-21 01:28:44 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 01:28:49 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-21 01:28:53 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-21 01:30:06 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 01:33:08 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-21 01:33:53 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-21 01:34:17 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 01:34:18 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-21 01:34:20 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-21 01:58:39 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 01:59:47 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 02:00:56 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 02:01:00 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 02:01:07 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 02:01:17 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 02:01:20 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-21 02:01:39 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 02:01:42 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-21 02:01:44 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-21 02:01:46 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 02:02:37 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 02:03:18 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-21 16:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Api.php 520
ERROR - 2020-07-21 16:04:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Api.php 520
ERROR - 2020-07-21 02:05:07 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 02:06:00 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 02:07:55 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 02:08:05 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 02:08:17 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 02:09:42 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 02:10:00 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 02:13:57 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-21 02:18:02 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 02:18:14 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-21 02:18:19 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-21 02:18:21 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-21 02:18:29 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-21 02:18:50 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 02:18:54 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\comments.php 52
ERROR - 2020-07-21 02:18:55 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 02:29:33 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 02:29:35 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\posts.php 52
ERROR - 2020-07-21 11:03:32 --> 404 Page Not Found: Wwwemoglasslive/assets
ERROR - 2020-07-21 11:03:32 --> 404 Page Not Found: Wwwemoglasslive/assets
ERROR - 2020-07-21 11:03:32 --> 404 Page Not Found: Wwwemoglasslive/assets
ERROR - 2020-07-21 11:03:32 --> 404 Page Not Found: Wwwemoglasslive/assets
ERROR - 2020-07-21 11:03:32 --> 404 Page Not Found: Wwwemoglasslive/assets
ERROR - 2020-07-21 11:03:32 --> 404 Page Not Found: Wwwemoglasslive/assets
ERROR - 2020-07-21 11:03:33 --> 404 Page Not Found: Wwwemoglasslive/assets
ERROR - 2020-07-21 11:03:33 --> 404 Page Not Found: Wwwemoglasslive/assets
ERROR - 2020-07-21 11:03:34 --> 404 Page Not Found: Wwwemoglasslive/assets
ERROR - 2020-07-21 11:03:34 --> 404 Page Not Found: Wwwemoglasslive/assets
ERROR - 2020-07-21 11:03:34 --> 404 Page Not Found: Wwwemoglasslive/assets
ERROR - 2020-07-21 11:03:34 --> 404 Page Not Found: Wwwemoglasslive/assets
ERROR - 2020-07-21 11:03:34 --> 404 Page Not Found: Wwwemoglasslive/assets
ERROR - 2020-07-21 11:03:34 --> 404 Page Not Found: Wwwemoglasslive/assets
ERROR - 2020-07-21 11:03:35 --> 404 Page Not Found: Wwwemoglasslive/assets
ERROR - 2020-07-21 11:03:35 --> 404 Page Not Found: Wwwemoglasslive/assets
ERROR - 2020-07-21 11:03:36 --> 404 Page Not Found: Wwwemoglasslive/assets
