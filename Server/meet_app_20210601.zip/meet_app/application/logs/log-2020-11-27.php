<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-27 07:25:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-27 07:42:34 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-11-27 07:42:35 --> 404 Page Not Found: 404javascriptjs/index
