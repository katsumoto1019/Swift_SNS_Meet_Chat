<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-03 17:30:17 --> 404 Page Not Found: Robotstxt/index
