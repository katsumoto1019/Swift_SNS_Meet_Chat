<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-14 11:36:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'Group By tb_user.id' at line 2 - Invalid query: SELECT * FROM tb_user WHERE tb_user.id != 
 Group By tb_user.id
ERROR - 2020-10-14 13:00:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT * FROM `tb_user` JOIN tb_follow ON tb_user.id = tb_follow.owner_id WHERE tb_follow.user_id =
ERROR - 2020-10-14 06:55:01 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-10-14 06:55:02 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-10-14 16:45:12 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-10-14 17:40:18 --> 404 Page Not Found: Wp_admin/install.php
