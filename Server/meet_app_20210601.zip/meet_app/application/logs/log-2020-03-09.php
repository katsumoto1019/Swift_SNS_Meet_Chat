<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-09 08:43:09 --> Severity: Notice --> Undefined index: categories C:\xampp\htdocs\application\controllers\Api.php 86
ERROR - 2020-03-09 08:43:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\controllers\Api.php 86
ERROR - 2020-03-09 11:28:19 --> Query error: Table 'foodtrack.tb_checkout' doesn't exist - Invalid query: SELECT *
FROM `tb_checkout`
WHERE `user_id` = '6'
AND `product_id` = '6'
ERROR - 2020-03-09 11:29:00 --> Query error: Table 'foodtrack.tb_checkout' doesn't exist - Invalid query: SELECT *
FROM `tb_checkout`
WHERE `user_id` = '6'
AND `product_id` = '6'
ERROR - 2020-03-09 16:33:54 --> Severity: Notice --> Undefined index: checkout_id C:\xampp\htdocs\application\controllers\Api.php 765
ERROR - 2020-03-09 16:39:26 --> Severity: Notice --> Undefined index: checkout_id C:\xampp\htdocs\application\controllers\Api.php 765
ERROR - 2020-03-09 16:39:38 --> Severity: Notice --> Undefined index: checkout_id C:\xampp\htdocs\application\controllers\Api.php 765
ERROR - 2020-03-09 16:39:39 --> Severity: Notice --> Undefined index: checkout_id C:\xampp\htdocs\application\controllers\Api.php 765
ERROR - 2020-03-09 16:44:44 --> Severity: Notice --> Undefined index: checkout_id C:\xampp\htdocs\application\controllers\Api.php 765
ERROR - 2020-03-09 16:49:07 --> Severity: Notice --> Undefined index: categories C:\xampp\htdocs\application\controllers\Api.php 86
ERROR - 2020-03-09 16:49:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\controllers\Api.php 86
ERROR - 2020-03-09 17:04:32 --> Query error: Unknown column 'checkout_id' in 'where clause' - Invalid query: DELETE FROM `tb_workoutvideo_checkout`
WHERE `checkout_id` = '3'
ERROR - 2020-03-09 17:04:35 --> Query error: Unknown column 'checkout_id' in 'where clause' - Invalid query: DELETE FROM `tb_workoutvideo_checkout`
WHERE `checkout_id` = '6'
ERROR - 2020-03-09 17:11:03 --> Severity: Notice --> Undefined index: user_name C:\xampp\htdocs\application\controllers\Api.php 794
ERROR - 2020-03-09 17:13:57 --> Severity: Notice --> Undefined index: user_name C:\xampp\htdocs\application\controllers\Api.php 794
ERROR - 2020-03-09 17:17:41 --> Severity: Notice --> Undefined index: user_name C:\xampp\htdocs\application\controllers\Api.php 794
ERROR - 2020-03-09 17:19:13 --> Severity: Notice --> Undefined index: user_name C:\xampp\htdocs\application\controllers\Api.php 794
ERROR - 2020-03-09 17:24:10 --> Severity: Notice --> Undefined index: user_name C:\xampp\htdocs\application\controllers\Api.php 794
ERROR - 2020-03-09 17:26:09 --> Severity: Notice --> Undefined index: categories C:\xampp\htdocs\application\controllers\Api.php 86
ERROR - 2020-03-09 17:26:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\controllers\Api.php 86
ERROR - 2020-03-09 17:26:43 --> Severity: Notice --> Undefined index: user_name C:\xampp\htdocs\application\controllers\Api.php 794
ERROR - 2020-03-09 17:28:22 --> Severity: Notice --> Undefined index: user_name C:\xampp\htdocs\application\controllers\Api.php 794
ERROR - 2020-03-09 17:35:31 --> Severity: Notice --> Undefined index: user_name C:\xampp\htdocs\application\controllers\Api.php 794
ERROR - 2020-03-09 17:42:57 --> Severity: Notice --> Undefined index: user_name C:\xampp\htdocs\application\controllers\Api.php 794
ERROR - 2020-03-09 17:48:42 --> Severity: Notice --> Undefined index: user_name C:\xampp\htdocs\application\controllers\Api.php 794
ERROR - 2020-03-09 17:57:02 --> Severity: Notice --> Undefined index: user_name C:\xampp\htdocs\application\controllers\Api.php 794
ERROR - 2020-03-09 17:58:59 --> Severity: Notice --> Undefined index: user_name C:\xampp\htdocs\application\controllers\Api.php 794
