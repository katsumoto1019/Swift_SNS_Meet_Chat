<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-14 01:40:01 --> 404 Page Not Found: Admin/simple
ERROR - 2020-07-14 01:40:26 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 01:41:18 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 01:44:21 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 01:44:29 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 01:45:03 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 01:45:06 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 01:47:13 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 01:47:14 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 01:47:18 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 01:48:14 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 01:48:26 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 01:48:35 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 01:48:39 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 01:54:17 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 01:54:31 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 01:54:56 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 01:55:00 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 01:55:10 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 01:55:13 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 01:57:01 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 01:57:30 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 01:57:37 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 01:57:54 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 01:58:54 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 02:00:57 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' C:\xampp\htdocs\application\controllers\Admin.php 259
ERROR - 2020-07-14 00:01:04 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:01:04 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 00:01:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\add_simple.php 28
ERROR - 2020-07-14 00:01:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_simple.php 28
ERROR - 2020-07-14 02:01:05 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:01:22 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:01:22 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 00:01:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_simple.php 28
ERROR - 2020-07-14 02:01:23 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:01:35 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:01:35 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 00:01:35 --> Severity: Notice --> Undefined index: question C:\xampp\htdocs\application\views\admin\add_simple.php 28
ERROR - 2020-07-14 02:01:36 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:01:48 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:01:48 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 00:01:48 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\add_simple.php 28
ERROR - 2020-07-14 02:01:49 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:03:21 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:03:21 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 00:03:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_simple.php 28
ERROR - 2020-07-14 02:03:21 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:03:50 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:03:50 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 00:03:50 --> Severity: Notice --> Undefined index: question C:\xampp\htdocs\application\views\admin\add_simple.php 23
ERROR - 2020-07-14 00:03:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_simple.php 29
ERROR - 2020-07-14 02:03:50 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:04:09 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:04:09 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 00:04:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_simple.php 23
ERROR - 2020-07-14 00:04:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_simple.php 29
ERROR - 2020-07-14 02:04:10 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:04:45 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:04:45 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 00:04:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\add_simple.php 23
ERROR - 2020-07-14 00:04:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_simple.php 23
ERROR - 2020-07-14 00:04:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_simple.php 29
ERROR - 2020-07-14 02:04:45 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:04:57 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:04:57 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 00:04:57 --> Severity: Notice --> Use of undefined constant question - assumed 'question' C:\xampp\htdocs\application\views\admin\add_simple.php 23
ERROR - 2020-07-14 00:04:57 --> Severity: Notice --> Undefined index: question C:\xampp\htdocs\application\views\admin\add_simple.php 23
ERROR - 2020-07-14 00:04:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_simple.php 29
ERROR - 2020-07-14 02:04:58 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:05:07 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:05:07 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 00:05:07 --> Severity: Notice --> Undefined index: question C:\xampp\htdocs\application\views\admin\add_simple.php 23
ERROR - 2020-07-14 00:05:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_simple.php 29
ERROR - 2020-07-14 02:05:08 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:07:01 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:07:01 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 00:07:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_simple.php 29
ERROR - 2020-07-14 02:07:01 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:07:41 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:07:41 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 00:07:41 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\add_simple.php 23
ERROR - 2020-07-14 00:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_simple.php 23
ERROR - 2020-07-14 00:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_simple.php 29
ERROR - 2020-07-14 02:07:41 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:07:50 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:07:50 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 00:07:50 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\application\views\admin\add_simple.php 23
ERROR - 2020-07-14 00:07:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_simple.php 23
ERROR - 2020-07-14 00:07:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_simple.php 29
ERROR - 2020-07-14 02:07:50 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:07:57 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:07:57 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 00:08:05 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:08:05 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 00:09:11 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:09:11 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 00:09:19 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:09:19 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 00:09:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_simple.php 29
ERROR - 2020-07-14 02:09:19 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:11:14 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:11:14 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 00:11:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_simple.php 29
ERROR - 2020-07-14 02:11:15 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:12:31 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:12:31 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 00:12:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_simple.php 29
ERROR - 2020-07-14 02:12:31 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:13:14 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:13:14 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 00:13:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_simple.php 29
ERROR - 2020-07-14 02:13:15 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:13:15 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:13:15 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 00:13:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_simple.php 29
ERROR - 2020-07-14 02:13:16 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:15:30 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:15:30 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 00:15:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_simple.php 34
ERROR - 2020-07-14 02:15:31 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:16:09 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:16:09 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 00:16:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_simple.php 23
ERROR - 2020-07-14 00:16:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_simple.php 34
ERROR - 2020-07-14 02:16:09 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:16:20 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:16:20 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 00:16:20 --> Severity: Notice --> Undefined index: question C:\xampp\htdocs\application\views\admin\add_simple.php 23
ERROR - 2020-07-14 00:16:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_simple.php 34
ERROR - 2020-07-14 02:16:21 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:16:22 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:16:22 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 00:16:22 --> Severity: Notice --> Undefined index: question C:\xampp\htdocs\application\views\admin\add_simple.php 23
ERROR - 2020-07-14 00:16:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_simple.php 34
ERROR - 2020-07-14 02:16:22 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:16:29 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:16:29 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 00:16:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_simple.php 34
ERROR - 2020-07-14 02:16:30 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:17:19 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:17:19 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 02:17:19 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:17:29 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:17:29 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 00:17:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\add_simple.php 23
ERROR - 2020-07-14 00:17:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_simple.php 23
ERROR - 2020-07-14 00:17:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\add_simple.php 34
ERROR - 2020-07-14 00:17:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_simple.php 34
ERROR - 2020-07-14 02:17:30 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:18:05 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:18:05 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 00:18:36 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:18:36 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 00:18:47 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:18:47 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 00:18:47 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\add_simple.php 23
ERROR - 2020-07-14 00:18:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_simple.php 23
ERROR - 2020-07-14 02:18:48 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:19:25 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:19:25 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 00:19:25 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\add_simple.php 23
ERROR - 2020-07-14 00:19:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_simple.php 23
ERROR - 2020-07-14 02:19:25 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:19:43 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:19:43 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 00:19:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\add_simple.php 23
ERROR - 2020-07-14 00:19:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_simple.php 23
ERROR - 2020-07-14 00:19:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\add_simple.php 33
ERROR - 2020-07-14 00:19:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_simple.php 33
ERROR - 2020-07-14 02:19:43 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:20:30 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:20:30 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 00:20:30 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\add_simple.php 23
ERROR - 2020-07-14 00:20:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_simple.php 23
ERROR - 2020-07-14 02:20:30 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:20:31 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:20:31 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 00:20:31 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\add_simple.php 23
ERROR - 2020-07-14 00:20:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_simple.php 23
ERROR - 2020-07-14 02:20:32 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:20:33 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:20:33 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 00:20:33 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\add_simple.php 23
ERROR - 2020-07-14 00:20:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_simple.php 23
ERROR - 2020-07-14 02:20:34 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:20:53 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:20:53 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 02:20:54 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:21:02 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:21:02 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 02:21:03 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:21:03 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:21:03 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 02:21:04 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:21:27 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:21:27 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 02:21:27 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:21:28 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:21:28 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 02:21:28 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:22:09 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:22:09 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 02:22:09 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:22:14 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:22:14 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 02:22:15 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:22:21 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:22:21 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 02:22:21 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:22:26 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:22:26 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 02:22:26 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:22:30 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:22:30 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 02:22:30 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:22:37 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:22:37 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 02:22:37 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:23:31 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:23:31 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 02:23:31 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:24:37 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:24:37 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 02:24:37 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:24:38 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:24:38 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 02:24:38 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:24:43 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:24:43 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 02:24:44 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:24:48 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:24:48 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 02:24:48 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:26:35 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:26:35 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 00:26:43 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:26:43 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 02:26:43 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:26:47 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:26:47 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 00:30:41 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:30:41 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 00:30:45 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:30:45 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 02:30:46 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:30:57 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:30:57 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 00:33:09 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:33:09 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 00:33:13 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:33:13 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 02:33:14 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:33:29 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:33:29 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 00:33:44 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:33:44 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 00:33:46 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:33:46 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 02:33:46 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:33:48 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:33:48 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 00:33:51 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:33:51 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 02:33:52 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:33:53 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:33:53 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 00:34:17 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:34:17 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 02:34:17 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:34:21 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:34:21 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 02:34:21 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:34:29 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:34:29 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 02:34:29 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:34:31 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:34:31 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 02:34:31 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:34:54 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:34:54 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 02:34:54 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:34:57 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:34:57 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 02:34:57 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:35:10 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\controllers\Admin.php 319
ERROR - 2020-07-14 00:35:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Admin.php 319
ERROR - 2020-07-14 00:35:10 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:35:10 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 00:36:37 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:36:37 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 02:36:37 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:36:45 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:36:45 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 02:36:46 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:36:52 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:36:52 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 02:36:53 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:42:08 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:42:08 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 02:42:08 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:42:18 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:42:18 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 02:42:19 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:42:21 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:42:21 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 02:42:22 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 00:42:25 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 00:42:25 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 02:42:25 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 03:20:40 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 03:20:40 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 05:20:40 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 03:39:10 --> Severity: error --> Exception: Call to a member function num_rows() on array C:\xampp\htdocs\application\controllers\Admin.php 292
ERROR - 2020-07-14 03:47:49 --> Severity: error --> Exception: Call to a member function num_rows() on array C:\xampp\htdocs\application\controllers\Admin.php 292
ERROR - 2020-07-14 03:48:34 --> Severity: Notice --> Undefined property: stdClass::$choice C:\xampp\htdocs\application\controllers\Admin.php 294
ERROR - 2020-07-14 03:48:34 --> Query error: Unknown column 'timestamp' in 'where clause' - Invalid query: SELECT *
FROM `tb_choice_question`
WHERE `timestamp` = '1594684800000'
ERROR - 2020-07-14 03:49:10 --> Severity: Notice --> Undefined property: stdClass::$choice C:\xampp\htdocs\application\controllers\Admin.php 294
ERROR - 2020-07-14 03:49:10 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 03:49:10 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 03:50:59 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 03:50:59 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 05:51:00 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 03:52:09 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 03:52:09 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 03:52:41 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 03:52:41 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 05:52:42 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 03:53:07 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 03:53:07 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 05:53:08 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 03:53:38 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\application\controllers\Admin.php 313
ERROR - 2020-07-14 03:53:38 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 03:53:38 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 03:53:47 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 03:53:47 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 03:54:34 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 03:54:34 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 03:55:00 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 03:55:00 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 03:55:15 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 03:55:15 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 05:55:16 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 03:55:33 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 03:55:33 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 03:55:45 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 03:55:45 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 03:57:01 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 03:57:01 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 03:57:18 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 03:57:18 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 03:59:27 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 03:59:27 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 03:59:58 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 03:59:58 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 05:59:58 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 04:00:00 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 04:00:00 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 04:00:05 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 04:00:05 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 06:00:05 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 04:00:08 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 04:00:08 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 06:00:08 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 04:01:31 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 04:01:31 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 06:01:32 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 04:01:35 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 04:01:35 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 06:01:35 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 04:05:19 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 04:05:19 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 06:05:19 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 04:05:53 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 04:05:53 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 06:05:53 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 04:06:07 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 04:06:07 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 04:06:13 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 04:06:13 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 06:06:13 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 04:06:56 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 04:06:56 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 06:58:29 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 06:58:29 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 01:58:29 --> Severity: Notice --> Undefined variable: category_id C:\xampp\htdocs\application\views\admin\add_choice.php 19
ERROR - 2020-07-14 01:58:29 --> Severity: Notice --> Undefined variable: category_title C:\xampp\htdocs\application\views\admin\add_choice.php 19
ERROR - 2020-07-14 01:58:29 --> Severity: Notice --> Undefined variable: category_id C:\xampp\htdocs\application\views\admin\add_choice.php 20
ERROR - 2020-07-14 06:58:55 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 06:58:55 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 01:58:55 --> Severity: Notice --> Undefined variable: category_id C:\xampp\htdocs\application\views\admin\add_choice.php 19
ERROR - 2020-07-14 07:02:57 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 07:02:57 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 02:02:57 --> Severity: Notice --> Undefined variable: category_title C:\xampp\htdocs\application\views\admin\add_choice.php 30
ERROR - 2020-07-14 02:02:57 --> Severity: Notice --> Undefined variable: category_id C:\xampp\htdocs\application\views\admin\add_choice.php 34
ERROR - 2020-07-14 07:03:28 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 07:03:28 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 02:03:28 --> Severity: Notice --> Undefined variable: category_id C:\xampp\htdocs\application\views\admin\add_choice.php 30
ERROR - 2020-07-14 07:06:25 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 07:06:25 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 02:06:25 --> Severity: Notice --> Undefined variable: choice_id C:\xampp\htdocs\application\views\admin\add_choice.php 30
ERROR - 2020-07-14 07:07:15 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 07:07:15 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 02:07:15 --> Severity: Notice --> Undefined variable: choice_id C:\xampp\htdocs\application\views\admin\add_choice.php 30
ERROR - 2020-07-14 07:08:25 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 07:08:25 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 07:08:32 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 07:08:32 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 07:09:15 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 07:09:15 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 02:09:15 --> Severity: Notice --> Undefined variable: fetchdata C:\xampp\htdocs\application\views\admin\add_choice.php 30
ERROR - 2020-07-14 02:09:15 --> Severity: Notice --> Undefined variable: choice_id C:\xampp\htdocs\application\views\admin\add_choice.php 30
ERROR - 2020-07-14 02:09:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_choice.php 30
ERROR - 2020-07-14 07:10:44 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 07:10:44 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 02:10:44 --> Severity: Notice --> Undefined variable: fetchdata C:\xampp\htdocs\application\views\admin\add_choice.php 30
ERROR - 2020-07-14 02:10:44 --> Severity: Notice --> Undefined variable: choice_id C:\xampp\htdocs\application\views\admin\add_choice.php 30
ERROR - 2020-07-14 02:10:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_choice.php 30
ERROR - 2020-07-14 07:11:37 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 07:11:37 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 02:11:37 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\add_choice.php 30
ERROR - 2020-07-14 02:11:37 --> Severity: Notice --> Undefined variable: choice_id C:\xampp\htdocs\application\views\admin\add_choice.php 30
ERROR - 2020-07-14 02:11:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_choice.php 30
ERROR - 2020-07-14 07:11:37 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\add_choice.php 50
ERROR - 2020-07-14 07:11:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_choice.php 50
ERROR - 2020-07-14 08:10:00 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 08:10:00 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 03:10:00 --> Severity: Notice --> Undefined variable: choice_id C:\xampp\htdocs\application\views\admin\add_choice.php 30
ERROR - 2020-07-14 03:10:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_choice.php 30
ERROR - 2020-07-14 08:10:00 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\add_choice.php 50
ERROR - 2020-07-14 08:10:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_choice.php 50
ERROR - 2020-07-14 08:10:13 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 08:10:13 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 03:10:13 --> Severity: Notice --> Undefined variable: choice_id C:\xampp\htdocs\application\views\admin\add_choice.php 30
ERROR - 2020-07-14 08:10:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\add_choice.php 50
ERROR - 2020-07-14 08:10:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_choice.php 50
ERROR - 2020-07-14 08:10:51 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 08:10:51 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 08:10:51 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\add_choice.php 50
ERROR - 2020-07-14 08:10:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_choice.php 50
ERROR - 2020-07-14 08:13:22 --> Severity: Notice --> Undefined index: fetchdata C:\xampp\htdocs\application\controllers\Admin.php 315
ERROR - 2020-07-14 08:13:22 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 08:13:22 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 03:13:22 --> Severity: Notice --> Undefined variable: fetchdata C:\xampp\htdocs\application\views\admin\add_choice.php 30
ERROR - 2020-07-14 08:15:15 --> Severity: Notice --> Undefined index: fetchdata C:\xampp\htdocs\application\controllers\Admin.php 315
ERROR - 2020-07-14 08:15:15 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 08:15:15 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 08:15:41 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 08:15:41 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 10:15:41 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 08:20:14 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 08:20:14 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 08:20:14 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\views\admin\add_choice.php 58
ERROR - 2020-07-14 08:20:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_choice.php 58
ERROR - 2020-07-14 10:20:15 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 08:21:39 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 08:21:39 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 10:21:39 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 08:21:43 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 08:21:43 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 03:21:43 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\simple_answer.php 52
ERROR - 2020-07-14 03:21:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-14 03:21:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-14 10:21:43 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 08:22:07 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 08:22:07 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 10:22:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 08:23:48 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 08:23:48 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 10:23:49 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 08:23:53 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 08:23:53 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 10:23:53 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 08:23:55 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 08:23:55 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 10:23:55 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 08:24:01 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 08:24:01 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 10:24:02 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 08:24:12 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 08:24:12 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 10:24:12 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 08:24:34 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 08:24:34 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 10:24:34 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 08:24:37 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 08:24:37 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 10:24:37 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 08:32:14 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 08:32:14 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 08:35:11 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 08:35:11 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 08:35:15 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 08:35:15 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 10:35:16 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 08:35:18 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 08:35:18 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 08:37:30 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 08:37:30 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 08:37:31 --> Severity: Notice --> Undefined index: timestamp C:\xampp\htdocs\application\controllers\Admin.php 343
ERROR - 2020-07-14 08:37:31 --> Query error: Unknown column 'choice_id' in 'field list' - Invalid query: INSERT INTO `tb_question` (`choice_id`) VALUES ('')
ERROR - 2020-07-14 08:37:32 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 08:37:32 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 08:37:42 --> Severity: Notice --> Undefined index: fetchdata C:\xampp\htdocs\application\controllers\Admin.php 315
ERROR - 2020-07-14 08:37:42 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 08:37:42 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 08:37:43 --> Severity: error --> Exception: Too few arguments to function Admin::add_choice_answer(), 0 passed in C:\xampp\htdocs\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\application\controllers\Admin.php 336
ERROR - 2020-07-14 08:38:05 --> Severity: Notice --> Undefined index: fetchdata C:\xampp\htdocs\application\controllers\Admin.php 315
ERROR - 2020-07-14 08:38:05 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 08:38:05 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 08:38:06 --> Severity: Notice --> Undefined index: fetchdata C:\xampp\htdocs\application\controllers\Admin.php 315
ERROR - 2020-07-14 08:38:06 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 08:38:06 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 08:38:07 --> Severity: error --> Exception: Too few arguments to function Admin::add_choice_answer(), 0 passed in C:\xampp\htdocs\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\application\controllers\Admin.php 336
ERROR - 2020-07-14 08:43:56 --> Severity: error --> Exception: Too few arguments to function Admin::add_choice_answer(), 0 passed in C:\xampp\htdocs\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\application\controllers\Admin.php 336
ERROR - 2020-07-14 08:43:58 --> Severity: Notice --> Undefined index: fetchdata C:\xampp\htdocs\application\controllers\Admin.php 315
ERROR - 2020-07-14 08:43:58 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 08:43:58 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 08:43:59 --> Severity: error --> Exception: Too few arguments to function Admin::add_choice_answer(), 0 passed in C:\xampp\htdocs\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\application\controllers\Admin.php 336
ERROR - 2020-07-14 08:44:19 --> Severity: error --> Exception: Too few arguments to function Admin::add_choice_answer(), 0 passed in C:\xampp\htdocs\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\application\controllers\Admin.php 336
ERROR - 2020-07-14 08:44:20 --> Severity: Notice --> Undefined index: fetchdata C:\xampp\htdocs\application\controllers\Admin.php 315
ERROR - 2020-07-14 08:44:20 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 08:44:20 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 08:44:22 --> Severity: error --> Exception: Too few arguments to function Admin::add_choice_answer(), 0 passed in C:\xampp\htdocs\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\application\controllers\Admin.php 336
ERROR - 2020-07-14 08:44:23 --> Severity: Notice --> Undefined index: fetchdata C:\xampp\htdocs\application\controllers\Admin.php 315
ERROR - 2020-07-14 08:44:23 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 08:44:23 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 08:44:25 --> Severity: Notice --> Undefined index: fetchdata C:\xampp\htdocs\application\controllers\Admin.php 315
ERROR - 2020-07-14 08:44:25 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 08:44:25 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 08:44:26 --> Severity: error --> Exception: Too few arguments to function Admin::add_choice_answer(), 0 passed in C:\xampp\htdocs\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\application\controllers\Admin.php 336
ERROR - 2020-07-14 08:45:00 --> Severity: Notice --> Undefined index: fetchdata C:\xampp\htdocs\application\controllers\Admin.php 315
ERROR - 2020-07-14 08:45:00 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 08:45:00 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 08:45:02 --> Severity: Notice --> Undefined index: fetchdata C:\xampp\htdocs\application\controllers\Admin.php 315
ERROR - 2020-07-14 08:45:02 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 08:45:02 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 08:45:04 --> Severity: Notice --> Undefined index: fetchdata C:\xampp\htdocs\application\controllers\Admin.php 315
ERROR - 2020-07-14 08:45:04 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 08:45:04 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 08:45:06 --> Severity: Notice --> Undefined index: fetchdata C:\xampp\htdocs\application\controllers\Admin.php 315
ERROR - 2020-07-14 08:45:06 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 08:45:06 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 08:45:14 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 08:45:14 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 08:45:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\application\controllers\Admin.php 342
ERROR - 2020-07-14 08:45:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\application\controllers\Admin.php 348
ERROR - 2020-07-14 08:45:20 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 08:45:20 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 08:45:27 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\application\controllers\Admin.php 342
ERROR - 2020-07-14 08:45:27 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\application\controllers\Admin.php 348
ERROR - 2020-07-14 08:45:36 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 08:45:36 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 08:49:55 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 08:49:55 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 08:49:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_choice.php 84
ERROR - 2020-07-14 08:49:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_choice.php 85
ERROR - 2020-07-14 08:49:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_choice.php 86
ERROR - 2020-07-14 08:49:55 --> Severity: Notice --> Undefined variable: category_id C:\xampp\htdocs\application\views\admin\add_choice.php 86
ERROR - 2020-07-14 08:49:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_choice.php 87
ERROR - 2020-07-14 08:49:55 --> Severity: Notice --> Undefined variable: category_id C:\xampp\htdocs\application\views\admin\add_choice.php 87
ERROR - 2020-07-14 08:50:58 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 08:50:58 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 08:50:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_choice.php 85
ERROR - 2020-07-14 08:50:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_choice.php 86
ERROR - 2020-07-14 08:50:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_choice.php 87
ERROR - 2020-07-14 08:50:58 --> Severity: Notice --> Undefined variable: category_id C:\xampp\htdocs\application\views\admin\add_choice.php 87
ERROR - 2020-07-14 08:50:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_choice.php 88
ERROR - 2020-07-14 08:50:58 --> Severity: Notice --> Undefined variable: category_id C:\xampp\htdocs\application\views\admin\add_choice.php 88
ERROR - 2020-07-14 09:04:04 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:04:04 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 09:04:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_choice.php 85
ERROR - 2020-07-14 09:04:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_choice.php 86
ERROR - 2020-07-14 09:04:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_choice.php 87
ERROR - 2020-07-14 09:04:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_choice.php 92
ERROR - 2020-07-14 09:04:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_choice.php 95
ERROR - 2020-07-14 09:04:36 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:04:36 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 04:04:36 --> Severity: error --> Exception: syntax error, unexpected '"/admin/edit_choiceanswer;?>"' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' C:\xampp\htdocs\application\views\admin\add_choice.php 90
ERROR - 2020-07-14 09:05:10 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:05:10 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 09:05:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_choice.php 85
ERROR - 2020-07-14 09:05:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_choice.php 86
ERROR - 2020-07-14 09:05:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_choice.php 87
ERROR - 2020-07-14 09:05:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_choice.php 92
ERROR - 2020-07-14 09:05:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_choice.php 95
ERROR - 2020-07-14 09:05:46 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:05:46 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 09:05:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_choice.php 85
ERROR - 2020-07-14 09:05:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_choice.php 86
ERROR - 2020-07-14 09:05:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_choice.php 87
ERROR - 2020-07-14 09:05:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_choice.php 92
ERROR - 2020-07-14 09:05:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_choice.php 95
ERROR - 2020-07-14 09:06:11 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:06:11 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 04:06:11 --> Severity: error --> Exception: syntax error, unexpected ''admin/edit_choiceanswer'' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' C:\xampp\htdocs\application\views\admin\add_choice.php 90
ERROR - 2020-07-14 09:07:03 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:07:03 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 09:07:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_choice.php 85
ERROR - 2020-07-14 09:07:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_choice.php 86
ERROR - 2020-07-14 09:07:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_choice.php 87
ERROR - 2020-07-14 09:07:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_choice.php 92
ERROR - 2020-07-14 09:07:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_choice.php 95
ERROR - 2020-07-14 09:07:09 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:07:09 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 04:07:09 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\report.php 52
ERROR - 2020-07-14 11:07:10 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:07:11 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:07:11 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 09:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_choice.php 85
ERROR - 2020-07-14 09:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_choice.php 86
ERROR - 2020-07-14 09:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_choice.php 87
ERROR - 2020-07-14 09:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_choice.php 92
ERROR - 2020-07-14 09:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_choice.php 95
ERROR - 2020-07-14 09:09:42 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:09:42 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 09:09:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_choice.php 86
ERROR - 2020-07-14 09:09:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_choice.php 87
ERROR - 2020-07-14 09:09:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_choice.php 88
ERROR - 2020-07-14 09:09:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\add_choice.php 91
ERROR - 2020-07-14 09:10:48 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:10:48 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 09:13:32 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:13:32 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 09:14:45 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:14:45 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 09:14:47 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:14:47 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 09:14:53 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:14:53 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 09:15:20 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:15:20 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:15:21 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:16:02 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:16:02 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 09:16:02 --> Severity: Notice --> Undefined variable: fetchdata C:\xampp\htdocs\application\views\admin\add_choice.php 83
ERROR - 2020-07-14 09:16:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\add_choice.php 83
ERROR - 2020-07-14 11:16:03 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:17:35 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:17:35 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:17:36 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:18:25 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:18:25 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:18:25 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:18:40 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:18:40 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:18:40 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:18:44 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:18:44 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:18:44 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:18:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\application\controllers\Admin.php 342
ERROR - 2020-07-14 09:18:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\application\controllers\Admin.php 348
ERROR - 2020-07-14 09:18:47 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:18:47 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:18:47 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:19:08 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:19:08 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:19:08 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:25:41 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:25:41 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:25:42 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:25:43 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:25:43 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:25:43 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:25:44 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:25:44 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:25:44 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:25:51 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:25:51 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:25:52 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:25:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\application\controllers\Admin.php 342
ERROR - 2020-07-14 09:25:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\application\controllers\Admin.php 348
ERROR - 2020-07-14 09:25:54 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:25:54 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:25:55 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:25:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\application\controllers\Admin.php 342
ERROR - 2020-07-14 09:25:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\application\controllers\Admin.php 348
ERROR - 2020-07-14 09:28:30 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:28:30 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 09:28:30 --> Severity: Notice --> Undefined property: stdClass::$category_id C:\xampp\htdocs\application\views\admin\add_choice.php 90
ERROR - 2020-07-14 09:28:30 --> Severity: Notice --> Undefined property: stdClass::$category_id C:\xampp\htdocs\application\views\admin\add_choice.php 90
ERROR - 2020-07-14 11:28:31 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:29:11 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:29:11 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:29:12 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:29:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\application\controllers\Admin.php 342
ERROR - 2020-07-14 09:29:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\application\controllers\Admin.php 348
ERROR - 2020-07-14 09:29:15 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:29:15 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:29:15 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:29:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\application\controllers\Admin.php 342
ERROR - 2020-07-14 09:29:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\application\controllers\Admin.php 348
ERROR - 2020-07-14 09:29:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\application\controllers\Admin.php 342
ERROR - 2020-07-14 09:29:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\application\controllers\Admin.php 348
ERROR - 2020-07-14 09:29:41 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:29:41 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:29:41 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:29:42 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:29:42 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:29:42 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:29:50 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:29:50 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:29:50 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:29:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\application\controllers\Admin.php 342
ERROR - 2020-07-14 09:29:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\application\controllers\Admin.php 348
ERROR - 2020-07-14 09:29:52 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:29:52 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:29:52 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:30:06 --> Severity: Notice --> Undefined variable: choice_id C:\xampp\htdocs\application\controllers\Admin.php 357
ERROR - 2020-07-14 09:30:06 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:30:06 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:30:06 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:30:07 --> Severity: Notice --> Undefined variable: choice_id C:\xampp\htdocs\application\controllers\Admin.php 357
ERROR - 2020-07-14 09:30:08 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:30:08 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:30:08 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:33:13 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:33:13 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:33:14 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:33:16 --> Query error: Unknown column 'choice_answer_id' in 'field list' - Invalid query: UPDATE `tb_choice_question` SET `choice_answer_id` = '3', `question` = 'Second Choice answer11'
WHERE `id` = '3'
ERROR - 2020-07-14 09:34:05 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:34:05 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:34:06 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:34:08 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:34:08 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:34:08 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:34:18 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:34:18 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:34:19 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:34:21 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:34:21 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:34:22 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:34:28 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:34:28 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:34:28 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:34:32 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:34:32 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:34:32 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:36:56 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:36:56 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:36:56 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:36:59 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:36:59 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:37:00 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:37:20 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:37:20 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:37:20 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:37:23 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:37:23 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:37:23 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:37:37 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:37:37 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:37:38 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:37:39 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:37:39 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:37:39 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:37:44 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:37:44 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:37:44 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:37:47 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:37:47 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:37:47 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:38:03 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:38:03 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:38:04 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:38:06 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:38:06 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:38:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:38:10 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:38:10 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:38:11 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:38:16 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:38:16 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:38:17 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:43:21 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:43:21 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:43:22 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:43:22 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:43:22 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:43:22 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:44:47 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:44:47 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:44:48 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:44:57 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:44:57 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:44:57 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:45:01 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:45:01 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:45:02 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:45:04 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:45:04 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:45:04 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:45:26 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:45:26 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:45:27 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:45:41 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:45:41 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:45:42 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:45:59 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:45:59 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:45:59 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:46:44 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:46:44 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:46:44 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:55:26 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:55:26 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:55:26 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:55:27 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:55:27 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:55:27 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:55:31 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:55:31 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:55:32 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:55:35 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:55:35 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:55:35 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:55:42 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:55:42 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:55:42 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:56:57 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:56:57 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:56:58 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:57:03 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:57:03 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:57:03 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:57:07 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:57:07 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:57:08 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:57:10 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:57:10 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:57:11 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:57:14 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:57:14 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:57:14 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:57:33 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:57:33 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:57:34 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:57:37 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:57:37 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:57:37 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:57:40 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:57:40 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 11:57:40 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:58:04 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:58:04 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 04:58:04 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\simple_answer.php 52
ERROR - 2020-07-14 04:58:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-14 04:58:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-14 11:58:05 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 09:58:08 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\controllers\Admin.php 439
ERROR - 2020-07-14 09:58:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Admin.php 439
ERROR - 2020-07-14 09:58:08 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:58:08 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 04:58:08 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\multiple_answer.php 52
ERROR - 2020-07-14 04:58:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-14 04:58:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-14 04:58:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-14 09:59:49 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 09:59:49 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 04:59:49 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\multiple_answer.php 52
ERROR - 2020-07-14 04:59:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-14 04:59:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-14 04:59:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-14 11:59:50 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 10:00:23 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 10:00:23 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 05:00:23 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\simple_answer.php 52
ERROR - 2020-07-14 05:00:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-14 05:00:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-14 12:00:24 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 10:00:25 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 10:00:25 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 05:00:25 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\multiple_answer.php 52
ERROR - 2020-07-14 05:00:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-14 05:00:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-14 05:00:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-14 12:00:26 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 10:00:37 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 10:00:37 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 05:00:37 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\simple_answer.php 52
ERROR - 2020-07-14 05:00:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-14 05:00:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-14 12:00:38 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 10:00:39 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 10:00:39 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 05:00:39 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\mask.php 52
ERROR - 2020-07-14 12:00:40 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 10:00:40 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 10:00:40 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 05:00:40 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\apply.php 52
ERROR - 2020-07-14 12:00:40 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 10:02:57 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 10:02:57 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 05:02:57 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\apply.php 52
ERROR - 2020-07-14 12:02:57 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 10:03:00 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 10:03:00 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 05:03:00 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\apply.php 52
ERROR - 2020-07-14 12:03:00 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 10:03:01 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 10:03:01 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 05:03:01 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\volunteer.php 52
ERROR - 2020-07-14 12:03:01 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 10:03:02 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 10:03:02 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 05:03:02 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\agency.php 52
ERROR - 2020-07-14 12:03:02 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 10:03:03 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 10:03:03 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 05:03:03 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\report.php 52
ERROR - 2020-07-14 12:03:03 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 10:03:04 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 10:03:04 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 12:03:04 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 10:03:14 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 10:03:14 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 12:03:15 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 10:03:16 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 10:03:16 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 05:03:16 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-14 12:03:16 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 10:03:18 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 10:03:18 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 12:03:18 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 10:03:19 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 10:03:19 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 05:03:19 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-14 12:03:19 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 10:03:20 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 10:03:20 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 12:03:21 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 10:03:22 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 10:03:22 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 05:03:22 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\report.php 52
ERROR - 2020-07-14 12:03:22 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 10:03:23 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 10:03:23 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 05:03:23 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\volunteer.php 52
ERROR - 2020-07-14 12:03:24 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 10:03:25 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 10:03:25 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 05:03:25 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\volunteer.php 52
ERROR - 2020-07-14 12:03:25 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 10:03:25 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 10:03:25 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 05:03:25 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\apply.php 52
ERROR - 2020-07-14 12:03:26 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 10:03:26 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 10:03:26 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 05:03:26 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\agency.php 52
ERROR - 2020-07-14 12:03:26 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 10:03:28 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 10:03:28 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 05:03:28 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\money.php 52
ERROR - 2020-07-14 12:03:28 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 10:03:29 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 10:03:29 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 05:03:29 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\mask.php 52
ERROR - 2020-07-14 12:03:29 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 10:03:33 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 10:03:33 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 05:03:33 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\simple_answer.php 52
ERROR - 2020-07-14 05:03:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-14 05:03:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\simple_answer.php 74
ERROR - 2020-07-14 12:03:33 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 10:03:36 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 10:03:36 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 05:03:36 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\multiple_answer.php 52
ERROR - 2020-07-14 05:03:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-14 05:03:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-14 05:03:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\views\admin\multiple_answer.php 74
ERROR - 2020-07-14 12:03:36 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 10:03:37 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 10:03:37 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 12:03:38 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 10:03:43 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 10:03:43 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 12:03:43 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 10:03:52 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 10:03:52 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 12:03:52 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 10:03:55 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 10:03:55 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 05:03:55 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\users.php 54
ERROR - 2020-07-14 12:03:55 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 10:04:00 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 10:04:00 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 12:04:00 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 10:04:02 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 10:04:02 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 05:04:02 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\report.php 52
ERROR - 2020-07-14 12:04:02 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 10:04:06 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 10:04:06 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 05:04:06 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\volunteer.php 52
ERROR - 2020-07-14 12:04:06 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 10:04:08 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 10:04:08 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 05:04:08 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\apply.php 52
ERROR - 2020-07-14 12:04:09 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 10:04:10 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 10:04:10 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 05:04:10 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\agency.php 52
ERROR - 2020-07-14 12:04:11 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 10:04:15 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 10:04:15 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 05:04:15 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\money.php 52
ERROR - 2020-07-14 12:04:15 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 10:04:18 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 10:04:18 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 05:04:18 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\admin\mask.php 52
ERROR - 2020-07-14 12:04:18 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 10:04:47 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 10:04:47 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 12:04:47 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 10:04:55 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 10:04:55 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 12:04:55 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 10:04:57 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-14 10:04:57 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-14 12:04:57 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-14 12:51:49 --> 404 Page Not Found: HNAP1/index
