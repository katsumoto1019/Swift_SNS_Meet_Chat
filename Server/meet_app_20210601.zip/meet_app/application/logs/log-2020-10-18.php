<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-18 01:08:13 --> 404 Page Not Found: Env/index
ERROR - 2020-10-18 01:16:47 --> 404 Page Not Found: Env/index
ERROR - 2020-10-18 01:16:48 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-10-18 06:52:25 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-10-18 06:52:26 --> 404 Page Not Found: 404javascriptjs/index
