<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-24 16:36:35 --> 404 Page Not Found: Env/index
ERROR - 2020-09-24 16:36:36 --> 404 Page Not Found: Env/index
ERROR - 2020-09-24 16:36:38 --> 404 Page Not Found: Admin/.env
ERROR - 2020-09-24 16:36:39 --> 404 Page Not Found: Admin/.env
ERROR - 2020-09-24 16:36:40 --> 404 Page Not Found: Laravel/.env
ERROR - 2020-09-24 16:36:42 --> 404 Page Not Found: Laravel/.env
ERROR - 2020-09-24 16:36:42 --> 404 Page Not Found: Public/.env
ERROR - 2020-09-24 16:36:43 --> 404 Page Not Found: Public/.env
ERROR - 2020-09-24 16:36:45 --> 404 Page Not Found: V1/.env
ERROR - 2020-09-24 16:36:46 --> 404 Page Not Found: V1/.env
ERROR - 2020-09-24 16:36:46 --> 404 Page Not Found: App/.env
ERROR - 2020-09-24 16:36:50 --> 404 Page Not Found: App/.env
ERROR - 2020-09-24 16:36:50 --> 404 Page Not Found: Config/.env
