<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-04 07:47:37 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-03-04 07:47:37 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-03-04 08:30:51 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-03-04 08:31:22 --> 404 Page Not Found: Blog/wp_login.php
ERROR - 2021-03-04 08:31:22 --> 404 Page Not Found: Wp/wp_login.php
ERROR - 2021-03-04 18:00:47 --> 404 Page Not Found: Wordpress/wp_login.php
ERROR - 2021-03-04 18:01:17 --> 404 Page Not Found: Wp/wp_login.php
ERROR - 2021-03-04 19:36:00 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-03-04 22:42:06 --> 404 Page Not Found: Robotstxt/index
