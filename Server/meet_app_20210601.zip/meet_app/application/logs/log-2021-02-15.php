<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-15 02:25:05 --> 404 Page Not Found: Env/index
ERROR - 2021-02-15 07:43:22 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-02-15 07:43:23 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-02-15 13:42:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-02-15 14:52:10 --> 404 Page Not Found: Js/admin.js
