<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-11 01:01:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-11 01:09:43 --> 404 Page Not Found: Wp_content/db_cache.php
ERROR - 2021-05-11 05:51:30 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2021-05-11 06:32:33 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-05-11 06:32:34 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-05-11 07:50:37 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-05-11 14:38:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-11 22:06:44 --> 404 Page Not Found: Robotstxt/index
