<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-27 05:55:16 --> 404 Page Not Found: Public/assets
ERROR - 2021-03-27 06:40:17 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-03-27 06:40:18 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-03-27 15:02:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-03-27 18:59:08 --> 404 Page Not Found: Public/assets
ERROR - 2021-03-27 19:03:09 --> 404 Page Not Found: Dup_installer/main.installer.php
