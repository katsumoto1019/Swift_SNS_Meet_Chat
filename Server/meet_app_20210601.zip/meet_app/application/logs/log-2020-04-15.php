<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-15 02:59:27 --> Severity: Notice --> Undefined index: deviceType C:\xampp\htdocs\application\controllers\Api.php 1306
ERROR - 2020-04-15 02:59:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '= '123123123123123deeeeeeerrr234'' at line 4 - Invalid query: SELECT *
FROM `tb_device`
WHERE `user_id` = '23423'
AND   = '123123123123123deeeeeeerrr234'
