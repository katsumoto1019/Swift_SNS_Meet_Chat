<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-26 16:51:34 --> 404 Page Not Found: Robotstxt/index
