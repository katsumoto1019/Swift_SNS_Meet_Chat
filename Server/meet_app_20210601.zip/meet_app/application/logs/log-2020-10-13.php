<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-13 06:49:32 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-10-13 06:49:32 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-10-13 12:30:28 --> 404 Page Not Found: Robotstxt/index
