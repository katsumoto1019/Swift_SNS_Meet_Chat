<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-22 01:24:03 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-05-22 01:24:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-05-22 02:24:06 --> 404 Page Not Found: Assets/admin
ERROR - 2020-05-22 02:24:09 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-05-22 01:25:01 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-05-22 01:25:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-05-22 02:25:01 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-05-22 02:25:09 --> 404 Page Not Found: Admin/update_password
ERROR - 2020-05-22 02:26:03 --> 404 Page Not Found: Admin/update_password
ERROR - 2020-05-22 01:26:06 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-05-22 01:26:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-05-22 02:26:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-05-22 02:26:10 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-05-22 01:27:28 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-05-22 01:27:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-05-22 02:27:29 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-05-22 01:28:13 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-05-22 01:28:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-05-22 02:28:13 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-05-22 02:28:15 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-05-22 01:28:30 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-05-22 01:28:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-05-22 02:28:30 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-05-22 01:28:39 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-05-22 01:28:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-05-22 02:28:39 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-05-22 02:28:41 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-05-22 02:28:47 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-05-22 02:29:08 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-05-22 01:29:13 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-05-22 01:29:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-05-22 02:29:14 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-05-22 02:29:15 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-05-22 02:31:38 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-05-22 01:31:41 --> Query error: Table 'learnme.tb_samplebreakfast' doesn't exist - Invalid query: SELECT *
FROM `tb_samplebreakfast`
ORDER BY `id` ASC
ERROR - 2020-05-22 02:31:43 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-05-22 01:31:44 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-05-22 01:31:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-05-22 02:31:45 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-05-22 02:31:49 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-05-22 02:31:55 --> 404 Page Not Found: Manifestjson/index
