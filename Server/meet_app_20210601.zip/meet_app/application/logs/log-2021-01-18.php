<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-18 01:28:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-01-18 07:51:12 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-01-18 07:51:12 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-01-18 11:32:54 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-01-18 11:32:54 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-01-18 16:21:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-01-18 21:23:25 --> 404 Page Not Found: Robotstxt/index
