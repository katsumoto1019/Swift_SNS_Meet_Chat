<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-07 01:39:11 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-10-07 06:55:13 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-10-07 06:55:14 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-10-07 12:48:21 --> 404 Page Not Found: Wp_includes/wlwmanifest.xml
ERROR - 2020-10-07 12:48:21 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2020-10-07 12:48:23 --> 404 Page Not Found: Blog/wp_includes
ERROR - 2020-10-07 12:48:23 --> 404 Page Not Found: Web/wp_includes
ERROR - 2020-10-07 12:48:24 --> 404 Page Not Found: Wordpress/wp_includes
ERROR - 2020-10-07 12:48:25 --> 404 Page Not Found: Website/wp_includes
ERROR - 2020-10-07 12:48:25 --> 404 Page Not Found: Wp/wp_includes
ERROR - 2020-10-07 12:48:25 --> 404 Page Not Found: News/wp_includes
ERROR - 2020-10-07 12:48:26 --> 404 Page Not Found: 2018/wp_includes
ERROR - 2020-10-07 12:48:27 --> 404 Page Not Found: 2019/wp_includes
ERROR - 2020-10-07 12:48:27 --> 404 Page Not Found: Shop/wp_includes
ERROR - 2020-10-07 12:48:28 --> 404 Page Not Found: Wp1/wp_includes
ERROR - 2020-10-07 12:48:29 --> 404 Page Not Found: Test/wp_includes
ERROR - 2020-10-07 12:48:29 --> 404 Page Not Found: Media/wp_includes
ERROR - 2020-10-07 12:48:29 --> 404 Page Not Found: Wp2/wp_includes
ERROR - 2020-10-07 12:48:29 --> 404 Page Not Found: Site/wp_includes
ERROR - 2020-10-07 12:48:30 --> 404 Page Not Found: Cms/wp_includes
ERROR - 2020-10-07 12:48:30 --> 404 Page Not Found: Sito/wp_includes
ERROR - 2020-10-07 22:07:16 --> 404 Page Not Found: Wp_admin/setup_config.php
ERROR - 2020-10-07 22:07:17 --> 404 Page Not Found: Wp_admin/install.php
