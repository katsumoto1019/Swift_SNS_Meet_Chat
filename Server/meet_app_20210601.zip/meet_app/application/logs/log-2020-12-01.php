<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-01 07:43:56 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-12-01 07:43:57 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-12-01 11:36:46 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-12-01 21:22:54 --> 404 Page Not Found: Robotstxt/index
