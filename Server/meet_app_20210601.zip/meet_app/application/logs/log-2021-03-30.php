<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-30 06:45:48 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-03-30 06:45:49 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-03-30 08:56:42 --> 404 Page Not Found: Assets/admin
ERROR - 2021-03-30 20:17:54 --> 404 Page Not Found: Assets/admin
ERROR - 2021-03-30 22:01:08 --> 404 Page Not Found: Wp_includes/wlwmanifest.xml
ERROR - 2021-03-30 22:01:08 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2021-03-30 22:01:08 --> 404 Page Not Found: Blog/wp_includes
ERROR - 2021-03-30 22:01:08 --> 404 Page Not Found: Web/wp_includes
ERROR - 2021-03-30 22:01:09 --> 404 Page Not Found: Wordpress/wp_includes
ERROR - 2021-03-30 22:01:09 --> 404 Page Not Found: Website/wp_includes
ERROR - 2021-03-30 22:01:09 --> 404 Page Not Found: Wp/wp_includes
ERROR - 2021-03-30 22:01:09 --> 404 Page Not Found: News/wp_includes
ERROR - 2021-03-30 22:01:09 --> 404 Page Not Found: 2018/wp_includes
ERROR - 2021-03-30 22:01:09 --> 404 Page Not Found: 2019/wp_includes
ERROR - 2021-03-30 22:01:09 --> 404 Page Not Found: Shop/wp_includes
ERROR - 2021-03-30 22:01:09 --> 404 Page Not Found: Wp1/wp_includes
ERROR - 2021-03-30 22:01:09 --> 404 Page Not Found: Test/wp_includes
ERROR - 2021-03-30 22:01:10 --> 404 Page Not Found: Media/wp_includes
ERROR - 2021-03-30 22:01:10 --> 404 Page Not Found: Wp2/wp_includes
ERROR - 2021-03-30 22:01:10 --> 404 Page Not Found: Site/wp_includes
ERROR - 2021-03-30 22:01:10 --> 404 Page Not Found: Cms/wp_includes
ERROR - 2021-03-30 22:01:10 --> 404 Page Not Found: Sito/wp_includes
