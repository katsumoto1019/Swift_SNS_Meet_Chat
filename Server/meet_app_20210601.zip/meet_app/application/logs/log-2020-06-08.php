<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-08 00:32:56 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-06-08 00:38:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-08 00:38:15 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2020-06-08 00:58:59 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-06-08 00:58:59 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-06-08 03:15:19 --> 404 Page Not Found: Wp_includes/seo_script.php
ERROR - 2020-06-08 03:51:26 --> 404 Page Not Found: Wp_admin/newsr.php
ERROR - 2020-06-08 04:09:04 --> 404 Page Not Found: Api/submitFCM
ERROR - 2020-06-08 04:09:07 --> 404 Page Not Found: Api/mkContact
ERROR - 2020-06-08 05:57:58 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-06-08 16:39:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-08 16:40:01 --> 404 Page Not Found: Feed/index
ERROR - 2020-06-08 18:06:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-06-08 18:06:18 --> 404 Page Not Found: Privacy_policy_learnme/index
ERROR - 2020-06-08 18:11:45 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-06-08 18:11:53 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-06-08 18:24:32 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-06-08 20:35:53 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-06-08 21:53:12 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-06-08 23:06:23 --> 404 Page Not Found: Wp_feedphp/index
