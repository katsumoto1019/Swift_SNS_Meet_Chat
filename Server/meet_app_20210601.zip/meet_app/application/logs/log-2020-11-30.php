<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-30 07:45:32 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-11-30 07:45:33 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-11-30 14:46:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-30 19:20:48 --> 404 Page Not Found: Robotstxt/index
