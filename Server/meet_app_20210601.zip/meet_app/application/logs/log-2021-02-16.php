<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-16 00:29:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-02-16 07:46:43 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-02-16 07:46:43 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-02-16 11:43:51 --> 404 Page Not Found: Env/index
