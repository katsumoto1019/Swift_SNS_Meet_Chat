<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-05 06:41:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-02-05 07:44:55 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-02-05 07:44:56 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-02-05 17:13:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-02-05 17:17:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-02-05 19:03:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-02-05 22:47:30 --> 404 Page Not Found: Wp_loginphp/index
