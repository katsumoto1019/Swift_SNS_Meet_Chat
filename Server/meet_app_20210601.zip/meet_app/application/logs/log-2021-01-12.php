<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-12 01:11:34 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-01-12 07:49:55 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-01-12 07:49:55 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-01-12 08:52:12 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-01-12 08:52:13 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-01-12 08:52:13 --> 404 Page Not Found: PhpMyAdmin/index.php
ERROR - 2021-01-12 08:52:13 --> 404 Page Not Found: Pma/index.php
ERROR - 2021-01-12 08:52:14 --> 404 Page Not Found: Phpmyadmin/index.php
ERROR - 2021-01-12 16:58:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-01-12 17:41:18 --> 404 Page Not Found: Wp_loginphp/index
