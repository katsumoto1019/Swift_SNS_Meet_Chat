<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-03 00:51:56 --> Severity: Notice --> Undefined variable: workoutvideos C:\xampp\htdocs\application\controllers\Api.php 625
ERROR - 2020-03-03 00:51:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Api.php 625
