<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-26 06:51:16 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-10-26 06:51:17 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-10-26 12:09:01 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-10-26 16:53:55 --> 404 Page Not Found: Robotstxt/index
