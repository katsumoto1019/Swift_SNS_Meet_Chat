<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-26 01:08:26 --> 404 Page Not Found: Env/index
ERROR - 2021-02-26 03:50:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-02-26 03:50:22 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-02-26 03:50:23 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-02-26 07:50:07 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-02-26 07:50:07 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-02-26 08:20:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-02-26 13:50:29 --> 404 Page Not Found: Wp_loginphp/index
