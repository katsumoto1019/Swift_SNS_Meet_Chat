<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-19 13:06:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-08-19 13:06:52 --> 404 Page Not Found: Sitemapxml/index
