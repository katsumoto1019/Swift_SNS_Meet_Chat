<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-04 06:42:26 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-04-04 06:42:27 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-04-04 08:33:09 --> 404 Page Not Found: Wp_content/db_cache.php
ERROR - 2021-04-04 12:40:24 --> 404 Page Not Found: _ignition/health_check
ERROR - 2021-04-04 16:56:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-04-04 22:24:34 --> 404 Page Not Found: Robotstxt/index
