<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-01 03:22:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-03-01 07:44:29 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-03-01 07:44:30 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-03-01 12:56:41 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-03-01 12:56:41 --> 404 Page Not Found: Wordpress/wp_login.php
ERROR - 2021-03-01 12:56:42 --> 404 Page Not Found: Blog/wp_login.php
ERROR - 2021-03-01 14:09:24 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-03-01 14:20:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-03-01 15:13:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-03-01 16:38:32 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-03-01 17:37:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-03-01 19:19:45 --> 404 Page Not Found: Robotstxt/index
