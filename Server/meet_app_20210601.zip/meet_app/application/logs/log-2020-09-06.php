<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-06 14:59:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-09-06 14:59:17 --> 404 Page Not Found: Humanstxt/index
ERROR - 2020-09-06 14:59:17 --> 404 Page Not Found: Adstxt/index
ERROR - 2020-09-06 15:00:44 --> 404 Page Not Found: Wp_admin/install.php
ERROR - 2020-09-06 22:54:07 --> 404 Page Not Found: Android_icon_192x192png/index
