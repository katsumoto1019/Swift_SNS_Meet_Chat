<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-27 21:47:54 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-09-27 21:49:10 --> 404 Page Not Found: Wp_content/plugins
