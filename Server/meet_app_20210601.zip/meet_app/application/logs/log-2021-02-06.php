<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-06 05:45:20 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-02-06 05:45:21 --> 404 Page Not Found: Wordpress/wp_login.php
ERROR - 2021-02-06 05:45:21 --> 404 Page Not Found: Blog/wp_login.php
ERROR - 2021-02-06 05:45:22 --> 404 Page Not Found: Wp/wp_login.php
ERROR - 2021-02-06 07:48:31 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-02-06 07:48:32 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-02-06 21:09:34 --> 404 Page Not Found: Robotstxt/index
