<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-10 01:04:28 --> Severity: error --> Exception: syntax error, unexpected '$result' (T_VARIABLE) /home/kmfjwp39rnql/public_html/application/controllers/Api.php 494
ERROR - 2020-10-10 01:07:46 --> Severity: Compile Error --> Cannot use temporary expression in write context /home/kmfjwp39rnql/public_html/application/controllers/Api.php 705
ERROR - 2020-10-10 05:40:27 --> 404 Page Not Found: Wp_includes/wlwmanifest.xml
ERROR - 2020-10-10 05:40:27 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2020-10-10 05:40:28 --> 404 Page Not Found: Blog/wp_includes
ERROR - 2020-10-10 05:40:28 --> 404 Page Not Found: Web/wp_includes
ERROR - 2020-10-10 05:40:29 --> 404 Page Not Found: Wordpress/wp_includes
ERROR - 2020-10-10 05:40:29 --> 404 Page Not Found: Website/wp_includes
ERROR - 2020-10-10 05:40:29 --> 404 Page Not Found: Wp/wp_includes
ERROR - 2020-10-10 05:40:30 --> 404 Page Not Found: News/wp_includes
ERROR - 2020-10-10 05:40:30 --> 404 Page Not Found: 2018/wp_includes
ERROR - 2020-10-10 05:40:30 --> 404 Page Not Found: 2019/wp_includes
ERROR - 2020-10-10 05:40:31 --> 404 Page Not Found: Shop/wp_includes
ERROR - 2020-10-10 05:40:31 --> 404 Page Not Found: Wp1/wp_includes
ERROR - 2020-10-10 05:40:31 --> 404 Page Not Found: Test/wp_includes
ERROR - 2020-10-10 05:40:31 --> 404 Page Not Found: Media/wp_includes
ERROR - 2020-10-10 05:40:32 --> 404 Page Not Found: Wp2/wp_includes
ERROR - 2020-10-10 05:40:32 --> 404 Page Not Found: Site/wp_includes
ERROR - 2020-10-10 05:40:32 --> 404 Page Not Found: Cms/wp_includes
ERROR - 2020-10-10 05:40:33 --> 404 Page Not Found: Sito/wp_includes
ERROR - 2020-10-10 07:00:05 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-10-10 07:00:05 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-10-10 08:08:39 --> 404 Page Not Found: Env/index
ERROR - 2020-10-10 19:08:02 --> 404 Page Not Found: Env/index
