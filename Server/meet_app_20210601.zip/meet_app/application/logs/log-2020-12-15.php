<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-15 07:47:52 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-12-15 07:47:53 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-12-15 16:59:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-15 16:59:09 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2020-12-15 16:59:10 --> 404 Page Not Found: Adstxt/index
