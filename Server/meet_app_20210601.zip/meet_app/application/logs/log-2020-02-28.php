<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-28 01:40:47 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 01:41:47 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 02:04:55 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 02:05:13 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 02:20:32 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 02:20:38 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 02:20:57 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 02:29:24 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 02:45:09 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 01:45:18 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\video\coachingservice.php 45
ERROR - 2020-02-28 01:45:18 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\video\coachingservice.php 67
ERROR - 2020-02-28 01:45:18 --> Severity: Notice --> Undefined variable: fetch C:\xampp\htdocs\application\views\video\coachingservice.php 79
ERROR - 2020-02-28 01:45:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\video\coachingservice.php 79
ERROR - 2020-02-28 02:45:24 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:01:23 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:01:36 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:01:37 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:01:41 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:01:43 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:01:45 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:01:51 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:02:01 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:02:03 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:02:06 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:02:32 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:02:34 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:02:35 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 02:02:59 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\application\views\video\coachingservice.php 68
ERROR - 2020-02-28 02:02:59 --> Severity: Notice --> Undefined variable: fetch C:\xampp\htdocs\application\views\video\coachingservice.php 80
ERROR - 2020-02-28 02:02:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\video\coachingservice.php 80
ERROR - 2020-02-28 03:03:00 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 02:05:10 --> Severity: Notice --> Undefined variable: fetch C:\xampp\htdocs\application\views\video\coachingservice.php 74
ERROR - 2020-02-28 02:05:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\video\coachingservice.php 74
ERROR - 2020-02-28 03:05:11 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 02:05:55 --> Severity: Notice --> Undefined variable: fetch C:\xampp\htdocs\application\views\video\coachingservice.php 74
ERROR - 2020-02-28 02:05:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\video\coachingservice.php 74
ERROR - 2020-02-28 03:05:56 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 02:06:30 --> Severity: Notice --> Undefined variable: fetch C:\xampp\htdocs\application\views\video\coachingservice.php 74
ERROR - 2020-02-28 02:06:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\video\coachingservice.php 74
ERROR - 2020-02-28 03:06:31 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 02:06:32 --> Severity: Notice --> Undefined variable: fetch C:\xampp\htdocs\application\views\video\coachingservice.php 74
ERROR - 2020-02-28 02:06:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\video\coachingservice.php 74
ERROR - 2020-02-28 03:06:33 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:09:09 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:09:17 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:09:20 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:09:22 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:10:51 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:10:55 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:13:44 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:13:50 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:13:52 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:14:26 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:14:31 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:14:33 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:14:54 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:15:03 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:15:09 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:15:10 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:15:12 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:25:01 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:25:06 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:25:09 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:25:13 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:38:20 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:38:24 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:38:26 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:38:30 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 02:44:22 --> Severity: Notice --> Undefined variable: category_id C:\xampp\htdocs\application\views\video\coachingservice.php 47
ERROR - 2020-02-28 02:44:22 --> Severity: Notice --> Undefined variable: fetch C:\xampp\htdocs\application\views\video\coachingservice.php 71
ERROR - 2020-02-28 02:44:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\video\coachingservice.php 71
ERROR - 2020-02-28 03:44:23 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:44:27 --> 404 Page Not Found: Api/sendTestMail
ERROR - 2020-02-28 02:44:30 --> Severity: Notice --> Undefined variable: category_id C:\xampp\htdocs\application\views\video\coachingservice.php 47
ERROR - 2020-02-28 02:44:30 --> Severity: Notice --> Undefined variable: fetch C:\xampp\htdocs\application\views\video\coachingservice.php 71
ERROR - 2020-02-28 02:44:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\video\coachingservice.php 71
ERROR - 2020-02-28 03:44:30 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:45:24 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:45:33 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 02:45:48 --> Severity: Notice --> Undefined variable: category_id C:\xampp\htdocs\application\views\video\coachingservice.php 47
ERROR - 2020-02-28 02:45:48 --> Severity: Notice --> Undefined variable: fetch C:\xampp\htdocs\application\views\video\coachingservice.php 71
ERROR - 2020-02-28 02:45:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\video\coachingservice.php 71
ERROR - 2020-02-28 03:45:49 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 02:45:51 --> Severity: Notice --> Undefined variable: category_id C:\xampp\htdocs\application\views\video\coachingservice.php 47
ERROR - 2020-02-28 02:45:51 --> Severity: Notice --> Undefined variable: fetch C:\xampp\htdocs\application\views\video\coachingservice.php 71
ERROR - 2020-02-28 02:45:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\video\coachingservice.php 71
ERROR - 2020-02-28 03:45:52 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:47:03 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:47:05 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:47:06 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:47:35 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:47:40 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:47:44 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:47:45 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:47:51 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 02:47:55 --> Severity: Notice --> Undefined variable: category_id C:\xampp\htdocs\application\views\video\coachingservice.php 44
ERROR - 2020-02-28 02:47:55 --> Severity: Notice --> Undefined variable: fetch C:\xampp\htdocs\application\views\video\coachingservice.php 68
ERROR - 2020-02-28 02:47:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\video\coachingservice.php 68
ERROR - 2020-02-28 03:47:56 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:48:03 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 02:49:51 --> Severity: Notice --> Undefined variable: category_id C:\xampp\htdocs\application\views\video\coachingservice.php 46
ERROR - 2020-02-28 02:49:51 --> Severity: Notice --> Undefined variable: fetch C:\xampp\htdocs\application\views\video\coachingservice.php 70
ERROR - 2020-02-28 02:49:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\video\coachingservice.php 70
ERROR - 2020-02-28 03:49:51 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 02:55:59 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\application\views\video\coachingservice.php 86
ERROR - 2020-02-28 03:19:28 --> Severity: Notice --> Undefined variable: category_id C:\xampp\htdocs\application\views\video\coachingservice.php 47
ERROR - 2020-02-28 03:19:28 --> Severity: Notice --> Undefined variable: fetch C:\xampp\htdocs\application\views\video\coachingservice.php 70
ERROR - 2020-02-28 03:19:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\video\coachingservice.php 70
ERROR - 2020-02-28 04:19:29 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:19:50 --> Severity: Notice --> Undefined variable: category_id C:\xampp\htdocs\application\views\video\coachingservice.php 47
ERROR - 2020-02-28 04:19:51 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 04:28:08 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 03:28:11 --> Severity: Notice --> Undefined variable: category_id C:\xampp\htdocs\application\views\video\coachingservice.php 47
ERROR - 2020-02-28 04:28:12 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 04:25:21 --> Severity: Notice --> Undefined variable: category_id C:\xampp\htdocs\application\views\video\coachingservice.php 47
ERROR - 2020-02-28 05:25:22 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 04:25:24 --> Severity: Notice --> Undefined variable: category_id C:\xampp\htdocs\application\views\video\coachingservice.php 47
ERROR - 2020-02-28 05:25:25 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 04:25:35 --> Severity: Notice --> Undefined variable: category_id C:\xampp\htdocs\application\views\video\coachingservice.php 47
ERROR - 2020-02-28 05:25:40 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 05:26:15 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 05:26:16 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 05:26:33 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 05:26:36 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 05:26:37 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 05:27:32 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 05:28:51 --> 404 Page Not Found: Admin/addcoachingservice%20
ERROR - 2020-02-28 05:29:25 --> 404 Page Not Found: Admin/addcoachingservice%20
ERROR - 2020-02-28 05:29:29 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 04:30:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ' `minidescription`, `fulldescription`, `price`, `phone`, `name`, `image`) VALUES' at line 1 - Invalid query: INSERT INTO `tb_coachingservices` (`title`, , `minidescription`, `fulldescription`, `price`, `phone`, `name`, `image`) VALUES ('asdasdasdasd', 'asdasdasdasdwqewqweqwe', 'mtytytytyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy', 'fweeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee', '14.99', '16759823365', 'Nsdfwerwerme', 'http://localhost:8080/uploadfiles/coachingservice/1582864206704.png')
ERROR - 2020-02-28 04:31:00 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\application\views\video\coachingservice.php 74
ERROR - 2020-02-28 05:31:00 --> 404 Page Not Found: Admin/%3Cdiv
ERROR - 2020-02-28 05:31:08 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 05:31:19 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 04:31:33 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\application\views\video\coachingservice.php 74
ERROR - 2020-02-28 04:31:33 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\application\views\video\coachingservice.php 74
ERROR - 2020-02-28 05:31:34 --> 404 Page Not Found: Admin/%3Cdiv
ERROR - 2020-02-28 05:31:43 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 05:32:47 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 05:35:00 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 05:35:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 05:35:10 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 05:35:28 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 05:37:13 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 05:37:53 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 05:37:54 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 05:37:56 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 05:37:59 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 05:38:22 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 06:30:13 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 06:30:17 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 06:30:19 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 06:31:25 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 06:31:40 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 06:36:18 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 06:38:57 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 06:40:09 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 06:40:35 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 06:41:47 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 06:44:05 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 06:44:46 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 06:49:29 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 06:49:54 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 06:50:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 06:50:16 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 06:50:18 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 06:51:41 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 06:53:45 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 06:55:09 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 06:55:38 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:02:38 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:04:55 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:05:38 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:07:24 --> 404 Page Not Found: Uploadfiles/category
ERROR - 2020-02-28 07:07:24 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:07:32 --> 404 Page Not Found: Uploadfiles/category
ERROR - 2020-02-28 07:07:32 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:07:44 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:07:53 --> 404 Page Not Found: Uploadfiles/category
ERROR - 2020-02-28 07:07:53 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:08:10 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:08:23 --> 404 Page Not Found: Uploadfiles/category
ERROR - 2020-02-28 07:08:23 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:12:40 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:13:41 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:14:17 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:17:43 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:20:49 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:21:10 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:22:00 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:22:18 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:22:42 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:23:01 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:23:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:30:58 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:32:26 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:32:28 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:32:34 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:33:04 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:33:09 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:36:40 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:36:57 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:37:00 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:37:03 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:37:11 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:37:17 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:37:31 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:38:26 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:38:35 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:38:39 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:38:51 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:39:27 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:39:31 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:39:38 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:39:42 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:40:00 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:40:13 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:40:26 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:40:36 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:40:44 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:40:53 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:42:06 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:42:28 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:43:15 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:43:24 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:43:30 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:43:58 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:44:03 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:44:21 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:44:54 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:45:05 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:45:22 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:45:57 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:46:33 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:46:58 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:47:01 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:47:22 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:47:34 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:47:39 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:47:54 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:47:57 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:48:26 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 06:48:35 --> Severity: error --> Exception: Call to undefined method Admin_model::get_values_desc() C:\xampp\htdocs\application\controllers\Admin.php 518
ERROR - 2020-02-28 07:49:59 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:50:16 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:50:51 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:50:58 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:51:20 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:51:29 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:08:13 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:08:16 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:08:34 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:09:06 --> Severity: Warning --> unlink(): http does not allow unlinking C:\xampp\htdocs\application\controllers\Admin.php 512
ERROR - 2020-02-28 08:09:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:14:50 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:15:11 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:15:15 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:16:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:16:24 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:16:32 --> Severity: Warning --> unlink(): http does not allow unlinking C:\xampp\htdocs\application\controllers\Admin.php 512
ERROR - 2020-02-28 08:16:33 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:17:30 --> Severity: Warning --> unlink(): http does not allow unlinking C:\xampp\htdocs\application\controllers\Admin.php 512
ERROR - 2020-02-28 08:17:31 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:18:39 --> 404 Page Not Found: Uploadfiles/category
ERROR - 2020-02-28 08:18:41 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:18:42 --> 404 Page Not Found: Uploadfiles/category
ERROR - 2020-02-28 08:18:42 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:18:45 --> 404 Page Not Found: Uploadfiles/category
ERROR - 2020-02-28 08:18:45 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:18:47 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:18:55 --> 404 Page Not Found: Uploadfiles/category
ERROR - 2020-02-28 08:18:55 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:19:09 --> 404 Page Not Found: Uploadfiles/category
ERROR - 2020-02-28 08:19:09 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:19:25 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:19:33 --> 404 Page Not Found: Uploadfiles/category
ERROR - 2020-02-28 08:19:33 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:19:42 --> 404 Page Not Found: Uploadfiles/category
ERROR - 2020-02-28 08:19:42 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:21:04 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:21:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:21:19 --> 404 Page Not Found: Uploadfiles/category
ERROR - 2020-02-28 08:21:19 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:21:36 --> 404 Page Not Found: Uploadfiles/category
ERROR - 2020-02-28 08:21:36 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:21:40 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:21:44 --> 404 Page Not Found: Uploadfiles/category
ERROR - 2020-02-28 08:21:44 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:21:48 --> 404 Page Not Found: Uploadfiles/category
ERROR - 2020-02-28 08:21:48 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:22:18 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:22:46 --> 404 Page Not Found: Uploadfiles/coachingservice
ERROR - 2020-02-28 08:22:47 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:23:02 --> 404 Page Not Found: Uploadfiles/coachingservice
ERROR - 2020-02-28 08:23:03 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:24:10 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:24:15 --> 404 Page Not Found: Uploadfiles/coachingservice
ERROR - 2020-02-28 08:24:15 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:24:23 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:24:39 --> 404 Page Not Found: Uploadfiles/coachingservice
ERROR - 2020-02-28 08:24:40 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:24:44 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:25:03 --> 404 Page Not Found: Uploadfiles/coachingservice
ERROR - 2020-02-28 08:25:04 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:25:09 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:25:13 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:25:19 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:25:37 --> 404 Page Not Found: Uploadfiles/coachingservice
ERROR - 2020-02-28 08:25:37 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:26:08 --> Severity: Warning --> unlink(): http does not allow unlinking C:\xampp\htdocs\application\controllers\Admin.php 514
ERROR - 2020-02-28 08:26:08 --> 404 Page Not Found: Uploadfiles/coachingservice
ERROR - 2020-02-28 08:26:09 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:26:26 --> Severity: Warning --> unlink(): http does not allow unlinking C:\xampp\htdocs\application\controllers\Admin.php 514
ERROR - 2020-02-28 08:26:27 --> 404 Page Not Found: Uploadfiles/coachingservice
ERROR - 2020-02-28 08:26:27 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:28:38 --> 404 Page Not Found: Uploadfiles/coachingservice
ERROR - 2020-02-28 08:30:57 --> 404 Page Not Found: Uploadfiles/coachingservice
ERROR - 2020-02-28 08:30:58 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:31:09 --> 404 Page Not Found: Uploadfiles/coachingservice
ERROR - 2020-02-28 08:31:09 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:34:59 --> 404 Page Not Found: Uploadfiles/category
ERROR - 2020-02-28 08:34:59 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:35:02 --> 404 Page Not Found: Uploadfiles/category
ERROR - 2020-02-28 08:35:02 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:35:04 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:38:56 --> 404 Page Not Found: Uploadfiles/category
ERROR - 2020-02-28 08:38:56 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:38:58 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:40:30 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:48:47 --> 404 Page Not Found: Uploadfiles/coachingservice
ERROR - 2020-02-28 08:48:47 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:49:18 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:49:24 --> 404 Page Not Found: Uploadfiles/coachingservice
ERROR - 2020-02-28 08:49:24 --> 404 Page Not Found: Uploadfiles/coachingservice
ERROR - 2020-02-28 08:49:25 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:49:35 --> 404 Page Not Found: Uploadfiles/coachingservice
ERROR - 2020-02-28 08:49:35 --> 404 Page Not Found: Uploadfiles/coachingservice
ERROR - 2020-02-28 08:49:35 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:53:09 --> 404 Page Not Found: Uploadfiles/coachingservice
ERROR - 2020-02-28 08:53:09 --> 404 Page Not Found: Uploadfiles/coachingservice
ERROR - 2020-02-28 08:53:10 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 07:53:14 --> Severity: Warning --> unlink(uploadfiles/coachingservice/1582876126330.png): No such file or directory C:\xampp\htdocs\application\controllers\Admin.php 519
ERROR - 2020-02-28 08:53:15 --> 404 Page Not Found: Uploadfiles/coachingservice
ERROR - 2020-02-28 08:53:16 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:53:21 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:53:25 --> 404 Page Not Found: Uploadfiles/coachingservice
ERROR - 2020-02-28 08:53:26 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:54:08 --> 404 Page Not Found: Uploadfiles/coachingservice
ERROR - 2020-02-28 08:54:09 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:54:16 --> 404 Page Not Found: Uploadfiles/coachingservice
ERROR - 2020-02-28 08:54:17 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:54:20 --> 404 Page Not Found: Uploadfiles/coachingservice
ERROR - 2020-02-28 08:54:24 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:54:30 --> 404 Page Not Found: Uploadfiles/coachingservice
ERROR - 2020-02-28 08:54:31 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:55:07 --> 404 Page Not Found: Uploadfiles/coachingservice
ERROR - 2020-02-28 08:55:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:55:20 --> 404 Page Not Found: Uploadfiles/coachingservice
ERROR - 2020-02-28 08:55:21 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:56:40 --> 404 Page Not Found: Uploadfiles/coachingservice
ERROR - 2020-02-28 08:56:45 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:57:13 --> 404 Page Not Found: Uploadfiles/coachingservice
ERROR - 2020-02-28 08:57:14 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:57:25 --> 404 Page Not Found: Uploadfiles/coachingservice
ERROR - 2020-02-28 08:57:26 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:57:29 --> 404 Page Not Found: Uploadfiles/coachingservice
ERROR - 2020-02-28 08:57:32 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:58:55 --> 404 Page Not Found: Uploadfiles/coachingservice
ERROR - 2020-02-28 08:58:56 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:59:10 --> 404 Page Not Found: Uploadfiles/coachingservice
ERROR - 2020-02-28 08:59:11 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:59:22 --> 404 Page Not Found: Uploadfiles/coachingservice
ERROR - 2020-02-28 08:59:23 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 09:00:06 --> 404 Page Not Found: Uploadfiles/coachingservice
ERROR - 2020-02-28 09:00:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 09:00:16 --> 404 Page Not Found: Uploadfiles/coachingservice
ERROR - 2020-02-28 09:00:17 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 09:00:36 --> 404 Page Not Found: Uploadfiles/coachingservice
ERROR - 2020-02-28 09:00:37 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 09:01:05 --> 404 Page Not Found: Uploadfiles/coachingservice
ERROR - 2020-02-28 09:01:06 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 09:02:03 --> 404 Page Not Found: Uploadfiles/coachingservice
ERROR - 2020-02-28 09:02:04 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 09:02:07 --> 404 Page Not Found: Uploadfiles/coachingservice
ERROR - 2020-02-28 09:02:08 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 09:02:11 --> 404 Page Not Found: Uploadfiles/coachingservice
ERROR - 2020-02-28 09:02:15 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 09:02:46 --> 404 Page Not Found: Uploadfiles/coachingservice
ERROR - 2020-02-28 09:02:47 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 09:03:28 --> 404 Page Not Found: Uploadfiles/coachingservice
ERROR - 2020-02-28 09:03:28 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 09:03:38 --> 404 Page Not Found: Uploadfiles/coachingservice
ERROR - 2020-02-28 09:03:39 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 09:03:47 --> 404 Page Not Found: Uploadfiles/coachingservice
ERROR - 2020-02-28 09:03:48 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 09:04:10 --> 404 Page Not Found: Uploadfiles/coachingservice
ERROR - 2020-02-28 09:04:11 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 09:04:18 --> 404 Page Not Found: Uploadfiles/coachingservice
ERROR - 2020-02-28 09:04:19 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 09:05:08 --> 404 Page Not Found: Uploadfiles/coachingservice
ERROR - 2020-02-28 09:05:09 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 09:06:52 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 08:06:58 --> Severity: Warning --> unlink(uploadfiles/coachingservice/1582870420384.png): No such file or directory C:\xampp\htdocs\application\controllers\Admin.php 602
ERROR - 2020-02-28 09:06:59 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 09:07:01 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 09:07:21 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 10:13:48 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 10:13:52 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 10:13:59 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 10:14:17 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 10:14:23 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 10:14:32 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 10:14:43 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 10:14:55 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 10:20:57 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 10:21:10 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 10:21:24 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 10:21:26 --> 404 Page Not Found: Admin/nutritionist
ERROR - 2020-02-28 10:21:28 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 10:37:17 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 10:37:20 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 10:37:26 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 09:38:12 --> Query error: Unknown column 'minidescription' in 'field list' - Invalid query: INSERT INTO `tb_nutritionists` (`title`, `subtitle`, `minidescription`, `fulldescription`, `price`, `email`, `name`, `image`) VALUES ('Undere The Sea', 'asdasdasdasdwqewqweqwe', 'mtytytytyyyyyyyy yyyyyyy yyyyyyyyyy yyyyyyyyyyy', ' NEED HELP? CLICK THE HOME BUTTON TO CONTACT A NUTRITIONIST OR COACH NEED HELP? CLICK THE HOME BUTTON TO CONTACT A NUTRITIONIST OR COACH NEED HELP? CLICK THE HOME BUTTON TO CONTACT A NUTRITIONIST OR COACH NEED HELP? CLICK THE HOME BUTTON TO CONTACT A NUTRITIONIST OR COACH NEED HELP? CLICK THE HOME BUTTON TO CONTACT A NUTRITIONIST OR COACH NEED HELP? CLICK THE HOME BUTTON TO CONTACT A NUTRITIONIST OR COACH NEED HELP? CLICK THE HOME BUTTON TO CONTACT A NUTRITIONIST OR COACH', '5.99', 'admin@admin.com', 'Nsdfwerwerme', 'http://localhost:8080/uploadfiles/nutritionist/1582882692104.png')
ERROR - 2020-02-28 10:39:11 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 10:39:14 --> 404 Page Not Found: Uploadfiles/nutritionist
ERROR - 2020-02-28 10:39:15 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 10:40:14 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 10:40:20 --> 404 Page Not Found: Uploadfiles/nutritionist
ERROR - 2020-02-28 10:40:21 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 10:40:26 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 10:41:11 --> 404 Page Not Found: Uploadfiles/nutritionist
ERROR - 2020-02-28 10:41:12 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 10:41:16 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 10:41:49 --> 404 Page Not Found: Uploadfiles/nutritionist
ERROR - 2020-02-28 10:41:49 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 09:41:52 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\application\views\video\edit_nutritionist.php 46
ERROR - 2020-02-28 10:41:52 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 10:42:31 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 09:42:41 --> Severity: Warning --> unlink(uploadfiles/nutritionist/158): No such file or directory C:\xampp\htdocs\application\controllers\Admin.php 683
ERROR - 2020-02-28 10:42:42 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 10:42:46 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 10:42:53 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 10:43:12 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 10:43:18 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 10:43:42 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 10:44:58 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 10:45:01 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 10:46:00 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 10:46:21 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 10:46:27 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 10:46:53 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 10:47:50 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 10:48:10 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 10:48:13 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 10:48:16 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 10:48:19 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 16:48:43 --> 404 Page Not Found: Api/updateContent
ERROR - 2020-02-28 16:54:18 --> 404 Page Not Found: Api/uploadContent
ERROR - 2020-02-28 17:00:38 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 17:00:41 --> 404 Page Not Found: Admin/myVideo.mp4
ERROR - 2020-02-28 17:00:41 --> 404 Page Not Found: Admin/myVideo.mp4
ERROR - 2020-02-28 17:00:41 --> 404 Page Not Found: Admin/myVideo.mp4
ERROR - 2020-02-28 17:00:41 --> 404 Page Not Found: Admin/myVideo.webm
ERROR - 2020-02-28 17:00:41 --> 404 Page Not Found: Admin/myVideo.webm
ERROR - 2020-02-28 17:00:41 --> 404 Page Not Found: Admin/myVideo.mp4
ERROR - 2020-02-28 17:00:41 --> 404 Page Not Found: Admin/myVideo.mp4
ERROR - 2020-02-28 17:00:41 --> 404 Page Not Found: Admin/myVideo.webm
ERROR - 2020-02-28 17:00:41 --> 404 Page Not Found: Admin/myVideo.webm
ERROR - 2020-02-28 17:00:41 --> 404 Page Not Found: Admin/myVideo.webm
ERROR - 2020-02-28 17:00:41 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 17:00:45 --> 404 Page Not Found: Admin/myVideo.mp4
ERROR - 2020-02-28 17:00:45 --> 404 Page Not Found: Admin/myVideo.mp4
ERROR - 2020-02-28 17:00:45 --> 404 Page Not Found: Admin/myVideo.mp4
ERROR - 2020-02-28 17:00:45 --> 404 Page Not Found: Admin/myVideo.webm
ERROR - 2020-02-28 17:00:45 --> 404 Page Not Found: Admin/myVideo.mp4
ERROR - 2020-02-28 17:00:45 --> 404 Page Not Found: Admin/myVideo.webm
ERROR - 2020-02-28 17:00:45 --> 404 Page Not Found: Admin/myVideo.mp4
ERROR - 2020-02-28 17:00:45 --> 404 Page Not Found: Admin/myVideo.webm
ERROR - 2020-02-28 17:00:46 --> 404 Page Not Found: Admin/myVideo.webm
ERROR - 2020-02-28 17:00:46 --> 404 Page Not Found: Admin/myVideo.webm
ERROR - 2020-02-28 17:00:46 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 17:01:08 --> 404 Page Not Found: Admin/myVideo.mp4
ERROR - 2020-02-28 17:01:08 --> 404 Page Not Found: Admin/myVideo.mp4
ERROR - 2020-02-28 17:01:08 --> 404 Page Not Found: Admin/myVideo.mp4
ERROR - 2020-02-28 17:01:08 --> 404 Page Not Found: Admin/myVideo.mp4
ERROR - 2020-02-28 17:01:08 --> 404 Page Not Found: Admin/myVideo.webm
ERROR - 2020-02-28 17:01:08 --> 404 Page Not Found: Admin/myVideo.webm
ERROR - 2020-02-28 17:01:08 --> 404 Page Not Found: Admin/myVideo.mp4
ERROR - 2020-02-28 17:01:08 --> 404 Page Not Found: Admin/myVideo.webm
ERROR - 2020-02-28 17:01:08 --> 404 Page Not Found: Admin/myVideo.webm
ERROR - 2020-02-28 17:01:08 --> 404 Page Not Found: Admin/myVideo.webm
ERROR - 2020-02-28 17:01:08 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 17:01:25 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 17:01:28 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 17:01:30 --> 404 Page Not Found: Admin/myVideo.mp4
ERROR - 2020-02-28 17:01:30 --> 404 Page Not Found: Admin/myVideo.mp4
ERROR - 2020-02-28 17:01:30 --> 404 Page Not Found: Admin/myVideo.mp4
ERROR - 2020-02-28 17:01:30 --> 404 Page Not Found: Admin/myVideo.mp4
ERROR - 2020-02-28 17:01:30 --> 404 Page Not Found: Admin/myVideo.webm
ERROR - 2020-02-28 17:01:30 --> 404 Page Not Found: Admin/myVideo.webm
ERROR - 2020-02-28 17:01:30 --> 404 Page Not Found: Admin/myVideo.webm
ERROR - 2020-02-28 17:01:30 --> 404 Page Not Found: Admin/myVideo.mp4
ERROR - 2020-02-28 17:01:30 --> 404 Page Not Found: Admin/myVideo.webm
ERROR - 2020-02-28 17:01:30 --> 404 Page Not Found: Admin/myVideo.webm
ERROR - 2020-02-28 17:01:30 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 17:26:34 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 17:26:38 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 16:27:21 --> Query error: Unknown column 'minidescription' in 'field list' - Invalid query: INSERT INTO `tb_workoutvideos` (`title`, `subtitle`, `minidescription`, `fulldescription`, `price`, `image`, `video`) VALUES ('Undere The Sea', 'asda sdasdasdwqew qweqwe', 'mtytytytyy yyyyyyyy yyyyyyyyy yyyyy  yyyyy yyyyyyy', ' NEED HELP? CLICK THE HOME BUTTON TO CONTACT A NUTRITIONIST OR COACH NEED HELP? CLICK THE HOME BUTTON TO CONTACT A NUTRITIONIST OR COACH NEED HELP? CLICK THE HOME BUTTON TO CONTACT A NUTRITIONIST OR COACH NEED HELP? CLICK THE HOME BUTTON TO CONTACT A NUTRITIONIST OR COACH NEED HELP? CLICK THE HOME BUTTON TO CONTACT A NUTRITIONIST OR COACH NEED HELP? CLICK THE HOME BUTTON TO CONTACT A NUTRITIONIST OR COACH NEED HELP? CLICK THE HOME BUTTON TO CONTACT A NUTRITIONIST OR COACH', '14.99', 'http://localhost:8080/uploadfiles/workoutvideo/1582907241695.png', 'http://localhost:8080/uploadfiles/workoutvideo/15829072416951.png')
ERROR - 2020-02-28 17:27:30 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 17:27:57 --> 404 Page Not Found: Uploadfiles/workoutvideo
ERROR - 2020-02-28 17:27:58 --> 404 Page Not Found: Admin/myVideo.mp4
ERROR - 2020-02-28 17:27:58 --> 404 Page Not Found: Admin/myVideo.webm
ERROR - 2020-02-28 17:27:58 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 17:29:14 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 17:29:20 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 17:30:57 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 17:30:57 --> 404 Page Not Found: Admin/myVideo.webm
ERROR - 2020-02-28 17:35:36 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 17:35:57 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 16:36:33 --> Severity: Notice --> Undefined property: CI_Upload::$image_file_name C:\xampp\htdocs\application\controllers\Admin.php 728
ERROR - 2020-02-28 16:36:33 --> Severity: Notice --> Undefined property: CI_Upload::$video_file_name C:\xampp\htdocs\application\controllers\Admin.php 730
ERROR - 2020-02-28 17:36:34 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 17:36:34 --> 404 Page Not Found: Admin/myVideo.webm
ERROR - 2020-02-28 16:46:53 --> Severity: Warning --> unlink(uploadfiles/workoutvideo/): Permission denied C:\xampp\htdocs\application\controllers\Admin.php 511
ERROR - 2020-02-28 16:46:53 --> Severity: Warning --> unlink(uploadfiles/workoutvideo/): Permission denied C:\xampp\htdocs\application\controllers\Admin.php 513
ERROR - 2020-02-28 17:46:54 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 17:47:09 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 16:53:22 --> Severity: Notice --> Undefined property: CI_Upload::$image_file_name C:\xampp\htdocs\application\controllers\Admin.php 726
ERROR - 2020-02-28 16:53:22 --> The upload path does not appear to be valid.
ERROR - 2020-02-28 17:53:24 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 17:54:13 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 16:54:35 --> Severity: Notice --> Undefined property: CI_Upload::$image_file_name C:\xampp\htdocs\application\controllers\Admin.php 726
ERROR - 2020-02-28 16:54:35 --> The upload path does not appear to be valid.
ERROR - 2020-02-28 17:54:36 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 17:55:04 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 16:55:20 --> Severity: Notice --> Undefined property: CI_Upload::$image_file_name C:\xampp\htdocs\application\controllers\Admin.php 726
ERROR - 2020-02-28 16:55:20 --> The upload path does not appear to be valid.
ERROR - 2020-02-28 17:55:22 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 17:55:41 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 16:56:01 --> Severity: Notice --> Undefined property: CI_Upload::$image_file_name C:\xampp\htdocs\application\controllers\Admin.php 726
ERROR - 2020-02-28 16:56:01 --> The upload path does not appear to be valid.
ERROR - 2020-02-28 17:56:03 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 17:56:43 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 16:57:02 --> Severity: Notice --> Undefined property: CI_Upload::$image_file_name C:\xampp\htdocs\application\controllers\Admin.php 726
ERROR - 2020-02-28 16:57:02 --> The upload path does not appear to be valid.
ERROR - 2020-02-28 16:57:38 --> The upload path does not appear to be valid.
ERROR - 2020-02-28 17:57:43 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 16:57:58 --> The upload path does not appear to be valid.
ERROR - 2020-02-28 18:00:24 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 17:00:25 --> The upload path does not appear to be valid.
ERROR - 2020-02-28 18:00:45 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 17:00:48 --> The upload path does not appear to be valid.
ERROR - 2020-02-28 18:00:54 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 18:01:42 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 17:02:05 --> The upload path does not appear to be valid.
ERROR - 2020-02-28 18:03:14 --> Severity: error --> Exception: syntax error, unexpected ''remove_space'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\application\controllers\Admin.php 733
ERROR - 2020-02-28 18:04:32 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 18:05:37 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 18:05:38 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 18:06:13 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 18:09:24 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 18:09:37 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 18:09:39 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 18:09:40 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 18:10:10 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 18:14:33 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 18:18:30 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 18:22:41 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 18:26:36 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 18:28:45 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 18:30:59 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 18:31:57 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 18:31:59 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 18:32:03 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 17:32:25 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\application\controllers\Admin.php 765
ERROR - 2020-02-28 17:32:25 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\controllers\Admin.php 766
ERROR - 2020-02-28 17:32:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Admin.php 766
ERROR - 2020-02-28 18:34:21 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 17:36:02 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\application\controllers\Admin.php 765
ERROR - 2020-02-28 17:36:02 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\controllers\Admin.php 766
ERROR - 2020-02-28 17:36:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Admin.php 766
ERROR - 2020-02-28 17:36:02 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\controllers\Admin.php 768
ERROR - 2020-02-28 17:36:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Admin.php 768
ERROR - 2020-02-28 17:36:02 --> Severity: Notice --> Undefined variable: file_path C:\xampp\htdocs\application\controllers\Admin.php 779
ERROR - 2020-02-28 18:36:55 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 18:37:05 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 18:37:06 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 17:37:33 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\application\controllers\Admin.php 765
ERROR - 2020-02-28 17:37:33 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\controllers\Admin.php 766
ERROR - 2020-02-28 17:37:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Admin.php 766
ERROR - 2020-02-28 17:37:33 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\controllers\Admin.php 768
ERROR - 2020-02-28 17:37:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Admin.php 768
ERROR - 2020-02-28 17:37:33 --> Severity: Notice --> Undefined variable: file_path C:\xampp\htdocs\application\controllers\Admin.php 779
ERROR - 2020-02-28 18:39:34 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 17:39:40 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\application\controllers\Admin.php 765
ERROR - 2020-02-28 17:39:40 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\controllers\Admin.php 766
ERROR - 2020-02-28 17:39:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Admin.php 766
ERROR - 2020-02-28 17:39:40 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\controllers\Admin.php 768
ERROR - 2020-02-28 17:39:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Admin.php 768
ERROR - 2020-02-28 18:40:20 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 18:40:22 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 18:40:24 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 17:40:49 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\application\controllers\Admin.php 765
ERROR - 2020-02-28 17:40:49 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\controllers\Admin.php 766
ERROR - 2020-02-28 17:40:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Admin.php 766
ERROR - 2020-02-28 17:40:49 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\controllers\Admin.php 768
ERROR - 2020-02-28 17:40:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Admin.php 768
ERROR - 2020-02-28 18:41:46 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 18:41:48 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 18:42:59 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 18:44:57 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 18:45:01 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 18:45:15 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 17:45:27 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\application\controllers\Admin.php 765
ERROR - 2020-02-28 17:45:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\controllers\Admin.php 766
ERROR - 2020-02-28 17:45:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Admin.php 766
ERROR - 2020-02-28 17:45:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\application\controllers\Admin.php 768
ERROR - 2020-02-28 17:45:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Admin.php 768
ERROR - 2020-02-28 18:45:51 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 18:45:53 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 18:45:55 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 18:46:27 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 18:48:19 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 18:48:22 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 18:48:34 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 18:51:53 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 18:51:56 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 18:52:36 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 18:52:47 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 18:52:50 --> 404 Page Not Found: Android_icon_192x192png/index
ERROR - 2020-02-28 18:53:05 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 18:53:33 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 19:07:15 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 19:10:02 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 19:10:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 19:10:11 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 19:10:14 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 19:10:23 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 19:11:15 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 19:11:19 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 19:12:01 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 19:12:13 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 19:21:21 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 19:21:34 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 19:23:34 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 19:30:49 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 19:34:55 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 19:34:55 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 19:34:57 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 22:40:59 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 22:41:02 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 22:41:06 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 22:56:58 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 22:58:31 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 22:58:41 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 23:13:21 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 23:13:26 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 23:19:29 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 23:19:47 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 23:22:56 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 23:23:04 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 23:24:00 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 23:24:34 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 23:24:35 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 23:24:47 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 23:25:08 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 23:25:16 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 23:26:34 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 23:26:38 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 23:26:46 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-28 23:27:38 --> Severity: Notice --> Undefined index: image C:\xampp\htdocs\application\controllers\Admin.php 740
ERROR - 2020-02-28 23:27:38 --> Severity: Notice --> Undefined index: image C:\xampp\htdocs\application\controllers\Admin.php 744
ERROR - 2020-02-28 23:27:38 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\application\controllers\Admin.php 746
ERROR - 2020-02-28 23:29:15 --> Severity: Notice --> Undefined index: image C:\xampp\htdocs\application\controllers\Admin.php 740
ERROR - 2020-02-28 23:29:15 --> Severity: Notice --> Undefined index: image C:\xampp\htdocs\application\controllers\Admin.php 744
ERROR - 2020-02-28 23:29:15 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\application\controllers\Admin.php 746
ERROR - 2020-02-28 23:35:56 --> Severity: Notice --> Undefined index: image C:\xampp\htdocs\application\controllers\Admin.php 740
ERROR - 2020-02-28 23:35:56 --> Severity: Notice --> Undefined index: image C:\xampp\htdocs\application\controllers\Admin.php 744
ERROR - 2020-02-28 23:35:56 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\application\controllers\Admin.php 746
ERROR - 2020-02-28 23:37:19 --> Severity: Notice --> Undefined index: image C:\xampp\htdocs\application\controllers\Admin.php 740
ERROR - 2020-02-28 23:37:19 --> Severity: Notice --> Undefined index: image C:\xampp\htdocs\application\controllers\Admin.php 744
ERROR - 2020-02-28 23:37:19 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\application\controllers\Admin.php 746
ERROR - 2020-02-28 23:37:34 --> Severity: Notice --> Undefined index: image C:\xampp\htdocs\application\controllers\Admin.php 740
ERROR - 2020-02-28 23:37:34 --> Severity: Notice --> Undefined index: image C:\xampp\htdocs\application\controllers\Admin.php 744
ERROR - 2020-02-28 23:37:34 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\application\controllers\Admin.php 746
ERROR - 2020-02-28 23:39:39 --> Severity: Notice --> Undefined index: image C:\xampp\htdocs\application\controllers\Admin.php 740
ERROR - 2020-02-28 23:39:39 --> Severity: Notice --> Undefined index: image C:\xampp\htdocs\application\controllers\Admin.php 744
ERROR - 2020-02-28 23:39:39 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\application\controllers\Admin.php 746
ERROR - 2020-02-28 23:39:43 --> Severity: Notice --> Undefined index: image C:\xampp\htdocs\application\controllers\Admin.php 740
ERROR - 2020-02-28 23:39:43 --> Severity: Notice --> Undefined index: image C:\xampp\htdocs\application\controllers\Admin.php 744
ERROR - 2020-02-28 23:39:43 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\application\controllers\Admin.php 746
ERROR - 2020-02-28 23:40:03 --> Severity: Notice --> Undefined index: image C:\xampp\htdocs\application\controllers\Admin.php 740
ERROR - 2020-02-28 23:40:03 --> Severity: Notice --> Undefined index: image C:\xampp\htdocs\application\controllers\Admin.php 744
ERROR - 2020-02-28 23:40:03 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\application\controllers\Admin.php 746
ERROR - 2020-02-28 23:51:00 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\application\controllers\Admin.php 742
ERROR - 2020-02-28 23:51:38 --> Severity: Notice --> Undefined index: file C:\xampp\htdocs\application\controllers\Admin.php 742
ERROR - 2020-02-28 23:51:53 --> Severity: Notice --> Undefined index: file C:\xampp\htdocs\application\controllers\Admin.php 742
ERROR - 2020-02-28 23:51:58 --> Severity: Notice --> Undefined index: file C:\xampp\htdocs\application\controllers\Admin.php 742
ERROR - 2020-02-28 23:52:30 --> Severity: Notice --> Undefined index: file C:\xampp\htdocs\application\controllers\Admin.php 742
ERROR - 2020-02-28 23:53:45 --> Severity: Notice --> Undefined index: videoa C:\xampp\htdocs\application\controllers\Admin.php 742
ERROR - 2020-02-28 23:55:13 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\application\controllers\Admin.php 742
