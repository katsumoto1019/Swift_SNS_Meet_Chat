<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-09 05:24:27 --> 404 Page Not Found: Assets/fileupload
ERROR - 2021-05-09 06:32:44 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-05-09 06:32:44 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-05-09 13:48:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-09 17:58:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-09 22:18:50 --> 404 Page Not Found: Env/index
ERROR - 2021-05-09 22:43:32 --> 404 Page Not Found: Env/index
