<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-14 00:04:17 --> 404 Page Not Found: Env/index
ERROR - 2021-02-14 07:00:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-02-14 07:47:36 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-02-14 07:47:37 --> 404 Page Not Found: 404javascriptjs/index
