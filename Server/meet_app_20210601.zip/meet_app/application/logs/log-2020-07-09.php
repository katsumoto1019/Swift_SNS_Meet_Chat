<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-09 01:40:05 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 01:40:13 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 02:39:03 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 03:54:24 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-07-09 03:54:24 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-07-09 03:54:24 --> 404 Page Not Found: Wp_content/themes
ERROR - 2020-07-09 03:54:25 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-07-09 03:54:25 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-07-09 03:54:25 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-07-09 03:54:25 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-07-09 03:54:25 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-07-09 03:54:25 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-07-09 03:54:25 --> 404 Page Not Found: Wp_content/themes
ERROR - 2020-07-09 03:54:25 --> 404 Page Not Found: Wp_content/themes
ERROR - 2020-07-09 03:54:26 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-07-09 03:54:29 --> 404 Page Not Found: Wp_admin/admin_ajax.php
ERROR - 2020-07-09 03:54:30 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-07-09 03:54:30 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-07-09 03:54:30 --> 404 Page Not Found: Wp_content/themes
ERROR - 2020-07-09 03:54:30 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-07-09 03:54:30 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-07-09 03:54:30 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-07-09 03:54:30 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-07-09 03:54:30 --> 404 Page Not Found: Wp_content/themes
ERROR - 2020-07-09 03:54:30 --> 404 Page Not Found: Wp_content/themes
ERROR - 2020-07-09 03:54:30 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-07-09 03:54:31 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-07-09 03:54:31 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-07-09 03:54:31 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-07-09 03:54:32 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-07-09 03:54:34 --> 404 Page Not Found: Wp_admin/index
ERROR - 2020-07-09 03:56:30 --> 404 Page Not Found: Wp_admin/admin_ajax.php
ERROR - 2020-07-09 03:58:30 --> 404 Page Not Found: Wp_admin/admin_ajax.php
ERROR - 2020-07-09 03:59:39 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 04:00:16 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 04:00:19 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 04:00:31 --> 404 Page Not Found: Wp_admin/admin_ajax.php
ERROR - 2020-07-09 04:02:32 --> 404 Page Not Found: Wp_admin/admin_ajax.php
ERROR - 2020-07-09 04:02:32 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 04:02:40 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-07-09 04:03:10 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 04:04:32 --> 404 Page Not Found: Wp_admin/admin_ajax.php
ERROR - 2020-07-09 04:06:33 --> 404 Page Not Found: Wp_admin/admin_ajax.php
ERROR - 2020-07-09 04:08:04 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 04:08:11 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 04:08:34 --> 404 Page Not Found: Wp_admin/admin_ajax.php
ERROR - 2020-07-09 04:10:13 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 04:10:18 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 04:10:26 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 04:10:28 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 04:10:35 --> 404 Page Not Found: Wp_admin/admin_ajax.php
ERROR - 2020-07-09 04:10:40 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 04:10:42 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 04:10:43 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 04:10:46 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 04:10:49 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 04:11:40 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 04:12:02 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 04:12:14 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 04:12:28 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 04:12:35 --> 404 Page Not Found: Wp_admin/admin_ajax.php
ERROR - 2020-07-09 04:13:54 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 04:14:35 --> 404 Page Not Found: Wp_admin/admin_ajax.php
ERROR - 2020-07-09 04:15:19 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-07-09 04:16:25 --> 404 Page Not Found: Wp_content/themes
ERROR - 2020-07-09 04:16:25 --> 404 Page Not Found: Wp_content/themes
ERROR - 2020-07-09 04:16:26 --> 404 Page Not Found: Wp_content/themes
ERROR - 2020-07-09 04:16:35 --> 404 Page Not Found: Wp_admin/admin_ajax.php
ERROR - 2020-07-09 04:18:30 --> 404 Page Not Found: Wp_cronphp/index
ERROR - 2020-07-09 04:18:30 --> 404 Page Not Found: Wp_content/themes
ERROR - 2020-07-09 04:18:30 --> 404 Page Not Found: Wp_content/themes
ERROR - 2020-07-09 04:18:31 --> 404 Page Not Found: Wp_content/themes
ERROR - 2020-07-09 04:18:35 --> 404 Page Not Found: Wp_admin/admin_ajax.php
ERROR - 2020-07-09 04:19:48 --> 404 Page Not Found: Wp_admin/admin_ajax.php
ERROR - 2020-07-09 04:22:16 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 04:22:18 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 04:27:51 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 04:27:54 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 04:27:58 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 04:28:06 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 04:28:08 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 04:28:12 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 04:38:05 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 04:53:14 --> 404 Page Not Found: Env/index
ERROR - 2020-07-09 05:00:30 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 05:00:33 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 05:00:39 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 00:23:17 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-09 00:23:17 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-09 05:23:27 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 00:24:04 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-09 00:24:04 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-09 05:24:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 00:28:04 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-09 00:28:04 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-09 05:28:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 00:28:18 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-09 00:28:18 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-09 05:28:27 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 00:32:16 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-09 00:32:16 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-09 05:32:23 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 00:34:37 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-09 00:34:37 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-09 05:34:46 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 00:35:39 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-09 00:35:39 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-09 05:35:43 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 00:40:23 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-09 00:40:23 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-09 05:40:26 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 05:41:14 --> 404 Page Not Found: Learnme/index
ERROR - 2020-07-09 00:44:33 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-09 00:44:33 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-09 05:44:37 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 00:44:45 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-09 00:44:45 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-09 05:44:48 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 00:45:18 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-09 00:45:18 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-09 05:45:22 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 00:45:24 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-09 00:45:24 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-09 05:45:26 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 00:45:48 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-09 00:45:48 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-09 05:45:51 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 00:47:53 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-09 00:47:53 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-09 05:47:56 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 00:48:02 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-09 00:48:02 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-09 05:48:04 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 10:21:51 --> 404 Page Not Found: Adstxt/index
ERROR - 2020-07-09 06:04:56 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-09 06:04:56 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-09 11:04:59 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 06:07:37 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-09 06:07:37 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-09 11:07:40 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 06:11:19 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-09 06:11:19 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-09 11:11:22 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 06:22:36 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-09 06:22:36 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-09 11:22:39 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 06:22:43 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-09 06:22:43 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-09 11:22:44 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 06:31:33 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-09 06:31:33 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-09 11:31:37 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 12:09:23 --> 404 Page Not Found: Refund/index
ERROR - 2020-07-09 12:10:55 --> 404 Page Not Found: Refund/index
ERROR - 2020-07-09 12:11:20 --> 404 Page Not Found: Refund/index
ERROR - 2020-07-09 12:11:34 --> 404 Page Not Found: Refund/index
ERROR - 2020-07-09 12:11:52 --> 404 Page Not Found: Refund/index
ERROR - 2020-07-09 12:11:59 --> 404 Page Not Found: Refund/index
ERROR - 2020-07-09 12:50:41 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2020-07-09 12:50:43 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-07-09 13:31:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-07-09 13:31:38 --> 404 Page Not Found: Terms_of_use/index
ERROR - 2020-07-09 14:00:42 --> 404 Page Not Found: Api/submitFCM
ERROR - 2020-07-09 14:01:01 --> 404 Page Not Found: Api/mkContact
ERROR - 2020-07-09 14:03:23 --> 404 Page Not Found: Api/submitFCM
ERROR - 2020-07-09 14:03:34 --> 404 Page Not Found: Api/mkContact
ERROR - 2020-07-09 14:04:10 --> 404 Page Not Found: Api/submitFCM
ERROR - 2020-07-09 14:12:05 --> 404 Page Not Found: Api/mkContact
ERROR - 2020-07-09 14:18:31 --> 404 Page Not Found: Api/submitFCM
ERROR - 2020-07-09 14:18:48 --> 404 Page Not Found: Api/mkContact
ERROR - 2020-07-09 14:18:56 --> 404 Page Not Found: Api/submitFCM
ERROR - 2020-07-09 14:20:17 --> 404 Page Not Found: Api/mkContact
ERROR - 2020-07-09 14:23:50 --> 404 Page Not Found: Api/onLoadSellers_Top
ERROR - 2020-07-09 14:23:53 --> 404 Page Not Found: Api/onLoadSellers_Top
ERROR - 2020-07-09 14:23:57 --> 404 Page Not Found: Api/onLoadSellers_Top
ERROR - 2020-07-09 14:24:02 --> 404 Page Not Found: Api/onLoadSellers_Top
ERROR - 2020-07-09 14:24:03 --> 404 Page Not Found: Api/onLoadSellers_Top
ERROR - 2020-07-09 14:25:56 --> 404 Page Not Found: Api/onLoadSellers_Top
ERROR - 2020-07-09 14:25:59 --> 404 Page Not Found: Api/onLoadSellers_Top
ERROR - 2020-07-09 14:28:06 --> 404 Page Not Found: Api/onLoadSellers_Top
ERROR - 2020-07-09 14:28:23 --> 404 Page Not Found: Api/onLoadSellers_Top
ERROR - 2020-07-09 14:28:29 --> 404 Page Not Found: Api/onLoadSellers_Top
ERROR - 2020-07-09 14:32:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-07-09 14:32:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-07-09 14:32:41 --> 404 Page Not Found: App_adstxt/index
ERROR - 2020-07-09 14:33:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-07-09 14:33:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-07-09 14:33:19 --> 404 Page Not Found: App_adstxt/index
ERROR - 2020-07-09 14:33:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-07-09 14:33:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-07-09 14:33:24 --> 404 Page Not Found: App_adstxt/index
ERROR - 2020-07-09 14:33:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-07-09 14:34:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-07-09 14:34:04 --> 404 Page Not Found: App_adstxt/index
ERROR - 2020-07-09 14:34:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-07-09 14:34:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-07-09 14:34:42 --> 404 Page Not Found: App_adstxt/index
ERROR - 2020-07-09 14:34:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-07-09 14:34:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-07-09 14:34:49 --> 404 Page Not Found: App_adstxt/index
ERROR - 2020-07-09 14:34:57 --> 404 Page Not Found: Api/onLoadSellers_Top
ERROR - 2020-07-09 14:34:59 --> 404 Page Not Found: Api/onLoadSellers_Top
ERROR - 2020-07-09 14:35:01 --> 404 Page Not Found: Api/onLoadSellers_Top
ERROR - 2020-07-09 14:35:02 --> 404 Page Not Found: Api/onLoadSellers_Top
ERROR - 2020-07-09 14:35:05 --> 404 Page Not Found: Api/onLoadSellers_Top
ERROR - 2020-07-09 14:38:02 --> 404 Page Not Found: Api/onLoadSellers_Top
ERROR - 2020-07-09 14:38:13 --> 404 Page Not Found: Api/onLoadSellers_Top
ERROR - 2020-07-09 14:38:51 --> 404 Page Not Found: Api/onLoadSellers_Top
ERROR - 2020-07-09 14:39:55 --> 404 Page Not Found: Api/onLoadSellers_Top
ERROR - 2020-07-09 14:39:58 --> 404 Page Not Found: Api/onLoadSellers_Top
ERROR - 2020-07-09 14:42:51 --> 404 Page Not Found: Api/onLoadSellers_Top
ERROR - 2020-07-09 14:42:55 --> 404 Page Not Found: Api/onLoadSellers_Top
ERROR - 2020-07-09 14:43:25 --> 404 Page Not Found: Api/onLoadSellers_Top
ERROR - 2020-07-09 14:44:04 --> 404 Page Not Found: Api/onLoadSellers_Top
ERROR - 2020-07-09 14:44:06 --> 404 Page Not Found: Api/onLoadSellers_Top
ERROR - 2020-07-09 14:44:07 --> 404 Page Not Found: Api/onLoadSellers_Top
ERROR - 2020-07-09 14:46:18 --> 404 Page Not Found: Api/onLoadSellers_Top
ERROR - 2020-07-09 14:46:58 --> 404 Page Not Found: Api/onLoadSellers_Top
ERROR - 2020-07-09 14:47:01 --> 404 Page Not Found: Api/onLoadSellers_Top
ERROR - 2020-07-09 14:47:02 --> 404 Page Not Found: Api/onLoadSellers_Top
ERROR - 2020-07-09 14:47:05 --> 404 Page Not Found: Api/onLoadSellers_Top
ERROR - 2020-07-09 14:48:38 --> 404 Page Not Found: Api/onLoadSellers_Top
ERROR - 2020-07-09 14:48:51 --> 404 Page Not Found: Api/onLoadSellers_Top
ERROR - 2020-07-09 14:49:09 --> 404 Page Not Found: Api/onLoadSellers_Top
ERROR - 2020-07-09 14:49:33 --> 404 Page Not Found: Api/onLoadSellers_Top
ERROR - 2020-07-09 10:08:10 --> Severity: error --> Exception: Call to undefined function sendSingleFBPush() /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 1407
ERROR - 2020-07-09 10:08:18 --> Severity: error --> Exception: Call to undefined function sendSingleFBPush() /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 1407
ERROR - 2020-07-09 10:09:52 --> Severity: error --> Exception: Call to undefined function sendSingleFBPush() /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 1407
ERROR - 2020-07-09 10:13:57 --> Severity: error --> Exception: Call to undefined function sendSingleFBPush() /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 1407
ERROR - 2020-07-09 10:14:23 --> Severity: error --> Exception: Call to undefined function sendSingleFBPush() /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 1407
ERROR - 2020-07-09 10:14:50 --> Severity: error --> Exception: Call to undefined function sendSingleFBPush() /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 1407
ERROR - 2020-07-09 10:15:36 --> Severity: error --> Exception: Call to undefined function sendSingleFBPush() /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 1407
ERROR - 2020-07-09 10:15:52 --> Severity: error --> Exception: Call to undefined function sendSingleFBPush() /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 1407
ERROR - 2020-07-09 10:23:36 --> Severity: error --> Exception: Call to undefined function sendSingleFBPush() /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 1411
ERROR - 2020-07-09 10:24:20 --> Severity: error --> Exception: Call to undefined function sendSingleFBPush() /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 1411
ERROR - 2020-07-09 10:24:57 --> Severity: error --> Exception: Call to undefined function sendSingleFBPush() /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 1411
ERROR - 2020-07-09 10:26:22 --> Severity: error --> Exception: Call to undefined function sendSingleFBPush() /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 1411
ERROR - 2020-07-09 10:26:39 --> Severity: error --> Exception: Call to undefined function sendSingleFBPush() /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 1411
ERROR - 2020-07-09 10:28:11 --> Severity: error --> Exception: Too few arguments to function Api::sendSingleFBPush(), 0 passed in /home/kaysmbfnu0fv/public_html/system/core/CodeIgniter.php on line 514 and exactly 3 expected /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 1314
ERROR - 2020-07-09 15:28:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-07-09 15:28:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-07-09 15:28:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-07-09 15:28:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-07-09 15:28:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-07-09 15:28:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-07-09 15:37:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-07-09 11:04:58 --> Severity: error --> Exception: Call to undefined function sendSingleFBPush() /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 1411
ERROR - 2020-07-09 11:05:20 --> Severity: error --> Exception: Call to undefined function sendSingleFBPush() /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 1411
ERROR - 2020-07-09 11:07:59 --> Severity: error --> Exception: Too few arguments to function Api::sendRequest(), 0 passed in /home/kaysmbfnu0fv/public_html/system/core/CodeIgniter.php on line 514 and exactly 3 expected /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 1386
ERROR - 2020-07-09 11:54:33 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-09 11:54:33 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-09 16:54:34 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 11:54:36 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-09 11:54:36 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-09 16:54:37 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 11:54:42 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-09 11:54:42 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-09 16:54:43 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 11:54:50 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-09 11:54:50 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-09 16:54:50 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 12:13:56 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-09 12:13:56 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-09 17:13:57 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 12:14:01 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-09 12:14:01 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-09 17:14:01 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 12:14:17 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-09 12:14:17 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-09 17:14:17 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 12:14:26 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-09 12:14:26 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-09 17:14:26 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 12:14:38 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-09 12:14:38 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-09 17:14:39 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 12:14:57 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-09 12:14:57 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-09 17:14:57 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-07-09 12:22:05 --> Could not find the language line "menu_admin_signout"
ERROR - 2020-07-09 12:22:05 --> Could not find the language line "menu_admin_profile"
ERROR - 2020-07-09 17:22:06 --> 404 Page Not Found: Manifestjson/index
