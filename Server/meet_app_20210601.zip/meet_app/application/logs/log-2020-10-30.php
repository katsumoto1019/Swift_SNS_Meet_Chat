<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-30 00:36:38 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-10-30 06:53:34 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-10-30 06:53:35 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-10-30 07:53:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-10-30 08:58:49 --> 404 Page Not Found: Git/HEAD
ERROR - 2020-10-30 08:58:50 --> 404 Page Not Found: Git/HEAD
ERROR - 2020-10-30 11:34:47 --> 404 Page Not Found: Env/index
