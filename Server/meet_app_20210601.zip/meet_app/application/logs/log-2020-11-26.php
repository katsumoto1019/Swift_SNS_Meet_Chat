<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-26 06:14:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-26 07:48:45 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-11-26 07:48:46 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-11-26 16:45:40 --> 404 Page Not Found: Wp_loginphp/index
