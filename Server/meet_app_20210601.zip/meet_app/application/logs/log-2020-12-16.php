<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-16 07:51:12 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-12-16 07:51:12 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-12-16 10:04:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-16 10:37:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-16 22:25:29 --> 404 Page Not Found: Wp_infophp/index
ERROR - 2020-12-16 23:20:20 --> 404 Page Not Found: Wp_loginphp/index
