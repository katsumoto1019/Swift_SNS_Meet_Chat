<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-05 01:26:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-09-05 01:26:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-09-05 11:07:17 --> 404 Page Not Found: Wordpress/wp_admin
