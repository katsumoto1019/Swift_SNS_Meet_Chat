<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-23 01:27:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-08-23 12:09:13 --> 404 Page Not Found: Database/print.css
