<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-15 06:47:10 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-10-15 06:47:11 --> 404 Page Not Found: 404javascriptjs/index
