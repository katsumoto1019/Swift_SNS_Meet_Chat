<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-30 07:50:03 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-01-30 07:50:04 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-01-30 10:28:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-01-30 10:31:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-01-30 13:21:10 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-01-30 13:21:12 --> 404 Page Not Found: Wp_loginphp/index
