<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-29 01:07:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-04-29 03:15:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-04-29 06:32:46 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-04-29 06:32:47 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-04-29 09:17:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-04-29 11:57:27 --> 404 Page Not Found: Env/index
ERROR - 2021-04-29 15:41:30 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2021-04-29 17:44:49 --> 404 Page Not Found: Assets/admin
ERROR - 2021-04-29 19:16:31 --> 404 Page Not Found: Wp_loginphp/index
