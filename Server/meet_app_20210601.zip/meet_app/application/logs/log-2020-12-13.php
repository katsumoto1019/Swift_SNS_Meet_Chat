<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-13 16:23:38 --> Query error: Unknown column '5fd1d592f19b1535b3730b4a' in 'where clause' - Invalid query: SELECT * FROM `tb_user1` JOIN tb_blockusers ON tb_user1.user_id = tb_blockusers.user_id WHERE tb_user1.user_id =5fd1d592f19b1535b3730b4a
ERROR - 2020-12-13 16:34:00 --> Query error: Unknown column '5fd1d592f19b1535b3730b4a' in 'where clause' - Invalid query: SELECT * FROM `tb_user1` JOIN tb_blockusers ON tb_user1.user_id = tb_blockusers.user_id WHERE tb_user1.user_id =5fd1d592f19b1535b3730b4a
ERROR - 2020-12-13 16:35:08 --> Query error: Unknown column '5fd1d592f19b1535b3730b4a' in 'where clause' - Invalid query: SELECT * FROM `tb_user1` JOIN tb_blockusers ON tb_user1.user_id = tb_blockusers.user_id WHERE tb_user1.user_id =5fd1d592f19b1535b3730b4a
ERROR - 2020-12-13 16:36:11 --> Query error: Unknown column '5fd1d592f19b1535b3730b4a' in 'where clause' - Invalid query: SELECT * FROM `tb_user1` JOIN tb_blockusers ON tb_user1.user_id = tb_blockusers.user_id WHERE tb_user1.user_id =5fd1d592f19b1535b3730b4a
ERROR - 2020-12-13 07:38:06 --> 404 Page Not Found: Wp_content/wp_muen.php
ERROR - 2020-12-13 07:43:24 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-12-13 07:43:25 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-12-13 16:58:59 --> Query error: Unknown column '5fd1d592f19b1535b3730b4a' in 'where clause' - Invalid query: SELECT * FROM `tb_user1` JOIN tb_blockusers ON tb_user1.user_id = tb_blockusers.user_id WHERE tb_user1.user_id =5fd1d592f19b1535b3730b4a
ERROR - 2020-12-13 08:05:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-13 08:05:55 --> 404 Page Not Found: Humanstxt/index
ERROR - 2020-12-13 08:05:55 --> 404 Page Not Found: Adstxt/index
ERROR - 2020-12-13 17:15:23 --> Query error: Unknown column '5fd1d592f19b1535b3730b4a' in 'where clause' - Invalid query: SELECT * FROM `tb_user1` WHERE tb_user1.user_id =5fd1d592f19b1535b3730b4a
ERROR - 2020-12-13 17:17:26 --> Query error: Unknown column '5fd1d592f19b1535b3730b4a' in 'where clause' - Invalid query: SELECT * FROM `tb_user1` WHERE tb_user1.user_id =5fd1d592f19b1535b3730b4a
ERROR - 2020-12-13 17:17:46 --> Query error: Unknown column '5fd1d592f19b1535b3730b4a' in 'where clause' - Invalid query: SELECT * FROM `tb_user1` WHERE tb_user1.user_id =5fd1d592f19b1535b3730b4a
ERROR - 2020-12-13 17:21:38 --> Query error: Unknown column '5fd1d592f19b1535b3730b4a' in 'where clause' - Invalid query: SELECT * FROM `tb_user1` WHERE tb_user1.user_id =5fd1d592f19b1535b3730b4a
ERROR - 2020-12-13 17:21:59 --> Query error: Unknown column '5fd1d592f19b1535b3730b4a' in 'where clause' - Invalid query: SELECT * FROM `tb_user1` WHERE tb_user1.user_id =5fd1d592f19b1535b3730b4a
ERROR - 2020-12-13 17:22:35 --> Query error: Unknown column '5fd1d592f19b1535b3730b4a' in 'where clause' - Invalid query: SELECT * FROM `tb_user1` WHERE tb_user1.user_id =5fd1d592f19b1535b3730b4a
ERROR - 2020-12-13 18:39:36 --> Query error: Unknown column 'tb_blockusers.user_id' in 'where clause' - Invalid query: SELECT * FROM `tb_user1` WHERE tb_blockusers.user_id ="5fd1d592f19b1535b3730b4a"
ERROR - 2020-12-13 18:40:30 --> Query error: Unknown column 'tb_blockusers.user_id' in 'where clause' - Invalid query: SELECT * FROM `tb_user1` WHERE tb_blockusers.user_id ="5fd1d592f19b1535b3730b4a"
ERROR - 2020-12-13 18:42:15 --> Query error: Unknown column 'tb_blockusers.user_id' in 'where clause' - Invalid query: SELECT * FROM `tb_user1` WHERE tb_blockusers.user_id ="5fd1d592f19b1535b3730b4a"
ERROR - 2020-12-13 18:42:27 --> Query error: Unknown column 'tb_blockusers.user_id' in 'where clause' - Invalid query: SELECT * FROM `tb_user1` WHERE tb_blockusers.user_id ="5fd1d592f19b1535b3730b4a"
ERROR - 2020-12-13 18:43:22 --> Query error: Unknown column 'tb_blockusers.user_id' in 'where clause' - Invalid query: SELECT * FROM `tb_user1` WHERE tb_blockusers.user_id ="5fd1d592f19b1535b3730b4a"
ERROR - 2020-12-13 18:43:26 --> Query error: Unknown column 'tb_blockusers.user_id' in 'where clause' - Invalid query: SELECT * FROM `tb_user1` WHERE tb_blockusers.user_id ="5fd1d592f19b1535b3730b4a"
ERROR - 2020-12-13 18:43:27 --> Query error: Unknown column 'tb_blockusers.user_id' in 'where clause' - Invalid query: SELECT * FROM `tb_user1` WHERE tb_blockusers.user_id ="5fd1d592f19b1535b3730b4a"
ERROR - 2020-12-13 18:44:04 --> Query error: Unknown column 'tb_blockusers.user_id' in 'where clause' - Invalid query: SELECT * FROM `tb_user1` WHERE tb_blockusers.user_id ="5fd1d592f19b1535b3730b4a"
ERROR - 2020-12-13 10:10:18 --> 404 Page Not Found: Docphp/index
ERROR - 2020-12-13 19:49:02 --> Query error: Unknown column 'tb_blockusers.user_id' in 'where clause' - Invalid query: SELECT * FROM `tb_user1` WHERE tb_blockusers.user_id ="5fd1d592f19b1535b3730b4a"
ERROR - 2020-12-13 19:49:20 --> Query error: Unknown column 'tb_blockusers.user_id' in 'where clause' - Invalid query: SELECT * FROM `tb_user1` WHERE tb_blockusers.user_id ="5fd1d592f19b1535b3730b4a"
ERROR - 2020-12-13 19:49:36 --> Query error: Unknown column 'tb_blockusers.user_id' in 'where clause' - Invalid query: SELECT * FROM `tb_user1` WHERE tb_blockusers.user_id ="5fd1d592f19b1535b3730b4a"
ERROR - 2020-12-13 10:49:38 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-12-13 11:11:00 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-12-13 13:21:57 --> 404 Page Not Found: Miniphp/index
ERROR - 2020-12-13 13:57:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-13 22:07:11 --> 404 Page Not Found: Wp_includes/widgets
