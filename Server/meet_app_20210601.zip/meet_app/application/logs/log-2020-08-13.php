<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-13 01:44:24 --> 404 Page Not Found: Wordpress/index
