<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-22 05:15:29 --> 404 Page Not Found: Signup/index
ERROR - 2020-07-22 22:36:20 --> 404 Page Not Found: Adstxt/index
