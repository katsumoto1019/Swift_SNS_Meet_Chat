<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-22 20:04:44 --> 404 Page Not Found: Robotstxt/index
