<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-25 00:10:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-01-25 05:37:44 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-01-25 05:37:44 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-01-25 06:04:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-01-25 07:44:22 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-01-25 07:44:23 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-01-25 16:55:46 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-01-25 16:55:47 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-01-25 20:33:58 --> 404 Page Not Found: Robotstxt/index
