<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-21 07:44:14 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-02-21 07:44:16 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-02-21 08:58:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-02-21 08:58:59 --> 404 Page Not Found: Sitemapsxml/index
ERROR - 2021-02-21 09:06:14 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-02-21 09:07:34 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2021-02-21 09:10:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-02-21 09:10:34 --> 404 Page Not Found: Sitemapxmlgz/index
ERROR - 2021-02-21 09:11:15 --> 404 Page Not Found: Sitemap_indexxml/index
ERROR - 2021-02-21 09:55:39 --> 404 Page Not Found: Sitemapxmlgz/index
ERROR - 2021-02-21 09:57:14 --> 404 Page Not Found: Atomxml/index
ERROR - 2021-02-21 09:57:15 --> 404 Page Not Found: Atomxml/index
ERROR - 2021-02-21 10:02:09 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-02-21 10:06:10 --> 404 Page Not Found: Sitemap_indexxml/index
ERROR - 2021-02-21 10:09:36 --> 404 Page Not Found: Sitemapsxml/index
ERROR - 2021-02-21 10:21:52 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2021-02-21 17:20:11 --> 404 Page Not Found: Git/HEAD
ERROR - 2021-02-21 23:46:52 --> 404 Page Not Found: Wp_loginphp/index
