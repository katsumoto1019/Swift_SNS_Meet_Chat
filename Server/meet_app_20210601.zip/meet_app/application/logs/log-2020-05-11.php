<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-11 15:52:52 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-05-11 15:53:03 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-05-11 15:53:05 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-05-11 15:53:13 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-05-11 15:53:20 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-05-11 15:53:23 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-05-11 15:53:30 --> 404 Page Not Found: Manifestjson/index
