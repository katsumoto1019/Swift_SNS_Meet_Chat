<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-01 06:38:06 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-04-01 06:38:07 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-04-01 07:05:09 --> 404 Page Not Found: Theme/assets
ERROR - 2021-04-01 14:35:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-04-01 18:54:35 --> 404 Page Not Found: Robotstxt/index
