<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-11 02:33:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-01-11 07:42:59 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-01-11 07:43:00 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-01-11 08:16:00 --> 404 Page Not Found: Env/index
ERROR - 2021-01-11 08:16:01 --> 404 Page Not Found: Vendor/.env
ERROR - 2021-01-11 08:16:01 --> 404 Page Not Found: Storage/.env
ERROR - 2021-01-11 08:16:02 --> 404 Page Not Found: Public/.env
ERROR - 2021-01-11 08:41:26 --> Severity: Compile Error --> Cannot redeclare Api::getBlockUsers() /home/kmfjwp39rnql/public_html/application/controllers/Api.php 1220
ERROR - 2021-01-11 08:41:32 --> Severity: Compile Error --> Cannot redeclare Api::getBlockUsers() /home/kmfjwp39rnql/public_html/application/controllers/Api.php 1220
ERROR - 2021-01-11 08:42:12 --> Severity: Compile Error --> Cannot redeclare Api::getBlockUsers() /home/kmfjwp39rnql/public_html/application/controllers/Api.php 1220
ERROR - 2021-01-11 08:43:34 --> Severity: Compile Error --> Cannot redeclare Api::getBlockUsers() /home/kmfjwp39rnql/public_html/application/controllers/Api.php 1220
ERROR - 2021-01-11 08:44:00 --> Severity: Compile Error --> Cannot redeclare Api::getBlockUsers() /home/kmfjwp39rnql/public_html/application/controllers/Api.php 1220
ERROR - 2021-01-11 08:44:41 --> Severity: Compile Error --> Cannot redeclare Api::getBlockUsers() /home/kmfjwp39rnql/public_html/application/controllers/Api.php 1220
ERROR - 2021-01-11 12:11:50 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-01-11 22:03:29 --> Severity: error --> Exception: Call to undefined method Api::where() /home/kmfjwp39rnql/public_html/application/controllers/Api.php 1319
ERROR - 2021-01-11 13:15:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-01-11 23:45:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT * FROM `tb_user` JOIN tb_block ON tb_user.id = tb_block.block_user_id WHERE tb_block.owner_id =
ERROR - 2021-01-11 23:45:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT * FROM `tb_user` JOIN tb_block ON tb_user.id = tb_block.block_user_id WHERE tb_block.owner_id =
