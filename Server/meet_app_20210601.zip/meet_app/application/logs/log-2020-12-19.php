<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-19 07:41:13 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-12-19 07:41:15 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-12-19 15:58:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-19 16:15:42 --> 404 Page Not Found: Api/getBlockParameters
ERROR - 2020-12-19 20:19:02 --> 404 Page Not Found: Wp_loginphp/index
