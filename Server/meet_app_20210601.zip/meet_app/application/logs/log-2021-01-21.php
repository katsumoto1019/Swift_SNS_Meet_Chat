<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-21 00:01:40 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-01-21 00:01:47 --> 404 Page Not Found: App_adstxt/index
ERROR - 2021-01-21 01:25:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-01-21 01:25:33 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2021-01-21 01:25:36 --> 404 Page Not Found: Blog/robots.txt
ERROR - 2021-01-21 01:25:36 --> 404 Page Not Found: Blog/index
ERROR - 2021-01-21 01:25:37 --> 404 Page Not Found: Wordpress/index
ERROR - 2021-01-21 01:25:37 --> 404 Page Not Found: Wp/index
ERROR - 2021-01-21 07:54:43 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-01-21 07:54:44 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-01-21 15:54:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-01-21 18:34:28 --> 404 Page Not Found: Wp_loginphp/index
