<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-04 04:18:36 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-04 04:18:42 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-04 04:18:50 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-04 04:18:53 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-04 04:19:28 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-04 04:19:31 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-04 04:19:33 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-04 04:19:39 --> 404 Page Not Found: Admin/transactionWorkoutvideo
ERROR - 2020-03-04 04:19:42 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-04 05:50:05 --> Severity: Notice --> Undefined index: cardNumber C:\xampp\htdocs\application\controllers\Api.php 692
ERROR - 2020-03-04 05:50:05 --> Severity: Notice --> Undefined index: expirationDate C:\xampp\htdocs\application\controllers\Api.php 693
ERROR - 2020-03-04 05:50:05 --> Severity: Notice --> Undefined index: cardCode C:\xampp\htdocs\application\controllers\Api.php 694
ERROR - 2020-03-04 05:57:03 --> Severity: error --> Exception: Cannot use object of type net\authorize\api\contract\v1\CreateTransactionResponse as array C:\xampp\htdocs\application\controllers\Api.php 47
ERROR - 2020-03-04 07:03:39 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-04 07:03:42 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-04 06:17:17 --> Severity: Notice --> Undefined index: categories C:\xampp\htdocs\application\controllers\Api.php 86
ERROR - 2020-03-04 06:17:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\controllers\Api.php 86
ERROR - 2020-03-04 06:41:05 --> Severity: error --> Exception: Cannot use object of type net\authorize\api\contract\v1\CreateTransactionResponse as array C:\xampp\htdocs\application\controllers\Api.php 47
ERROR - 2020-03-04 06:45:02 --> Severity: error --> Exception: Cannot use object of type net\authorize\api\contract\v1\CreateTransactionResponse as array C:\xampp\htdocs\application\controllers\Api.php 47
ERROR - 2020-03-04 06:46:47 --> Severity: error --> Exception: Cannot use object of type net\authorize\api\contract\v1\CreateTransactionResponse as array C:\xampp\htdocs\application\controllers\Api.php 47
ERROR - 2020-03-04 06:47:41 --> Severity: Notice --> Undefined index: cnv_id C:\xampp\htdocs\application\controllers\Api.php 691
ERROR - 2020-03-04 06:47:46 --> Severity: error --> Exception: Cannot use object of type net\authorize\api\contract\v1\CreateTransactionResponse as array C:\xampp\htdocs\application\controllers\Api.php 47
ERROR - 2020-03-04 06:49:23 --> Severity: error --> Exception: Cannot use object of type net\authorize\api\contract\v1\CreateTransactionResponse as array C:\xampp\htdocs\application\controllers\Api.php 47
ERROR - 2020-03-04 06:49:55 --> Severity: error --> Exception: Cannot use object of type net\authorize\api\contract\v1\CreateTransactionResponse as array C:\xampp\htdocs\application\controllers\Api.php 47
ERROR - 2020-03-04 06:51:31 --> Severity: Notice --> Undefined index: cnv_id C:\xampp\htdocs\application\controllers\Api.php 691
ERROR - 2020-03-04 11:17:33 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-04 11:17:36 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-04 11:17:40 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-04 11:18:21 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-04 11:22:34 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-04 11:24:17 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-04 11:25:01 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-04 11:25:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-04 11:25:46 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-04 11:36:05 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-04 11:41:30 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-04 11:41:32 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-04 11:41:55 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-04 11:42:25 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-04 10:48:58 --> Severity: Notice --> Undefined index: cnv_title C:\xampp\htdocs\application\controllers\Api.php 692
ERROR - 2020-03-04 10:51:36 --> Severity: Notice --> Undefined index: cnv_title C:\xampp\htdocs\application\controllers\Api.php 692
ERROR - 2020-03-04 19:25:06 --> Severity: error --> Exception: Call to undefined function NOW() C:\xampp\htdocs\application\controllers\Api.php 815
ERROR - 2020-03-04 19:25:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'NOW()) VALUES ('')' at line 1 - Invalid query: INSERT INTO `tb_transaction` (NOW()) VALUES ('')
ERROR - 2020-03-04 20:26:00 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\application\controllers\Api.php 815
ERROR - 2020-03-04 19:26:59 --> Severity: error --> Exception: Call to undefined function NOW() C:\xampp\htdocs\application\controllers\Api.php 814
ERROR - 2020-03-04 19:31:24 --> Severity: Notice --> Undefined index: categories C:\xampp\htdocs\application\controllers\Api.php 86
ERROR - 2020-03-04 19:31:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\controllers\Api.php 86
ERROR - 2020-03-04 20:32:45 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-04 20:32:47 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-04 20:33:34 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-04 20:33:59 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-04 20:34:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-04 20:39:23 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-04 20:40:15 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-04 20:44:58 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-04 20:45:06 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-04 20:45:50 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-04 20:46:02 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-04 20:48:31 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-04 20:48:38 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-04 20:48:57 --> 404 Page Not Found: Manifestjson/index
