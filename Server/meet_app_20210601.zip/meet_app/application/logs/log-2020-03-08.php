<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-08 00:33:01 --> Severity: Notice --> Undefined index: categories C:\xampp\htdocs\application\controllers\Api.php 86
ERROR - 2020-03-08 00:33:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\controllers\Api.php 86
ERROR - 2020-03-08 02:26:39 --> Severity: Notice --> Undefined index: categories C:\xampp\htdocs\application\controllers\Api.php 86
ERROR - 2020-03-08 02:26:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\controllers\Api.php 86
ERROR - 2020-03-08 04:46:05 --> Severity: Notice --> Undefined index: categories C:\xampp\htdocs\application\controllers\Api.php 86
ERROR - 2020-03-08 04:46:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\controllers\Api.php 86
ERROR - 2020-03-08 04:53:31 --> Severity: Notice --> Undefined index: categories C:\xampp\htdocs\application\controllers\Api.php 86
ERROR - 2020-03-08 04:53:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\controllers\Api.php 86
ERROR - 2020-03-08 06:20:15 --> 404 Page Not Found: Api/editProfile
ERROR - 2020-03-08 07:51:11 --> Severity: Notice --> Undefined index: categories C:\xampp\htdocs\application\controllers\Api.php 86
ERROR - 2020-03-08 07:51:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\controllers\Api.php 86
ERROR - 2020-03-08 07:58:24 --> Severity: Notice --> Undefined index: categories C:\xampp\htdocs\application\controllers\Api.php 86
ERROR - 2020-03-08 07:58:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\controllers\Api.php 86
