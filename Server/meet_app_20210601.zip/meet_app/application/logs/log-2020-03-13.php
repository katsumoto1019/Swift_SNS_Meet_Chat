<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-13 02:06:26 --> 404 Page Not Found: Api/removeWorkoutVideo
ERROR - 2020-03-13 02:06:30 --> 404 Page Not Found: Api/removeWorkoutVideo
ERROR - 2020-03-13 02:06:34 --> 404 Page Not Found: Api/removeWorkoutVideo
ERROR - 2020-03-13 02:00:15 --> Severity: Notice --> Undefined index: categories C:\xampp\htdocs\application\controllers\Api.php 86
ERROR - 2020-03-13 02:00:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\controllers\Api.php 86
ERROR - 2020-03-13 05:28:08 --> Severity: Notice --> Undefined index: categories C:\xampp\htdocs\application\controllers\Api.php 86
ERROR - 2020-03-13 05:28:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\controllers\Api.php 86
ERROR - 2020-03-13 21:53:37 --> Severity: Notice --> Undefined index: categories C:\xampp\htdocs\application\controllers\Api.php 86
ERROR - 2020-03-13 21:53:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\controllers\Api.php 86
ERROR - 2020-03-13 23:04:42 --> Severity: Notice --> Undefined index: categories C:\xampp\htdocs\application\controllers\Api.php 86
ERROR - 2020-03-13 23:04:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\controllers\Api.php 86
