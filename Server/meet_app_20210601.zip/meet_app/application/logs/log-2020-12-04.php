<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-04 02:45:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-04 07:52:21 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-12-04 07:52:21 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-12-04 20:01:34 --> 404 Page Not Found: Wp_loginphp/index
