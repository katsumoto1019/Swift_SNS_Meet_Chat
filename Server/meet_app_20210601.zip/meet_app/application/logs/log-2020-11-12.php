<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-12 07:47:59 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-11-12 07:48:00 --> 404 Page Not Found: 404javascriptjs/index
