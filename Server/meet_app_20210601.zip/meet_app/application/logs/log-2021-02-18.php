<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-18 04:24:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-02-18 04:24:44 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-02-18 04:24:44 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-02-18 07:52:35 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-02-18 07:52:35 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-02-18 10:51:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-02-18 23:20:17 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-02-18 23:20:19 --> 404 Page Not Found: App_adstxt/index
