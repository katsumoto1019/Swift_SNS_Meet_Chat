<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-15 07:45:54 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-11-15 07:45:54 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-11-15 19:36:55 --> 404 Page Not Found: Robotstxt/index
