<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-17 01:21:21 --> 404 Page Not Found: Git/HEAD
ERROR - 2020-08-17 03:35:12 --> 404 Page Not Found: Api/deletePost
ERROR - 2020-08-17 03:37:12 --> 404 Page Not Found: Android_icon_192x192png/index
ERROR - 2020-08-17 03:37:49 --> 404 Page Not Found: Android_icon_192x192png/index
ERROR - 2020-08-17 03:38:01 --> 404 Page Not Found: Api/deletePost
ERROR - 2020-08-17 03:38:09 --> 404 Page Not Found: Api/deletePost
ERROR - 2020-08-17 03:39:22 --> 404 Page Not Found: Android_icon_192x192png/index
ERROR - 2020-08-17 03:42:40 --> 404 Page Not Found: Api/deletePost
ERROR - 2020-08-17 03:42:45 --> 404 Page Not Found: Android_icon_192x192png/index
ERROR - 2020-08-17 03:48:35 --> 404 Page Not Found: Android_icon_192x192png/index
ERROR - 2020-08-17 06:39:57 --> 404 Page Not Found: Git/HEAD
ERROR - 2020-08-17 18:00:25 --> 404 Page Not Found: Dev/wp_login.php
ERROR - 2020-08-17 21:51:55 --> 404 Page Not Found: Blog/wp_login.php
