<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-29 00:08:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-29 07:49:20 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-12-29 07:49:22 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-12-29 11:41:44 --> 404 Page Not Found: Robotstxt/index
