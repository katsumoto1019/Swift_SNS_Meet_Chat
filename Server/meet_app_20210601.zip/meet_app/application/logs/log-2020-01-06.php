<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-06 07:55:54 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\application\models\Api_model.php 63
ERROR - 2020-01-06 07:55:54 --> Severity: Notice --> Undefined index: cal C:\xampp\htdocs\application\models\Api_model.php 64
ERROR - 2020-01-06 07:55:54 --> Severity: Notice --> Undefined index: carbs C:\xampp\htdocs\application\models\Api_model.php 65
ERROR - 2020-01-06 07:55:54 --> Severity: Notice --> Undefined index: fat C:\xampp\htdocs\application\models\Api_model.php 66
ERROR - 2020-01-06 07:55:54 --> Severity: Notice --> Undefined index: protein C:\xampp\htdocs\application\models\Api_model.php 67
ERROR - 2020-01-06 07:55:54 --> Severity: Notice --> Undefined index: fiber C:\xampp\htdocs\application\models\Api_model.php 68
ERROR - 2020-01-06 07:55:54 --> Query error: Unknown column 'title' in 'field list' - Invalid query: INSERT INTO `tb_history_items` (`history_id`, `meal_type`, `food_type`, `title`, `cal`, `carbs`, `fat`, `protein`, `fiber`) VALUES (24, 'breakfast', 'Starchy Vegetables', NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2020-01-06 07:55:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\system\core\Exceptions.php:272) C:\xampp\htdocs\system\core\Common.php 573
ERROR - 2020-01-06 10:12:12 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\application\models\Api_model.php 201
ERROR - 2020-01-06 10:43:13 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\application\models\Api_model.php 201
ERROR - 2020-01-06 10:44:03 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\application\models\Api_model.php 201
ERROR - 2020-01-06 10:44:07 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\application\models\Api_model.php 201
ERROR - 2020-01-06 10:44:14 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\application\models\Api_model.php 201
ERROR - 2020-01-06 10:44:26 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\application\models\Api_model.php 201
ERROR - 2020-01-06 10:46:48 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\application\models\Api_model.php 201
ERROR - 2020-01-06 10:46:57 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\application\models\Api_model.php 201
ERROR - 2020-01-06 10:47:30 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\application\models\Api_model.php 201
ERROR - 2020-01-06 10:48:14 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\application\models\Api_model.php 201
ERROR - 2020-01-06 10:48:36 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\application\models\Api_model.php 201
ERROR - 2020-01-06 10:48:51 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\application\models\Api_model.php 201
ERROR - 2020-01-06 10:49:59 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\application\models\Api_model.php 201
ERROR - 2020-01-06 10:50:56 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\application\models\Api_model.php 201
ERROR - 2020-01-06 10:52:13 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\application\models\Api_model.php 201
ERROR - 2020-01-06 09:55:09 --> Severity: error --> Exception: Call to undefined method Api_model::setHistorySubCategories() C:\xampp\htdocs\application\controllers\Api.php 84
ERROR - 2020-01-06 09:59:11 --> Severity: error --> Exception: Call to undefined method Api_model::setHistorySubCategories() C:\xampp\htdocs\application\controllers\Api.php 84
ERROR - 2020-01-06 11:11:27 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\application\models\Api_model.php 200
ERROR - 2020-01-06 11:11:27 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\application\models\Api_model.php 200
ERROR - 2020-01-06 11:12:13 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\application\models\Api_model.php 200
ERROR - 2020-01-06 12:43:07 --> Severity: Notice --> Undefined index: categories C:\xampp\htdocs\application\controllers\Api.php 81
ERROR - 2020-01-06 12:43:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\controllers\Api.php 81
ERROR - 2020-01-06 12:44:19 --> Severity: Notice --> Undefined index: categories C:\xampp\htdocs\application\controllers\Api.php 81
ERROR - 2020-01-06 12:44:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\controllers\Api.php 81
ERROR - 2020-01-06 12:45:23 --> Severity: Notice --> Undefined index: categories C:\xampp\htdocs\application\controllers\Api.php 81
ERROR - 2020-01-06 12:45:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\controllers\Api.php 81
ERROR - 2020-01-06 15:52:36 --> Severity: Notice --> Undefined index: subcategories C:\xampp\htdocs\application\controllers\Api.php 84
ERROR - 2020-01-06 15:52:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\models\Api_model.php 67
ERROR - 2020-01-06 15:52:36 --> Severity: Notice --> Undefined index: subcategories C:\xampp\htdocs\application\controllers\Api.php 84
ERROR - 2020-01-06 15:52:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\models\Api_model.php 67
ERROR - 2020-01-06 15:52:36 --> Severity: Notice --> Undefined index: subcategories C:\xampp\htdocs\application\controllers\Api.php 84
ERROR - 2020-01-06 15:52:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\models\Api_model.php 67
ERROR - 2020-01-06 16:20:47 --> Severity: Notice --> Undefined index: categories C:\xampp\htdocs\application\controllers\Api.php 81
ERROR - 2020-01-06 16:20:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\controllers\Api.php 81
ERROR - 2020-01-06 16:21:36 --> Severity: Notice --> Undefined index: categories C:\xampp\htdocs\application\controllers\Api.php 81
ERROR - 2020-01-06 16:21:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\controllers\Api.php 81
ERROR - 2020-01-06 16:23:48 --> Severity: Notice --> Undefined index: categories C:\xampp\htdocs\application\controllers\Api.php 81
ERROR - 2020-01-06 16:23:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\controllers\Api.php 81
ERROR - 2020-01-06 16:24:02 --> Severity: Notice --> Undefined index: categories C:\xampp\htdocs\application\controllers\Api.php 81
ERROR - 2020-01-06 16:24:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\controllers\Api.php 81
