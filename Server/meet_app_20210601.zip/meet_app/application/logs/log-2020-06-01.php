<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-01 00:12:31 --> 404 Page Not Found: Api/mkContact
ERROR - 2020-06-01 00:12:39 --> 404 Page Not Found: Api/mkContact
ERROR - 2020-06-01 00:15:23 --> 404 Page Not Found: Api/submitFCM
ERROR - 2020-06-01 00:15:51 --> 404 Page Not Found: Api/mkContact
ERROR - 2020-06-01 00:15:56 --> 404 Page Not Found: Api/mkContact
ERROR - 2020-06-01 00:17:25 --> 404 Page Not Found: Api/mkContact
ERROR - 2020-06-01 00:17:28 --> 404 Page Not Found: Api/mkContact
ERROR - 2020-06-01 00:17:30 --> 404 Page Not Found: Api/mkContact
ERROR - 2020-06-01 02:07:55 --> 404 Page Not Found: Api/submitFCM
ERROR - 2020-06-01 02:07:57 --> 404 Page Not Found: Api/mkContact
ERROR - 2020-06-01 16:25:51 --> Severity: error --> Exception: syntax error, unexpected '}' /home/kaysmbfnu0fv/public_html/application/controllers/Api.php 35
