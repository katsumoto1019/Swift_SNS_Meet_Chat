<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-02 01:10:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-02 01:48:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-02 07:49:58 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-12-02 07:49:59 --> 404 Page Not Found: 404javascriptjs/index
