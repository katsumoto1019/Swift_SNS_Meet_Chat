<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-05 02:37:00 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-10-05 02:37:00 --> 404 Page Not Found: Git/HEAD
ERROR - 2020-10-05 02:37:00 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-10-05 02:44:09 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-10-05 02:44:09 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-10-05 06:53:51 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-10-05 06:53:52 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-10-05 15:09:24 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-10-05 23:46:45 --> 404 Page Not Found: Adstxt/index
