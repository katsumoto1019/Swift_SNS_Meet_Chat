<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-12 05:57:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-12 07:53:54 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-12-12 07:53:55 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-12-12 23:56:24 --> 404 Page Not Found: Wp_content/themes
