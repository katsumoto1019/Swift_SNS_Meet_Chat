<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-25 01:16:51 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-12-25 07:45:40 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-12-25 07:45:41 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-12-25 08:08:52 --> 404 Page Not Found: GankphpPhP/index
ERROR - 2020-12-25 19:04:28 --> 404 Page Not Found: Wp_admin/install.php
ERROR - 2020-12-25 20:26:33 --> 404 Page Not Found: Robotstxt/index
