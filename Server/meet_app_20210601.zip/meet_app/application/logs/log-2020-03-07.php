<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-07 01:36:04 --> 404 Page Not Found: Api/getAllContents
ERROR - 2020-03-07 15:46:27 --> 404 Page Not Found: Api/getContentsFavorite
ERROR - 2020-03-07 22:48:17 --> Severity: Notice --> Undefined index: categories C:\xampp\htdocs\application\controllers\Api.php 86
ERROR - 2020-03-07 22:48:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\controllers\Api.php 86
