<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-07 06:43:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-09-07 15:29:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-09-07 16:24:17 --> 404 Page Not Found: Wordpress/wp_admin
ERROR - 2020-09-07 21:20:47 --> 404 Page Not Found: Wp_admin/install.php
ERROR - 2020-09-07 21:42:40 --> 404 Page Not Found: Wp_loginphp/index
