<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-19 03:23:21 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-03-19 04:06:12 --> 404 Page Not Found: Wp_admin/install.php
ERROR - 2021-03-19 05:25:00 --> 404 Page Not Found: GankphpPhP/index
ERROR - 2021-03-19 06:39:47 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-03-19 06:39:48 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-03-19 06:54:34 --> 404 Page Not Found: Wp_content/themes
ERROR - 2021-03-19 18:07:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-03-19 22:36:54 --> 404 Page Not Found: Env/index
