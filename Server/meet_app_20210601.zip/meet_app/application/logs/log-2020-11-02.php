<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-02 06:52:47 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-11-02 06:52:48 --> 404 Page Not Found: 404javascriptjs/index
