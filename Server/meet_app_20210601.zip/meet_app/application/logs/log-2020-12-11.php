<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-11 01:56:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-11 07:47:32 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-12-11 07:47:33 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-12-11 16:14:18 --> 404 Page Not Found: Robotstxt/index
