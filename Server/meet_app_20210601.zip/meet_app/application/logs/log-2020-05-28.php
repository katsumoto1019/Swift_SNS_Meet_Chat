<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-28 01:40:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Api.php 640
ERROR - 2020-05-28 01:40:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Api.php 641
ERROR - 2020-05-28 03:10:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Api.php 640
ERROR - 2020-05-28 03:10:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Api.php 641
ERROR - 2020-05-28 04:37:54 --> Severity: Notice --> Undefined variable: portofolios C:\xampp\htdocs\application\controllers\Api.php 690
ERROR - 2020-05-28 04:37:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Api.php 690
ERROR - 2020-05-28 04:38:03 --> Severity: Notice --> Undefined variable: portofolios C:\xampp\htdocs\application\controllers\Api.php 690
ERROR - 2020-05-28 04:38:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Api.php 690
ERROR - 2020-05-28 04:38:34 --> Severity: Notice --> Undefined variable: portofolios C:\xampp\htdocs\application\controllers\Api.php 690
ERROR - 2020-05-28 04:38:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Api.php 690
ERROR - 2020-05-28 04:39:55 --> Severity: Notice --> Undefined variable: portofolios C:\xampp\htdocs\application\controllers\Api.php 690
ERROR - 2020-05-28 04:39:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Api.php 690
ERROR - 2020-05-28 06:56:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Api.php 640
ERROR - 2020-05-28 06:56:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Api.php 641
ERROR - 2020-05-28 07:00:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Api.php 640
ERROR - 2020-05-28 07:00:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Api.php 641
ERROR - 2020-05-28 10:38:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Api.php 640
ERROR - 2020-05-28 10:38:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\application\controllers\Api.php 641
ERROR - 2020-05-28 19:07:50 --> 404 Page Not Found: Api/booking
