<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-10 05:33:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-03-10 07:49:47 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-03-10 07:49:47 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-03-10 18:36:23 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-03-10 22:43:17 --> 404 Page Not Found: Wp_includes/wlwmanifest.xml
ERROR - 2021-03-10 22:43:17 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2021-03-10 22:43:17 --> 404 Page Not Found: Blog/wp_includes
ERROR - 2021-03-10 22:43:18 --> 404 Page Not Found: Web/wp_includes
ERROR - 2021-03-10 22:43:18 --> 404 Page Not Found: Wordpress/wp_includes
ERROR - 2021-03-10 22:43:18 --> 404 Page Not Found: Website/wp_includes
ERROR - 2021-03-10 22:43:18 --> 404 Page Not Found: Wp/wp_includes
ERROR - 2021-03-10 22:43:18 --> 404 Page Not Found: News/wp_includes
ERROR - 2021-03-10 22:43:19 --> 404 Page Not Found: 2018/wp_includes
ERROR - 2021-03-10 22:43:19 --> 404 Page Not Found: 2019/wp_includes
ERROR - 2021-03-10 22:43:19 --> 404 Page Not Found: Shop/wp_includes
ERROR - 2021-03-10 22:43:19 --> 404 Page Not Found: Wp1/wp_includes
ERROR - 2021-03-10 22:43:20 --> 404 Page Not Found: Test/wp_includes
ERROR - 2021-03-10 22:43:20 --> 404 Page Not Found: Media/wp_includes
ERROR - 2021-03-10 22:43:20 --> 404 Page Not Found: Wp2/wp_includes
ERROR - 2021-03-10 22:43:20 --> 404 Page Not Found: Site/wp_includes
ERROR - 2021-03-10 22:43:21 --> 404 Page Not Found: Cms/wp_includes
ERROR - 2021-03-10 22:43:21 --> 404 Page Not Found: Sito/wp_includes
