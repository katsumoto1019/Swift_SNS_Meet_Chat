<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-27 05:11:41 --> 404 Page Not Found: Robotstxt/index
