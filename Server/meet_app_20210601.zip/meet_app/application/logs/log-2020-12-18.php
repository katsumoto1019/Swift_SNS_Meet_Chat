<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-18 07:52:19 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-12-18 07:52:20 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-12-18 13:55:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-18 20:24:43 --> 404 Page Not Found: Robotstxt/index
