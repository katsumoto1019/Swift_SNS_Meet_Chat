<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-23 07:05:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-07-23 08:39:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-07-23 13:30:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-07-23 14:37:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-07-23 14:37:31 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2020-07-23 14:37:33 --> 404 Page Not Found: Adstxt/index
