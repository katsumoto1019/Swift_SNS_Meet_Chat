<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-30 05:00:49 --> Severity: Notice --> Undefined variable: datas C:\xampp\htdocs\application\controllers\Api.php 1091
ERROR - 2020-03-30 05:00:49 --> Severity: Notice --> Undefined variable: datas C:\xampp\htdocs\application\controllers\Api.php 1091
ERROR - 2020-03-30 05:00:49 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\application\controllers\Api.php 1097
ERROR - 2020-03-30 05:02:54 --> Severity: Notice --> Undefined variable: datas C:\xampp\htdocs\application\controllers\Api.php 1091
ERROR - 2020-03-30 05:02:54 --> Severity: Notice --> Undefined variable: datas C:\xampp\htdocs\application\controllers\Api.php 1091
ERROR - 2020-03-30 05:02:54 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\application\controllers\Api.php 1097
ERROR - 2020-03-30 05:05:56 --> Severity: Notice --> Undefined variable: datas C:\xampp\htdocs\application\controllers\Api.php 1091
ERROR - 2020-03-30 05:05:56 --> Severity: Notice --> Undefined variable: datas C:\xampp\htdocs\application\controllers\Api.php 1091
ERROR - 2020-03-30 05:05:56 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\application\controllers\Api.php 1097
ERROR - 2020-03-30 05:07:34 --> Severity: Notice --> Undefined variable: datas C:\xampp\htdocs\application\controllers\Api.php 1091
ERROR - 2020-03-30 05:07:34 --> Severity: Notice --> Undefined variable: datas C:\xampp\htdocs\application\controllers\Api.php 1091
ERROR - 2020-03-30 05:07:34 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\application\controllers\Api.php 1097
ERROR - 2020-03-30 05:08:36 --> Severity: Notice --> Undefined variable: datas C:\xampp\htdocs\application\controllers\Api.php 1091
ERROR - 2020-03-30 05:08:36 --> Severity: Notice --> Undefined variable: datas C:\xampp\htdocs\application\controllers\Api.php 1091
ERROR - 2020-03-30 05:08:36 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\application\controllers\Api.php 1097
ERROR - 2020-03-30 05:08:54 --> Severity: Notice --> Undefined variable: datas C:\xampp\htdocs\application\controllers\Api.php 1091
ERROR - 2020-03-30 05:08:54 --> Severity: Notice --> Undefined variable: datas C:\xampp\htdocs\application\controllers\Api.php 1091
ERROR - 2020-03-30 05:08:54 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\application\controllers\Api.php 1097
ERROR - 2020-03-30 05:10:25 --> Severity: Notice --> Undefined variable: datas C:\xampp\htdocs\application\controllers\Api.php 1091
ERROR - 2020-03-30 05:10:25 --> Severity: Notice --> Undefined variable: datas C:\xampp\htdocs\application\controllers\Api.php 1091
ERROR - 2020-03-30 05:10:25 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\application\controllers\Api.php 1097
ERROR - 2020-03-30 05:15:14 --> Severity: Notice --> Undefined variable: datas C:\xampp\htdocs\application\controllers\Api.php 1091
ERROR - 2020-03-30 05:15:14 --> Severity: Notice --> Undefined variable: datas C:\xampp\htdocs\application\controllers\Api.php 1091
ERROR - 2020-03-30 05:15:14 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\application\controllers\Api.php 1097
ERROR - 2020-03-30 05:19:54 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\application\controllers\Api.php 1097
ERROR - 2020-03-30 05:26:50 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\application\controllers\Api.php 1097
ERROR - 2020-03-30 05:29:37 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\application\controllers\Api.php 1097
ERROR - 2020-03-30 05:34:35 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\application\controllers\Api.php 1097
ERROR - 2020-03-30 05:37:41 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\application\controllers\Api.php 1097
ERROR - 2020-03-30 05:38:06 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\application\controllers\Api.php 1097
ERROR - 2020-03-30 21:15:32 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-30 21:15:56 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-30 21:16:28 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-30 21:16:31 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-30 21:16:32 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-30 21:16:41 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-30 21:19:48 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-30 21:23:38 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-30 21:26:06 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-30 21:27:59 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-30 21:28:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-30 21:29:32 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-30 21:29:52 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-30 21:30:03 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-30 21:30:22 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-30 21:30:52 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-30 21:31:02 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-30 21:31:06 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-30 21:31:09 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-30 21:31:15 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-30 21:32:01 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-30 21:33:15 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-30 21:33:31 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-30 21:33:40 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-30 21:33:46 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-30 21:34:08 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-30 21:35:01 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-30 21:35:11 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-30 21:37:04 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-30 21:37:20 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-30 21:37:56 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-30 21:38:10 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-30 21:38:25 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-30 21:40:09 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-30 21:40:19 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-30 21:41:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-03-30 21:41:36 --> 404 Page Not Found: Manifestjson/index
