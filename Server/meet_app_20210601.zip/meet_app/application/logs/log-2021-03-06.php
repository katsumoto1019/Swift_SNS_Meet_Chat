<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-06 02:30:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-03-06 03:33:33 --> 404 Page Not Found: _ignition/execute_solution
ERROR - 2021-03-06 05:45:19 --> 404 Page Not Found: Wordpress/wp_login.php
ERROR - 2021-03-06 05:45:20 --> 404 Page Not Found: Blog/wp_login.php
ERROR - 2021-03-06 05:45:20 --> 404 Page Not Found: Wp/wp_login.php
ERROR - 2021-03-06 07:34:30 --> 404 Page Not Found: Blog/wp_login.php
ERROR - 2021-03-06 07:34:31 --> 404 Page Not Found: Wp/wp_login.php
ERROR - 2021-03-06 07:44:14 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-03-06 07:44:15 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-03-06 08:35:55 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-03-06 10:17:19 --> 404 Page Not Found: Robotstxt/index
