<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-09 00:04:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-09 07:50:14 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2020-12-09 07:50:15 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2020-12-09 18:14:30 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-12-09 23:22:58 --> 404 Page Not Found: Robotstxt/index
