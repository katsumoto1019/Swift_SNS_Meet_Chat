<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-08 05:55:14 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-02-08 05:55:15 --> 404 Page Not Found: Wordpress/wp_login.php
ERROR - 2021-02-08 05:55:15 --> 404 Page Not Found: Blog/wp_login.php
ERROR - 2021-02-08 05:55:16 --> 404 Page Not Found: Wp/wp_login.php
ERROR - 2021-02-08 07:48:06 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-02-08 07:48:07 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-02-08 11:59:51 --> 404 Page Not Found: Upsphp/index
ERROR - 2021-02-08 14:20:48 --> 404 Page Not Found: Miniphp/index
ERROR - 2021-02-08 14:22:10 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-02-08 14:22:12 --> 404 Page Not Found: App_adstxt/index
ERROR - 2021-02-08 14:55:13 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-02-08 14:55:14 --> 404 Page Not Found: Wordpress/wp_login.php
ERROR - 2021-02-08 14:55:15 --> 404 Page Not Found: Blog/wp_login.php
ERROR - 2021-02-08 14:55:15 --> 404 Page Not Found: Wp/wp_login.php
ERROR - 2021-02-08 22:07:40 --> 404 Page Not Found: Docphp/index
