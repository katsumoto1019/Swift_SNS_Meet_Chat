<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-22 01:13:58 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-04-22 03:58:19 --> 404 Page Not Found: Env/index
ERROR - 2021-04-22 03:58:19 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2021-04-22 03:58:20 --> 404 Page Not Found: _ignition/execute_solution
ERROR - 2021-04-22 04:11:11 --> 404 Page Not Found: Env/index
ERROR - 2021-04-22 04:11:12 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2021-04-22 04:11:13 --> 404 Page Not Found: _ignition/execute_solution
ERROR - 2021-04-22 09:39:15 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2021-04-22 09:39:16 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2021-04-22 10:57:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-04-22 16:18:21 --> 404 Page Not Found: Robotstxt/index
