<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-21 07:18:50 --> 404 Page Not Found: Wp_json/index
ERROR - 2020-08-21 07:18:50 --> 404 Page Not Found: Blog/wp_json
ERROR - 2020-08-21 13:32:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-08-21 13:32:24 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2020-08-21 13:32:25 --> 404 Page Not Found: Adstxt/index
