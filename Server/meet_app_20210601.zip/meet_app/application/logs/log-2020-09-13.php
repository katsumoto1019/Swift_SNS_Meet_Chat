<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-13 11:01:42 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-09-13 13:09:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-09-13 21:43:33 --> 404 Page Not Found: Robotstxt/index
