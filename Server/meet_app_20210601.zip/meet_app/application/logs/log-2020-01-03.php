<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-03 01:23:09 --> Severity: Notice --> Undefined index: jsonObject C:\xampp\htdocs\application\controllers\Api.php 75
ERROR - 2020-01-03 01:23:09 --> Severity: Notice --> Undefined variable: firstsnack C:\xampp\htdocs\application\models\Api_model.php 49
ERROR - 2020-01-03 01:23:09 --> Severity: Notice --> Undefined variable: secondsnack C:\xampp\htdocs\application\models\Api_model.php 50
ERROR - 2020-01-03 01:23:09 --> Severity: Notice --> Undefined variable: thirdsnack C:\xampp\htdocs\application\models\Api_model.php 51
ERROR - 2020-01-03 01:23:09 --> Query error: Column 'email' cannot be null - Invalid query: INSERT INTO `tb_history` (`email`, `total`, `remain`, `score`, `grade`, `breakfast`, `lunch`, `dinner`, `firstsnack`, `secondsnack`, `thirdsnack`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2020-01-03 01:24:39 --> Severity: Notice --> Undefined index: jsonObject C:\xampp\htdocs\application\controllers\Api.php 75
ERROR - 2020-01-03 01:24:39 --> Severity: Notice --> Undefined variable: firstsnack C:\xampp\htdocs\application\models\Api_model.php 49
ERROR - 2020-01-03 01:24:39 --> Severity: Notice --> Undefined variable: secondsnack C:\xampp\htdocs\application\models\Api_model.php 50
ERROR - 2020-01-03 01:24:39 --> Severity: Notice --> Undefined variable: thirdsnack C:\xampp\htdocs\application\models\Api_model.php 51
ERROR - 2020-01-03 01:24:39 --> Query error: Column 'email' cannot be null - Invalid query: INSERT INTO `tb_history` (`email`, `total`, `remain`, `score`, `grade`, `breakfast`, `lunch`, `dinner`, `firstsnack`, `secondsnack`, `thirdsnack`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2020-01-03 01:53:34 --> Severity: Notice --> Undefined index: jsonObject C:\xampp\htdocs\application\controllers\Api.php 75
ERROR - 2020-01-03 01:53:34 --> Query error: Column 'email' cannot be null - Invalid query: INSERT INTO `tb_history` (`email`, `score`, `grade`, `date`, `total`, `remain`, `breakfast`, `lunch`, `dinner`, `firstsnack`, `secondsnack`, `thirdsnack`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2020-01-03 01:55:01 --> Severity: Notice --> Undefined index: jsonObject C:\xampp\htdocs\application\controllers\Api.php 75
ERROR - 2020-01-03 01:55:01 --> Query error: Column 'email' cannot be null - Invalid query: INSERT INTO `tb_history` (`email`, `score`, `grade`, `date`, `total`, `remain`, `breakfast`, `lunch`, `dinner`, `firstsnack`, `secondsnack`, `thirdsnack`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2020-01-03 02:01:20 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\application\controllers\Api.php 77
ERROR - 2020-01-03 02:01:20 --> Severity: Notice --> Undefined index: score C:\xampp\htdocs\application\controllers\Api.php 77
ERROR - 2020-01-03 02:01:20 --> Severity: Notice --> Undefined index: grade C:\xampp\htdocs\application\controllers\Api.php 77
ERROR - 2020-01-03 02:01:20 --> Severity: Notice --> Undefined index: time C:\xampp\htdocs\application\controllers\Api.php 77
ERROR - 2020-01-03 02:01:20 --> Severity: Notice --> Undefined index: total C:\xampp\htdocs\application\controllers\Api.php 77
ERROR - 2020-01-03 02:01:20 --> Severity: Notice --> Undefined index: remain C:\xampp\htdocs\application\controllers\Api.php 77
ERROR - 2020-01-03 02:01:20 --> Severity: Notice --> Undefined index: breakfast C:\xampp\htdocs\application\controllers\Api.php 77
ERROR - 2020-01-03 02:01:20 --> Severity: Notice --> Undefined index: lunch C:\xampp\htdocs\application\controllers\Api.php 77
ERROR - 2020-01-03 02:01:20 --> Severity: Notice --> Undefined index: dinner C:\xampp\htdocs\application\controllers\Api.php 77
ERROR - 2020-01-03 02:01:20 --> Severity: Notice --> Undefined index: snack1 C:\xampp\htdocs\application\controllers\Api.php 77
ERROR - 2020-01-03 02:01:20 --> Severity: Notice --> Undefined index: snack2 C:\xampp\htdocs\application\controllers\Api.php 77
ERROR - 2020-01-03 02:01:20 --> Severity: Notice --> Undefined variable: historyObject C:\xampp\htdocs\application\controllers\Api.php 77
ERROR - 2020-01-03 02:01:20 --> Query error: Column 'email' cannot be null - Invalid query: INSERT INTO `tb_history` (`email`, `score`, `grade`, `date`, `total`, `remain`, `breakfast`, `lunch`, `dinner`, `firstsnack`, `secondsnack`, `thirdsnack`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2020-01-03 02:01:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\system\core\Exceptions.php:272) C:\xampp\htdocs\system\core\Common.php 573
ERROR - 2020-01-03 02:02:42 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\application\controllers\Api.php 77
ERROR - 2020-01-03 02:02:42 --> Severity: Notice --> Undefined index: score C:\xampp\htdocs\application\controllers\Api.php 77
ERROR - 2020-01-03 02:02:42 --> Severity: Notice --> Undefined index: grade C:\xampp\htdocs\application\controllers\Api.php 77
ERROR - 2020-01-03 02:02:42 --> Severity: Notice --> Undefined index: time C:\xampp\htdocs\application\controllers\Api.php 77
ERROR - 2020-01-03 02:02:42 --> Severity: Notice --> Undefined index: total C:\xampp\htdocs\application\controllers\Api.php 77
ERROR - 2020-01-03 02:02:42 --> Severity: Notice --> Undefined index: remain C:\xampp\htdocs\application\controllers\Api.php 77
ERROR - 2020-01-03 02:02:42 --> Severity: Notice --> Undefined index: breakfast C:\xampp\htdocs\application\controllers\Api.php 77
ERROR - 2020-01-03 02:02:42 --> Severity: Notice --> Undefined index: lunch C:\xampp\htdocs\application\controllers\Api.php 77
ERROR - 2020-01-03 02:02:42 --> Severity: Notice --> Undefined index: dinner C:\xampp\htdocs\application\controllers\Api.php 77
ERROR - 2020-01-03 02:02:42 --> Severity: Notice --> Undefined index: snack1 C:\xampp\htdocs\application\controllers\Api.php 77
ERROR - 2020-01-03 02:02:42 --> Severity: Notice --> Undefined index: snack2 C:\xampp\htdocs\application\controllers\Api.php 77
ERROR - 2020-01-03 02:02:42 --> Severity: Notice --> Undefined variable: historyObject C:\xampp\htdocs\application\controllers\Api.php 77
ERROR - 2020-01-03 02:02:42 --> Query error: Column 'email' cannot be null - Invalid query: INSERT INTO `tb_history` (`email`, `score`, `grade`, `date`, `total`, `remain`, `breakfast`, `lunch`, `dinner`, `firstsnack`, `secondsnack`, `thirdsnack`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2020-01-03 02:02:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\system\core\Exceptions.php:272) C:\xampp\htdocs\system\core\Common.php 573
ERROR - 2020-01-03 02:03:38 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\application\controllers\Api.php 77
ERROR - 2020-01-03 02:03:38 --> Severity: Notice --> Undefined index: score C:\xampp\htdocs\application\controllers\Api.php 77
ERROR - 2020-01-03 02:03:38 --> Severity: Notice --> Undefined index: grade C:\xampp\htdocs\application\controllers\Api.php 77
ERROR - 2020-01-03 02:03:38 --> Severity: Notice --> Undefined index: time C:\xampp\htdocs\application\controllers\Api.php 77
ERROR - 2020-01-03 02:03:38 --> Severity: Notice --> Undefined index: total C:\xampp\htdocs\application\controllers\Api.php 77
ERROR - 2020-01-03 02:03:38 --> Severity: Notice --> Undefined index: remain C:\xampp\htdocs\application\controllers\Api.php 77
ERROR - 2020-01-03 02:03:38 --> Severity: Notice --> Undefined index: breakfast C:\xampp\htdocs\application\controllers\Api.php 77
ERROR - 2020-01-03 02:03:38 --> Severity: Notice --> Undefined index: lunch C:\xampp\htdocs\application\controllers\Api.php 77
ERROR - 2020-01-03 02:03:38 --> Severity: Notice --> Undefined index: dinner C:\xampp\htdocs\application\controllers\Api.php 77
ERROR - 2020-01-03 02:03:38 --> Severity: Notice --> Undefined index: snack1 C:\xampp\htdocs\application\controllers\Api.php 77
ERROR - 2020-01-03 02:03:38 --> Severity: Notice --> Undefined index: snack2 C:\xampp\htdocs\application\controllers\Api.php 77
ERROR - 2020-01-03 02:03:38 --> Severity: Notice --> Undefined variable: historyObject C:\xampp\htdocs\application\controllers\Api.php 77
ERROR - 2020-01-03 02:03:38 --> Query error: Column 'email' cannot be null - Invalid query: INSERT INTO `tb_history` (`email`, `score`, `grade`, `date`, `total`, `remain`, `breakfast`, `lunch`, `dinner`, `firstsnack`, `secondsnack`, `thirdsnack`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2020-01-03 02:03:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\system\core\Exceptions.php:272) C:\xampp\htdocs\system\core\Common.php 573
ERROR - 2020-01-03 03:03:42 --> Severity: Notice --> Undefined index: table_name C:\xampp\htdocs\application\controllers\Api.php 207
ERROR - 2020-01-03 03:03:42 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2020-01-03 03:21:11 --> Severity: Notice --> Undefined variable: historyId C:\xampp\htdocs\application\controllers\Api.php 83
ERROR - 2020-01-03 03:22:13 --> Severity: Notice --> Undefined variable: historyId C:\xampp\htdocs\application\controllers\Api.php 83
ERROR - 2020-01-03 04:42:15 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\application\controllers\Api.php 82
ERROR - 2020-01-03 04:42:15 --> Severity: Notice --> Undefined index: assignedFoodModels C:\xampp\htdocs\application\controllers\Api.php 83
ERROR - 2020-01-03 04:45:15 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\application\controllers\Api.php 82
ERROR - 2020-01-03 04:48:49 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\application\controllers\Api.php 82
ERROR - 2020-01-03 06:50:32 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\application\views\admin\dashboard.php 55
ERROR - 2020-01-03 06:50:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\admin\dashboard.php 55
