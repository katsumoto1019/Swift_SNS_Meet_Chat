<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-29 00:09:44 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 00:09:52 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 00:10:27 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 00:11:46 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 00:12:50 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 00:13:32 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 00:13:34 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 00:14:38 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 00:14:46 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 00:14:59 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 00:22:08 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 00:27:19 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 00:37:17 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 00:39:35 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 00:39:42 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 00:39:45 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 00:39:47 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 00:42:15 --> Severity: error --> Exception: Call to undefined function mysqli_init() C:\xampp\htdocs\system\database\drivers\mysqli\mysqli_driver.php 136
ERROR - 2020-02-29 00:44:47 --> Severity: error --> Exception: Call to undefined function mysqli_init() C:\xampp\htdocs\system\database\drivers\mysqli\mysqli_driver.php 136
ERROR - 2020-02-29 00:44:50 --> Severity: error --> Exception: Call to undefined function mysqli_init() C:\xampp\htdocs\system\database\drivers\mysqli\mysqli_driver.php 136
ERROR - 2020-02-29 00:48:35 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 00:48:40 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 00:48:59 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 00:50:51 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 00:51:37 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 00:51:41 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 00:51:43 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 00:52:00 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 00:52:21 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 00:53:31 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 00:53:35 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 00:55:05 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 00:55:17 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 01:02:04 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 01:16:05 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 01:16:06 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 01:16:15 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 01:16:38 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 01:23:16 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 01:28:24 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 01:28:33 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 01:28:45 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 01:30:02 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 01:30:04 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 01:31:38 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 01:31:38 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 01:31:46 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 01:31:48 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 01:32:09 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 01:32:17 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 01:34:26 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 01:38:10 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 01:38:32 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 01:38:45 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 01:38:53 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 01:39:15 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 01:39:19 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 01:39:34 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 01:41:34 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 01:41:38 --> 404 Page Not Found: Admin_model/addworkoutvideo
ERROR - 2020-02-29 01:42:28 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 01:42:29 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 01:42:33 --> 404 Page Not Found: Admin_model/addworkoutvideo
ERROR - 2020-02-29 01:42:41 --> 404 Page Not Found: Admin_model/addworkoutvideo
ERROR - 2020-02-29 01:43:22 --> 404 Page Not Found: Admin_model/addworkoutvideo
ERROR - 2020-02-29 01:43:25 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 01:43:27 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 01:43:36 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 01:43:49 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 02:08:22 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 02:11:54 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 02:13:10 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 02:13:16 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 02:13:41 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 03:25:31 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 03:26:32 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 03:27:29 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 03:28:13 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 03:28:47 --> 404 Page Not Found: Uploadfiles/workoutvideo
ERROR - 2020-02-29 03:28:48 --> 404 Page Not Found: Uploadfiles/workoutvideo
ERROR - 2020-02-29 03:28:48 --> 404 Page Not Found: Uploadfiles/workoutvideo
ERROR - 2020-02-29 03:28:51 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 03:31:18 --> Severity: error --> Exception: syntax error, unexpected '$source_file' (T_VARIABLE) C:\xampp\htdocs\application\controllers\Admin.php 751
ERROR - 2020-02-29 03:31:21 --> Severity: error --> Exception: syntax error, unexpected '$source_file' (T_VARIABLE) C:\xampp\htdocs\application\controllers\Admin.php 751
ERROR - 2020-02-29 03:32:06 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file C:\xampp\htdocs\application\controllers\Admin.php 770
ERROR - 2020-02-29 03:32:08 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file C:\xampp\htdocs\application\controllers\Admin.php 770
ERROR - 2020-02-29 03:32:56 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 03:35:02 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 03:35:09 --> 404 Page Not Found: Uploadfiles/workoutvideo
ERROR - 2020-02-29 03:35:09 --> 404 Page Not Found: Uploadfiles/workoutvideo
ERROR - 2020-02-29 03:35:09 --> 404 Page Not Found: Uploadfiles/workoutvideo
ERROR - 2020-02-29 03:35:09 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 03:38:35 --> 404 Page Not Found: Admin/add_workoutvideo
ERROR - 2020-02-29 03:38:53 --> 404 Page Not Found: Admin/add_workoutvideo
ERROR - 2020-02-29 03:38:56 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 03:38:58 --> 404 Page Not Found: Admin/add_workoutvideo
ERROR - 2020-02-29 03:39:24 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 03:39:42 --> 404 Page Not Found: Uploadfiles/workoutvideo
ERROR - 2020-02-29 03:39:43 --> 404 Page Not Found: Uploadfiles/workoutvideo
ERROR - 2020-02-29 03:39:43 --> 404 Page Not Found: Uploadfiles/workoutvideo
ERROR - 2020-02-29 03:39:43 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 03:39:45 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 03:40:17 --> 404 Page Not Found: Uploadfiles/workoutvideo
ERROR - 2020-02-29 03:40:17 --> 404 Page Not Found: Uploadfiles/workoutvideo
ERROR - 2020-02-29 03:40:17 --> 404 Page Not Found: Uploadfiles/workoutvideo
ERROR - 2020-02-29 03:40:17 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 03:41:18 --> 404 Page Not Found: Uploadfiles/workoutvideo
ERROR - 2020-02-29 03:41:18 --> 404 Page Not Found: Uploadfiles/workoutvideo
ERROR - 2020-02-29 03:41:19 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 03:45:49 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 03:46:06 --> 404 Page Not Found: Uploadfiles/workoutvideo
ERROR - 2020-02-29 03:46:06 --> 404 Page Not Found: Uploadfiles/workoutvideo
ERROR - 2020-02-29 03:46:07 --> 404 Page Not Found: Uploadfiles/workoutvideo
ERROR - 2020-02-29 03:46:07 --> 404 Page Not Found: Uploadfiles/workoutvideo
ERROR - 2020-02-29 03:46:07 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 03:49:33 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 03:50:06 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 03:50:23 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 03:50:29 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 03:51:13 --> 404 Page Not Found: Uploadfiles/workoutvideo
ERROR - 2020-02-29 03:51:13 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 03:51:40 --> 404 Page Not Found: Uploadfiles/workoutvideo
ERROR - 2020-02-29 03:52:38 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 03:53:13 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 03:53:31 --> 404 Page Not Found: Uploadfiles/workoutvideo
ERROR - 2020-02-29 03:53:31 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 03:56:13 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 03:56:37 --> 404 Page Not Found: Uploadfiles/workoutvideo
ERROR - 2020-02-29 03:56:37 --> 404 Page Not Found: Uploadfiles/workoutvideo
ERROR - 2020-02-29 03:56:37 --> 404 Page Not Found: Uploadfiles/workoutvideo
ERROR - 2020-02-29 03:56:37 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 03:58:05 --> 404 Page Not Found: Uploadfiles/workoutvideo
ERROR - 2020-02-29 03:58:05 --> 404 Page Not Found: Uploadfiles/workoutvideo
ERROR - 2020-02-29 03:58:05 --> 404 Page Not Found: Uploadfiles/workoutvideo
ERROR - 2020-02-29 03:58:06 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 03:58:10 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 03:58:27 --> 404 Page Not Found: Uploadfiles/workoutvideo
ERROR - 2020-02-29 03:58:27 --> 404 Page Not Found: Uploadfiles/workoutvideo
ERROR - 2020-02-29 03:58:27 --> 404 Page Not Found: Uploadfiles/workoutvideo
ERROR - 2020-02-29 03:58:28 --> 404 Page Not Found: Uploadfiles/workoutvideo
ERROR - 2020-02-29 03:58:28 --> 404 Page Not Found: Uploadfiles/workoutvideo
ERROR - 2020-02-29 03:58:28 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:00:21 --> Severity: error --> Exception: syntax error, unexpected ''max_size'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\application\controllers\Admin.php 782
ERROR - 2020-02-29 03:00:58 --> Severity: Warning --> unlink(uploadfiles/workoutvideo/1582945107508.mp4): No such file or directory C:\xampp\htdocs\application\controllers\Admin.php 513
ERROR - 2020-02-29 04:00:58 --> 404 Page Not Found: Uploadfiles/workoutvideo
ERROR - 2020-02-29 04:00:58 --> 404 Page Not Found: Uploadfiles/workoutvideo
ERROR - 2020-02-29 04:00:59 --> 404 Page Not Found: Uploadfiles/workoutvideo
ERROR - 2020-02-29 04:00:59 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 03:01:02 --> Severity: Warning --> unlink(uploadfiles/workoutvideo/1582944996359.mp4): No such file or directory C:\xampp\htdocs\application\controllers\Admin.php 513
ERROR - 2020-02-29 04:01:03 --> 404 Page Not Found: Uploadfiles/workoutvideo
ERROR - 2020-02-29 04:01:03 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 03:01:06 --> Severity: Warning --> unlink(uploadfiles/workoutvideo/1582944810739.png): No such file or directory C:\xampp\htdocs\application\controllers\Admin.php 511
ERROR - 2020-02-29 04:01:06 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:01:10 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:01:13 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:01:21 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:01:38 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:01:41 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:02:06 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:04:25 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:04:41 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:05:41 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:05:57 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:06:05 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:06:43 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:07:19 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:07:38 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:08:29 --> 404 Page Not Found: Uploadfiles/workoutvideo
ERROR - 2020-02-29 04:08:29 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:08:29 --> 404 Page Not Found: Uploadfiles/workoutvideo
ERROR - 2020-02-29 04:08:56 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:10:25 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:10:27 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:11:27 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:14:17 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:14:20 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:14:44 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:15:25 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:15:43 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:17:55 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:18:10 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:18:37 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:18:44 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:19:38 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:19:43 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:20:59 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:21:08 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:21:14 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:21:39 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:24:22 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:27:51 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:28:41 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:28:48 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:29:05 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:29:13 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:29:30 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:29:50 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:30:01 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:30:08 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:30:14 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:30:24 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:30:28 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:30:31 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:30:37 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:30:52 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:31:08 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:32:14 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:32:21 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:33:13 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:33:24 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:33:57 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:34:03 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:34:15 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 04:34:18 --> 404 Page Not Found: Manifestjson/index
ERROR - 2020-02-29 11:33:54 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\application\controllers\Api.php 489
ERROR - 2020-02-29 11:33:54 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\application\controllers\Api.php 489
ERROR - 2020-02-29 11:33:54 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\application\controllers\Api.php 489
ERROR - 2020-02-29 11:33:54 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\application\controllers\Api.php 489
ERROR - 2020-02-29 11:33:54 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\application\controllers\Api.php 489
ERROR - 2020-02-29 11:38:10 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::get_values_orderby() C:\xampp\htdocs\application\controllers\Api.php 462
ERROR - 2020-02-29 11:38:38 --> Severity: Notice --> Undefined property: Api::$admin_model C:\xampp\htdocs\application\controllers\Api.php 462
ERROR - 2020-02-29 11:38:38 --> Severity: error --> Exception: Call to a member function get_values_orderby() on null C:\xampp\htdocs\application\controllers\Api.php 462
ERROR - 2020-02-29 11:39:27 --> Severity: error --> Exception: Call to a member function num_rows() on array C:\xampp\htdocs\application\controllers\Api.php 465
ERROR - 2020-02-29 11:40:57 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::get_values_orderby() C:\xampp\htdocs\application\controllers\Api.php 463
ERROR - 2020-02-29 11:59:29 --> Severity: error --> Exception: Too few arguments to function Api_model::update_query(), 2 passed in C:\xampp\htdocs\application\controllers\Api.php on line 514 and exactly 3 expected C:\xampp\htdocs\application\models\Api_model.php 85
ERROR - 2020-02-29 21:23:12 --> 404 Page Not Found: Api/getgetNutritionists
ERROR - 2020-02-29 20:23:23 --> Query error: Unknown column 'coachingservice_id' in 'where clause' - Invalid query: SELECT *
FROM `tb_mynutritionists`
WHERE `user_id` = '6'
AND `coachingservice_id` = '1'
ERROR - 2020-02-29 20:25:20 --> Query error: Unknown column 'nutritionist_id' in 'field list' - Invalid query: INSERT INTO `tb_mycoachingservices` (`user_id`, `nutritionist_id`) VALUES ('6', '4')
ERROR - 2020-02-29 20:44:34 --> Query error: Table 'foodtrack.tb_myworkoutvideos' doesn't exist - Invalid query: SELECT *
FROM `tb_myworkoutvideos`
WHERE `user_id` = '6'
AND `workoutvideo_id` = '3'
