<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

// ------------------------------------------------------------------------
// Paypal IPN Class
// ------------------------------------------------------------------------

// Use PayPal on Sandbox or Live
$config['sandbox'] = TRUE; // FALSE for live environment
$config['client_id'] = 'AXJ1AXEeLXUyp-vnTSeEw6fr7YChnAsqPgUWhjfuLgO9uPEl3zmesglRaXQKyGH0kmv53Xuoay-yBnlA';
$config['secret'] = 'EP8kycfOXMtNMB2uX7XYUAEYgtyLPz4Ox0D0OGms1PaAEOQ11xliLoouJq_hqGiUeI5a2zVfxuQdvykO';

// PayPal Business Email ID
//$config['business'] = 'learnjoy007@gmail.com';
//$config['business'] = 'learnjoy007-facilitator@gmail.com';
$config['business'] = 'sarmadmahbouba-facilitator@gmail.com';

// for live environment
//$config['sandbox'] = FALSE; // FALSE for live environment
//$config['client_id'] = 'ATepeyupLlWPl__G-JitX50xJWZE3l15skALJ_qQEvzsfsbXFyFspTU5H6-dAumLtI29xHmRgL5Ll6iD';
//$config['secret'] = 'EFxEVwYFs8CR_Zpwzgf720GSv5AF6SVFUO8tMvT-fL-WK8eFt7eWr4HFd1rd533pyioidJlk6NSEvFdh';
//$config['business'] = 'sarmadmahbouba@gmail.com';

// If (and where) to log ipn to file
$config['paypal_lib_ipn_log_file'] = BASEPATH . 'logs/paypal_ipn.log';
$config['paypal_lib_ipn_log'] = TRUE;

// Where are the buttons located at 
$config['paypal_lib_button_path'] = 'buttons';

// What is the default currency?
$config['paypal_lib_currency_code'] = 'USD';

?>
